from __future__ import annotations

import csv
import sqlite3
from pathlib import Path

from .db import quote_ident


def export_table_to_csv(
    conn: sqlite3.Connection,
    table_name: str,
    output_file: Path,
    encoding: str,
    delimiter: str,
) -> int:
    output_file.parent.mkdir(parents=True, exist_ok=True)

    cursor = conn.execute(f"SELECT * FROM {quote_ident(table_name)};")
    columns = [desc[0] for desc in cursor.description]

    row_count = 0
    with output_file.open("w", encoding=encoding, newline="") as f:
        writer = csv.writer(f, delimiter=delimiter, lineterminator="\n")
        writer.writerow(columns)
        for row in cursor:
            writer.writerow([row[col] for col in columns])
            row_count += 1

    return row_count

from __future__ import annotations

import csv
import sqlite3
from pathlib import Path

from .db import quote_ident


def validate_input_file(input_file: Path, required_columns: list[str], encoding: str) -> list[str]:
    if not input_file.exists():
        raise FileNotFoundError(f"Input file not found: {input_file}")

    with input_file.open("r", encoding=encoding, newline="") as f:
        reader = csv.reader(f)
        header = next(reader, None)

    if not header:
        raise ValueError("Input CSV is empty or missing header.")

    missing = [col for col in required_columns if col not in header]
    if missing:
        raise ValueError(f"Input CSV missing required columns: {missing}")

    return header


def load_csv_to_table(
    conn: sqlite3.Connection,
    input_file: Path,
    table_name: str,
    encoding: str,
    delimiter: str,
) -> int:
    with input_file.open("r", encoding=encoding, newline="") as f:
        reader = csv.DictReader(f, delimiter=delimiter)
        columns = reader.fieldnames or []
        if not columns:
            raise ValueError("Input CSV has no columns.")

        quoted_columns = ", ".join(f"{quote_ident(col)} TEXT" for col in columns)
        conn.execute(f"DROP TABLE IF EXISTS {quote_ident(table_name)};")
        conn.execute(f"CREATE TABLE {quote_ident(table_name)} ({quoted_columns});")

        placeholders = ", ".join(["?"] * len(columns))
        column_list = ", ".join(quote_ident(col) for col in columns)
        sql = f"INSERT INTO {quote_ident(table_name)} ({column_list}) VALUES ({placeholders});"

        row_count = 0
        for row in reader:
            conn.execute(sql, [row.get(col, "") for col in columns])
            row_count += 1

    conn.commit()
    return row_count

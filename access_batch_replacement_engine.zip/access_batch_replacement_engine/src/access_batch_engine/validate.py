from __future__ import annotations

import csv
import sqlite3
from pathlib import Path


def record_validation(conn: sqlite3.Connection, name: str, status: str, message: str) -> None:
    conn.execute(
        "INSERT INTO validation_results(validation_name, status, message) VALUES (?, ?, ?);",
        (name, status, message),
    )
    conn.commit()


def validate_output_file(output_file: Path) -> None:
    if not output_file.exists():
        raise FileNotFoundError(f"Output file was not created: {output_file}")

    if output_file.stat().st_size == 0:
        raise ValueError(f"Output file is empty: {output_file}")

    with output_file.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.reader(f)
        header = next(reader, None)

    if not header:
        raise ValueError("Output CSV is missing a header row.")


def validate_final_table(conn: sqlite3.Connection) -> None:
    row_count = conn.execute("SELECT COUNT(*) AS n FROM final_export;").fetchone()["n"]
    if row_count < 1:
        raise ValueError("final_export table has zero rows.")

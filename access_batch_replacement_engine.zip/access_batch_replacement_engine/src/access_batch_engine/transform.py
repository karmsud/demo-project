from __future__ import annotations

import sqlite3
from pathlib import Path

from .db import execute_sql_file


def run_transformations(conn: sqlite3.Connection, sql_dir: Path) -> None:
    ordered_scripts = [
        "001_create_reference_defaults.sql",
        "010_normalize_servicer.sql",
        "020_join_sources.sql",
        "030_create_final_export.sql",
    ]

    for script in ordered_scripts:
        execute_sql_file(conn, sql_dir / script)

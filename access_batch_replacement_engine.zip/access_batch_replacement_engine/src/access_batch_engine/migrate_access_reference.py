from __future__ import annotations

import argparse
from pathlib import Path
import sqlite3

from .db import quote_ident


def parse_args():
    parser = argparse.ArgumentParser(description="Migrate local Access tables to SQLite reference DB.")
    parser.add_argument("--access-file", required=True)
    parser.add_argument("--sqlite-reference-db", required=True)
    return parser.parse_args()


def main():
    try:
        import pyodbc
    except ImportError as exc:
        raise RuntimeError("pyodbc is required for Access migration.") from exc

    args = parse_args()
    access_file = Path(args.access_file).resolve()
    sqlite_db = Path(args.sqlite_reference_db).resolve()
    sqlite_db.parent.mkdir(parents=True, exist_ok=True)

    access_conn = pyodbc.connect(
        r"DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};"
        rf"DBQ={access_file};"
    )
    sqlite_conn = sqlite3.connect(sqlite_db)

    cursor = access_conn.cursor()
    table_names = [
        row.table_name
        for row in cursor.tables(tableType="TABLE")
        if not row.table_name.startswith("MSys")
    ]

    for table in table_names:
        rows = cursor.execute(f"SELECT * FROM [{table}]").fetchall()
        columns = [col[0] for col in cursor.description]

        sqlite_conn.execute(f"DROP TABLE IF EXISTS {quote_ident(table)};")
        ddl_cols = ", ".join(f"{quote_ident(c)} TEXT" for c in columns)
        sqlite_conn.execute(f"CREATE TABLE {quote_ident(table)} ({ddl_cols});")

        insert_cols = ", ".join(quote_ident(c) for c in columns)
        placeholders = ", ".join(["?"] * len(columns))
        insert_sql = f"INSERT INTO {quote_ident(table)} ({insert_cols}) VALUES ({placeholders});"

        for row in rows:
            sqlite_conn.execute(insert_sql, ["" if v is None else str(v) for v in row])

        print(f"Migrated {table}: {len(rows)} rows")

    sqlite_conn.commit()
    sqlite_conn.close()
    access_conn.close()


if __name__ == "__main__":
    main()

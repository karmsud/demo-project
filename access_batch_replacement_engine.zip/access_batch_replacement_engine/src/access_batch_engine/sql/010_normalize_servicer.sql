DROP TABLE IF EXISTS wrk_normalized_servicer;

CREATE TABLE wrk_normalized_servicer AS
SELECT
    TRIM(deal_id) AS deal_id,
    TRIM(loan_id) AS loan_id,
    TRIM(period) AS period,
    CAST(REPLACE(TRIM(current_balance), ',', '') AS REAL) AS current_balance,
    UPPER(TRIM(status)) AS input_status
FROM stg_servicer_file;

DROP TABLE IF EXISTS final_export;

CREATE TABLE final_export AS
SELECT
    deal_id,
    loan_id,
    period,
    printf('%.2f', current_balance) AS current_balance,
    normalized_status AS status,
    CASE
        WHEN current_balance > 0 THEN 'Y'
        ELSE 'N'
    END AS is_active_balance,
    source_value
FROM wrk_joined_sources
ORDER BY deal_id, loan_id;

CREATE TABLE IF NOT EXISTS refdb.ref_status_mapping (
    input_status TEXT PRIMARY KEY,
    normalized_status TEXT NOT NULL
);

INSERT OR IGNORE INTO refdb.ref_status_mapping(input_status, normalized_status)
VALUES
    ('ACTIVE', 'ACTIVE'),
    ('INACTIVE', 'INACTIVE'),
    ('CLOSED', 'INACTIVE');

DROP TABLE IF EXISTS wrk_joined_sources;

CREATE TABLE wrk_joined_sources AS
SELECT
    s.deal_id,
    s.loan_id,
    s.period,
    s.current_balance,
    COALESCE(m.normalized_status, s.input_status) AS normalized_status,
    COALESCE(q.source_value, '') AS source_value
FROM wrk_normalized_servicer s
LEFT JOIN refdb.ref_status_mapping m
    ON s.input_status = m.input_status
LEFT JOIN stg_sqlserver_source q
    ON s.deal_id = q.deal_id
   AND s.loan_id = q.loan_id;

from __future__ import annotations

from pathlib import Path
import shutil


def archive_file(source: Path, archive_dir: Path, job_id: str) -> Path:
    archive_dir.mkdir(parents=True, exist_ok=True)
    target = archive_dir / f"{job_id}_{source.name}"
    shutil.copy2(source, target)
    return target

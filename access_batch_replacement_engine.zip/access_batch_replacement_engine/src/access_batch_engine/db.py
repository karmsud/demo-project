from __future__ import annotations

from pathlib import Path
import sqlite3


def quote_ident(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def connect_sqlite(db_path: Path) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA journal_mode = WAL;")
    return conn


def initialize_runtime_db(conn: sqlite3.Connection) -> None:
    conn.executescript(
        '''
        CREATE TABLE IF NOT EXISTS job_run (
            job_id TEXT PRIMARY KEY,
            started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            completed_at TEXT,
            input_file TEXT NOT NULL,
            output_file TEXT NOT NULL,
            status TEXT NOT NULL,
            message TEXT
        );

        CREATE TABLE IF NOT EXISTS validation_results (
            validation_name TEXT NOT NULL,
            status TEXT NOT NULL,
            message TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS error_records (
            source_table TEXT,
            row_number INTEGER,
            error_message TEXT,
            raw_payload TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        '''
    )
    conn.commit()


def execute_sql_file(conn: sqlite3.Connection, sql_file: Path) -> None:
    sql_text = sql_file.read_text(encoding="utf-8")
    conn.executescript(sql_text)
    conn.commit()


def attach_reference_db(conn: sqlite3.Connection, reference_db_path: Path) -> None:
    reference_db_path.parent.mkdir(parents=True, exist_ok=True)
    conn.execute("ATTACH DATABASE ? AS refdb;", (str(reference_db_path),))
    conn.commit()

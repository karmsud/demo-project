from __future__ import annotations

import sqlite3
from typing import Sequence

from .config import SqlServerConfig
from .db import quote_ident


def _connection_string(config: SqlServerConfig) -> str:
    if config.trusted_connection:
        auth = "Trusted_Connection=yes;"
    else:
        raise ValueError("Non-trusted SQL authentication is not implemented in scaffold.")

    return (
        f"DRIVER={{{config.driver}}};"
        f"SERVER={config.server};"
        f"DATABASE={config.database};"
        f"{auth}"
    )


def load_sql_server_data_to_sqlite(
    runtime_conn: sqlite3.Connection,
    config: SqlServerConfig,
    target_table: str,
    params: Sequence[str] | None = None,
) -> int:
    if not config.enabled:
        runtime_conn.execute(f"DROP TABLE IF EXISTS {quote_ident(target_table)};")
        runtime_conn.execute(
            f"CREATE TABLE {quote_ident(target_table)} (deal_id TEXT, loan_id TEXT, source_value TEXT);"
        )
        runtime_conn.commit()
        return 0

    try:
        import pyodbc
    except ImportError as exc:
        raise RuntimeError("pyodbc is required when sql_server.enabled=true.") from exc

    sql_conn = pyodbc.connect(_connection_string(config))
    cursor = sql_conn.cursor()
    cursor.execute(config.query, params or [])

    columns = [col[0] for col in cursor.description]
    runtime_conn.execute(f"DROP TABLE IF EXISTS {quote_ident(target_table)};")
    ddl_cols = ", ".join(f"{quote_ident(c)} TEXT" for c in columns)
    runtime_conn.execute(f"CREATE TABLE {quote_ident(target_table)} ({ddl_cols});")

    placeholders = ", ".join(["?"] * len(columns))
    column_list = ", ".join(quote_ident(col) for col in columns)
    insert_sql = f"INSERT INTO {quote_ident(target_table)} ({column_list}) VALUES ({placeholders});"

    row_count = 0
    for row in cursor.fetchall():
        runtime_conn.execute(insert_sql, ["" if v is None else str(v) for v in row])
        row_count += 1

    runtime_conn.commit()
    sql_conn.close()
    return row_count

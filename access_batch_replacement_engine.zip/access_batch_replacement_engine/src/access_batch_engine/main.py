from __future__ import annotations

import argparse
from pathlib import Path
import sys
import traceback

from .archive import archive_file
from .config import ensure_config_dirs, load_config
from .db import attach_reference_db, connect_sqlite, initialize_runtime_db
from .exit_codes import ExitCode
from .export_csv import export_table_to_csv
from .ingest_csv import load_csv_to_table, validate_input_file
from .logging_setup import setup_logging
from .sql_server import load_sql_server_data_to_sqlite
from .transform import run_transformations
from .validate import validate_final_table, validate_output_file, record_validation


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Access Batch Replacement Engine")
    parser.add_argument("--job-id", required=True)
    parser.add_argument("--input-file", required=True)
    parser.add_argument("--output-file", required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--deal-id", required=False, default="")
    return parser.parse_args()


def runtime_db_path(runtime_dir: Path, job_id: str) -> Path:
    safe_job_id = "".join(ch if ch.isalnum() or ch in "-_." else "_" for ch in job_id)
    return runtime_dir / f"{safe_job_id}_runtime.sqlite"


def run() -> ExitCode:
    args = parse_args()
    input_file = Path(args.input_file).resolve()
    output_file = Path(args.output_file).resolve()

    try:
        config = load_config(args.config)
        ensure_config_dirs(config)
    except Exception as exc:
        print(f"CONFIG FAILURE: {exc}", file=sys.stderr)
        return ExitCode.CONFIG_FAILURE

    logger = setup_logging(config.paths.log_dir, args.job_id)
    logger.info("Starting job_id=%s", args.job_id)
    logger.info("Input file: %s", input_file)
    logger.info("Output file: %s", output_file)

    conn = None
    try:
        validate_input_file(input_file, config.required_columns, config.csv.encoding)

        db_path = runtime_db_path(config.paths.runtime_dir, args.job_id)
        logger.info("Runtime SQLite DB: %s", db_path)
        conn = connect_sqlite(db_path)
        initialize_runtime_db(conn)
        attach_reference_db(conn, config.paths.reference_db_path)

        conn.execute(
            '''
            INSERT OR REPLACE INTO job_run(job_id, input_file, output_file, status, message)
            VALUES (?, ?, ?, 'RUNNING', NULL);
            ''',
            (args.job_id, str(input_file), str(output_file)),
        )
        conn.commit()

        row_count = load_csv_to_table(
            conn,
            input_file=input_file,
            table_name="stg_servicer_file",
            encoding=config.csv.encoding,
            delimiter=config.csv.delimiter,
        )
        logger.info("Loaded %s servicer rows.", row_count)

        sql_rows = load_sql_server_data_to_sqlite(
            conn,
            config.sql_server,
            target_table="stg_sqlserver_source",
            params=[args.deal_id] if args.deal_id else None,
        )
        logger.info("Loaded %s SQL Server rows.", sql_rows)

        sql_dir = Path(__file__).parent / "sql"
        run_transformations(conn, sql_dir)
        validate_final_table(conn)

        exported = export_table_to_csv(
            conn,
            table_name="final_export",
            output_file=output_file,
            encoding=config.csv.encoding,
            delimiter=config.csv.delimiter,
        )
        logger.info("Exported %s output rows.", exported)

        validate_output_file(output_file)
        record_validation(conn, "output_file_created", "PASS", str(output_file))

        if config.runtime.archive_files:
            archive_file(input_file, config.paths.archive_input_dir, args.job_id)
            archive_file(output_file, config.paths.archive_output_dir, args.job_id)

        conn.execute(
            "UPDATE job_run SET completed_at=CURRENT_TIMESTAMP, status='SUCCESS', message=? WHERE job_id=?;",
            (f"Exported {exported} rows.", args.job_id),
        )
        conn.commit()
        logger.info("Job completed successfully.")
        return ExitCode.SUCCESS

    except FileNotFoundError as exc:
        logger.error("Input/output file issue: %s", exc)
        return ExitCode.INPUT_FILE_MISSING
    except ValueError as exc:
        logger.error("Validation or schema failure: %s", exc)
        return ExitCode.INPUT_SCHEMA_MISMATCH
    except Exception as exc:
        logger.error("Unhandled failure: %s", exc)
        logger.error(traceback.format_exc())
        return ExitCode.GENERAL_FAILURE
    finally:
        if conn:
            conn.close()


def main() -> None:
    sys.exit(int(run()))


if __name__ == "__main__":
    main()

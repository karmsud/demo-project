from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json


@dataclass(frozen=True)
class PathConfig:
    runtime_dir: Path
    log_dir: Path
    archive_input_dir: Path
    archive_output_dir: Path
    reference_db_path: Path


@dataclass(frozen=True)
class CsvConfig:
    delimiter: str
    encoding: str
    has_header: bool


@dataclass(frozen=True)
class SqlServerConfig:
    enabled: bool
    driver: str
    server: str
    database: str
    trusted_connection: bool
    query: str


@dataclass(frozen=True)
class RuntimeConfig:
    job_db_mode: str
    fail_on_validation_diff: bool
    archive_files: bool


@dataclass(frozen=True)
class AppConfig:
    app_name: str
    environment: str
    paths: PathConfig
    csv: CsvConfig
    required_columns: list[str]
    sql_server: SqlServerConfig
    runtime: RuntimeConfig


def _resolve_path(raw_path: str, base_dir: Path) -> Path:
    path = Path(raw_path)
    if path.is_absolute():
        return path
    return (base_dir / path).resolve()


def load_config(config_path: str | Path) -> AppConfig:
    config_file = Path(config_path).resolve()
    base_dir = config_file.parents[1] if config_file.parent.name == "config" else Path.cwd()

    with config_file.open("r", encoding="utf-8") as f:
        raw = json.load(f)

    paths_raw = raw["paths"]
    paths = PathConfig(
        runtime_dir=_resolve_path(paths_raw["runtime_dir"], base_dir),
        log_dir=_resolve_path(paths_raw["log_dir"], base_dir),
        archive_input_dir=_resolve_path(paths_raw["archive_input_dir"], base_dir),
        archive_output_dir=_resolve_path(paths_raw["archive_output_dir"], base_dir),
        reference_db_path=_resolve_path(paths_raw["reference_db_path"], base_dir),
    )

    return AppConfig(
        app_name=raw["app_name"],
        environment=raw["environment"],
        paths=paths,
        csv=CsvConfig(**raw["csv"]),
        required_columns=raw["input_schema"]["required_columns"],
        sql_server=SqlServerConfig(**raw["sql_server"]),
        runtime=RuntimeConfig(**raw["runtime"]),
    )


def ensure_config_dirs(config: AppConfig) -> None:
    for path in [
        config.paths.runtime_dir,
        config.paths.log_dir,
        config.paths.archive_input_dir,
        config.paths.archive_output_dir,
        config.paths.reference_db_path.parent,
    ]:
        path.mkdir(parents=True, exist_ok=True)

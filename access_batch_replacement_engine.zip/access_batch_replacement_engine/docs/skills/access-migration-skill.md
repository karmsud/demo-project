# Skill: Access Migration

Use this skill when reverse-engineering Access tables, queries, and macros.

## Inventory

Capture:
- local tables
- linked tables
- saved queries
- macros
- VBA modules
- export path
- output column list
- expected row count

## Translation

Translate Access concepts:

```text
IIf        -> CASE WHEN
Nz         -> COALESCE
Date       -> current date logic
Format     -> strftime or Python formatting
Left/Right -> substr
&          -> ||
True/False -> 1/0
```

## Runtime decision

Do not keep Access in production runtime.

Use Access only to:
- inspect legacy logic
- export baseline CSV
- migrate reference tables
- validate parity

## Linked SQL tables

Prefer direct SQL Server query from Python instead of reading linked tables through Access.

## Parity

Never trust visual similarity.
Compare actual CSV outputs field by field.

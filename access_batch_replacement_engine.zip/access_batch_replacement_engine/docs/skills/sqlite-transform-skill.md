# Skill: SQLite Transformation

Use this skill when editing `src/access_batch_engine/sql/*.sql`.

## Rules

- Every script must be rerunnable.
- Drop and recreate work tables.
- Preserve explicit column names.
- Preserve explicit output order.
- Use `COALESCE` instead of Access `Nz`.
- Use `CASE WHEN` instead of Access `IIf`.
- Use `substr` instead of Access `Left`, `Right`, `Mid`.
- Use `||` for string concatenation.
- Use `strftime` for date formatting when needed.

## Table naming

Use prefixes:
- `stg_` for raw staging
- `wrk_` for intermediate work
- `refdb.` for reference tables
- `final_` for export-ready output

## Output

Only `final_export` should be exported.
The final SQL script controls column order and formatting.

## Review checklist

- Are casts intentional?
- Are joins left/inner exactly like Access?
- Are nulls handled?
- Is sort order deterministic?
- Are duplicate rows expected?

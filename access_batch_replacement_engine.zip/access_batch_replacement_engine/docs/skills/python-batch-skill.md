# Skill: Python Batch Engineering

Use this skill when editing `src/access_batch_engine/*.py`.

## Goals

- Keep modules small.
- Keep `main.py` orchestration-only.
- Use explicit exit codes.
- Make failures clear in logs.
- Preserve Windows path compatibility.

## Patterns

Use:
- `argparse` for CLI.
- `pathlib.Path` for paths.
- `logging` for logs.
- `sqlite3` for runtime DB.
- `csv` for deterministic CSV ingest/export.

Avoid:
- hidden global state
- hardcoded M drive paths
- silent exception swallowing
- UI dependencies
- implicit current working directory assumptions

## Error handling

Map known failures:
- missing input file -> input file exit code
- schema mismatch -> schema exit code
- SQL Server failure -> SQL exit code
- output write issue -> output exit code
- validation failure -> validation exit code

## Testing

Add or update tests when changing:
- config shape
- CLI behavior
- CSV schema logic
- SQL transformation assumptions

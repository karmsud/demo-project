# Skill: Batch Operations

Use this skill for scheduler integration and unattended execution.

## Command contract

Required:
- job id
- input file
- output file
- config file

Optional:
- deal id
- processing period

## Exit codes

Scheduler must receive:
- 0 success
- non-zero failure

Do not print success if exit code is non-zero.

## Logging

Each job writes:

```text
logs/{job_id}.log
```

Log:
- input path
- output path
- runtime DB path
- row counts
- validation results
- failure trace

## Reruns

A rerun with same job id should not corrupt another job.
Prefer a unique job id per run.

## Network drive caution

Do not assume network drive availability.
Fail clearly when M drive paths are unavailable.

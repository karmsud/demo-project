# Skill: Testing and Validation

Use this skill when adding tests or parity checks.

## Minimum tests

- config loads
- sample CSV validates
- missing column fails
- CSV loads to SQLite
- final CSV is created
- final_export has rows

## Parity validation

Compare Python output to Access baseline:

- same columns
- same column order
- same row count
- same values after agreed formatting
- same sort order

## Mismatch reporting

When differences exist, generate:
- summary counts
- missing rows
- extra rows
- changed fields

## Test data

Keep sample files small.
Do not commit confidential production files.

## Rule

A transformation change is not complete until it has a test or a documented validation path.

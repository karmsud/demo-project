# Project Setup

## Prerequisites

- Windows workstation or batch server.
- Python 3.10+.
- VS Code.
- GitHub Copilot / Copilot Chat.
- Optional: SQL Server ODBC Driver.
- Optional: Microsoft Access Database Engine for migration scripts.

## Setup

```powershell
cd access_batch_replacement_engine
.\scripts\setup.ps1
```

## Run sample job

```powershell
.\scripts\run_local.ps1
```

Expected output:

```text
data/output/sample_output.csv
```

## Run tests

```powershell
.\.venv\Scripts\pytest.exe
```

## Build executable

```powershell
.\scripts\build_exe.ps1
```

## Run from batch file

```bat
scripts\run_job.bat LOCAL_TEST_002 data\input\sample_servicer_file.csv data\output\sample_output_2.csv config\appsettings.local.json
```

## Configure enterprise path

Copy:

```text
config/appsettings.usbank.template.json
```

to an environment-specific file and replace:
- runtime folder
- log folder
- archive folders
- reference DB path
- SQL Server connection
- SQL query
- required input columns

Do not hardcode enterprise paths in Python.

# Repository Instructions

## Development style

This project uses small-file, spec-driven, AI-native development.

## Context discipline

Do not ask Copilot to load the whole repo.
Use the smallest relevant files:
- one spec file
- one skill file
- one target code file
- one test file

## Branching

Suggested branches:
- `feature/csv-ingest`
- `feature/sql-transform`
- `feature/sql-server-load`
- `feature/parity-validation`
- `feature/pyinstaller-build`

## Commit style

Use small commits:
- scaffold config loader
- add CSV staging
- add transformation SQL
- add output export
- add baseline comparison

## Confidentiality

Never commit:
- real servicer data
- production output files
- real connection strings
- passwords
- internal server names
- confidential Access databases

## Review checklist

Before merging:
- local run works
- tests pass
- logs are useful
- no hardcoded enterprise path
- output columns are deterministic
- exit code behavior is preserved

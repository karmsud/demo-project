# Implementation Prompts

Use one prompt at a time. Do not load every prompt file.

## Prompt 1: Understand scaffold

Read `README.md`, `.github/copilot-instructions.md`, and `docs/sdd/spec.md`.
Summarize the project goal, runtime flow, and non-negotiable constraints.
Do not modify code yet.

## Prompt 2: Implement one module

Read `docs/skills/python-batch-skill.md` and the target Python file.
Improve only the target module.
Preserve CLI contract and exit-code behavior.
Add or update tests if logic changes.

## Prompt 3: Add transformation step

Read `docs/skills/sqlite-transform-skill.md`.
Add one SQL transform script after the current last numbered script.
Update `transform.py` ordered script list.
Add a test or validation note.

## Prompt 4: Prepare enterprise config

Read `config/appsettings.usbank.template.json`.
Ask me for missing server, database, query, and path values.
Do not invent enterprise values.

## Prompt 5: Package executable

Read `scripts/build_exe.ps1`.
Confirm PyInstaller includes SQL scripts.
Fix packaging only if the executable cannot find SQL files.

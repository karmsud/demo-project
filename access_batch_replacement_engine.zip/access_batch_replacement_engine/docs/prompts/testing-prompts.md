# Testing Prompts

## Prompt 1: Unit test module

Read the target module and `docs/skills/testing-skill.md`.
Create focused pytest tests.
Do not add production dependencies unless necessary.

## Prompt 2: End-to-end local test

Create a pytest that runs the sample pipeline using local config.
Assert that output CSV exists and has expected columns.

## Prompt 3: Failure behavior

Add tests for:
- missing input file
- missing required column
- empty CSV
- invalid config path

Confirm exit codes match `exit_codes.py`.

## Prompt 4: Validation enhancement

Improve validation to write a concise mismatch report.
Keep sensitive data out of test fixtures.

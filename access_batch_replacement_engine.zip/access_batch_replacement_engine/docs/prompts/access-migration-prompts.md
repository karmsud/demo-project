# Access Migration Prompts

## Prompt 1: Inventory Access DB

I have an Access `.accdb` with local tables, linked SQL tables, queries, and macros.
Create a Python inventory script that lists tables, columns, saved queries if available, and linked table metadata.
Use Windows/pyodbc-compatible code.

## Prompt 2: Translate Access SQL

Translate this Access SQL to SQLite SQL.
Preserve joins, filters, calculated columns, aliases, output order, and null handling.
Call out every Access-specific function and its SQLite equivalent.

## Prompt 3: Migrate reference tables

Update `migrate_access_reference.py` so it migrates selected local Access tables to `reference.sqlite`.
Add include/exclude table filters.
Do not migrate system tables.

## Prompt 4: Build parity comparison

Create a script that compares Access baseline CSV and Python output CSV.
Compare columns, row count, order, and field-level values.
Write mismatch report to CSV.

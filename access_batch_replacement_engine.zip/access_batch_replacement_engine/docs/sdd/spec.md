# Spec: Access Batch Replacement Engine

## Problem

A legacy Microsoft Access database contains local tables, linked SQL data, query logic, and a macro that exports a CSV to a network drive. Access is difficult to integrate into unattended production workflows.

## Goal

Build a self-contained, unattended Python batch engine that reproduces the Access macro output CSV.

## In scope

- Windows-first Python project.
- CLI executable called by Active Batch or similar queue.
- Input servicer CSV file path is provided at runtime.
- Output CSV file path is provided at runtime.
- SQLite runtime DB is created per job.
- Migrated Access reference tables are read from SQLite.
- Optional SQL Server source data is pulled during run.
- Final output is exported as CSV.
- Explicit exit codes are returned to scheduler.
- Logs and runtime audit tables are written.

## Out of scope

- Web app.
- UI.
- React/Vite.
- Multi-user database.
- Human access to SQLite.
- Rebuilding Access forms.
- Keeping Access as runtime dependency.

## Success criteria

- Output CSV matches Access macro baseline.
- Process runs unattended.
- Scheduler receives reliable exit code.
- Paths are config/argument driven.
- Job can be rerun without corrupting prior runs.
- Logs clearly explain success/failure.

## Key design decision

SQLite is not an enterprise database here. It is an embedded private runtime store used only by the executable.

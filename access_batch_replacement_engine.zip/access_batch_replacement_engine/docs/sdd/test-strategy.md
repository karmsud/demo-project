# Test Strategy

## Unit tests

Test:
- config loading
- input schema validation
- CSV ingest
- transformation SQL
- export file creation

## Integration test

Use sample input CSV and local config.

Expected command:

```powershell
.\scripts\run_local.ps1
```

Expected result:

```text
data/output/sample_output.csv
```

## Access parity test

When baseline is available:

1. Run Access macro manually.
2. Save baseline CSV to `data/baseline/`.
3. Run Python engine.
4. Compare:
   - column names
   - column order
   - row count
   - exact field values
   - output sort order

## Failure tests

Test:
- missing input file
- missing required column
- invalid output path
- SQL Server disabled
- SQL Server connection failure
- empty final output

## Scheduler test

Confirm `.bat` or `.exe` returns expected `%ERRORLEVEL%`.

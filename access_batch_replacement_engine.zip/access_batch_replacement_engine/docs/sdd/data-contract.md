# Data Contract

## Input CSV

Default required columns:

```text
deal_id
loan_id
period
current_balance
status
```

Update `config/appsettings.*.json` when the real file is known.

## Staging table

Input file loads into:

```text
stg_servicer_file
```

All fields are initially loaded as TEXT to avoid lossy ingest.

## Normalized work table

`wrk_normalized_servicer` casts, trims, and standardizes fields.

## SQL Server staging table

Optional table:

```text
stg_sqlserver_source
```

Expected scaffold columns:

```text
deal_id
loan_id
source_value
```

Replace with real source query and columns.

## Reference tables

Access-derived reference tables belong in:

```text
refdb.*
```

Examples:
- `ref_status_mapping`
- deal mapping tables
- threshold tables
- export layout tables

## Final output

`final_export` is the only table exported to CSV.
Column order and formatting are defined in `030_create_final_export.sql`.

# Implementation Plan

## Phase 1: Scaffold

- Create package layout.
- Add config loading.
- Add CLI arguments.
- Add logging.
- Add exit codes.
- Add local run script.

## Phase 2: CSV pipeline

- Validate input file exists.
- Validate required columns.
- Load input CSV into SQLite staging table.
- Add tests for schema validation.

## Phase 3: Runtime DB

- Create job-specific SQLite file.
- Create job_run, validation_results, error_records.
- Attach reference DB.
- Use ordered SQL transformations.

## Phase 4: SQL Server optional load

- Add config toggle.
- Use trusted Windows auth.
- Load SQL query result into staging table.
- Fail clearly on connection/query issues.

## Phase 5: Export

- Export `final_export` to CSV.
- Preserve column order.
- Add output existence and non-empty validation.
- Return exit code 0 on success.

## Phase 6: Packaging

- Add PyInstaller build script.
- Confirm SQL files are bundled.
- Test exe invocation from PowerShell and .bat.

## Phase 7: Parity

- Capture Access macro baseline CSV.
- Compare baseline vs Python output.
- Generate mismatch report.
- Fix transforms until parity is achieved.

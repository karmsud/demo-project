# Architecture Decisions

## ADR-001: No UI

Decision: No web app, no UI, no React.

Reason: This is an unattended batch job. UI would add cost and operational risk.

## ADR-002: SQLite per job

Decision: Create one runtime SQLite DB per job.

Reason: Avoids concurrency issues and preserves job audit trail.

## ADR-003: CSV is official output

Decision: Final business artifact is CSV, not SQLite.

Reason: Downstream process expects file output.

## ADR-004: Access not used at runtime

Decision: Access is used only for migration/reverse engineering.

Reason: Production workflows should not depend on Access macros/forms.

## ADR-005: SQL transforms over hardcoded Python

Decision: Business joins/calculations should be SQL-first where practical.

Reason: Easier parity with Access queries and easier review by data analysts.

## ADR-006: Config over hardcoding

Decision: Enterprise paths and source settings live in JSON config.

Reason: Same executable should run in local, test, and production.

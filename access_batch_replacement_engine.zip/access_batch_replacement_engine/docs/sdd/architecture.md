# Architecture

## Runtime flow

```text
Scheduler
  -> EXE / Python CLI
  -> Validate input CSV
  -> Create job SQLite DB
  -> Load CSV into stg_servicer_file
  -> Attach reference SQLite DB
  -> Optionally load SQL Server table
  -> Run ordered SQL transforms
  -> Validate final_export
  -> Export output CSV
  -> Archive optional files
  -> Return exit code
```

## Runtime database strategy

Use one SQLite DB per job:

```text
runtime/{job_id}_runtime.sqlite
```

Benefits:
- avoids concurrent write collisions
- keeps audit trail by job
- supports rerun analysis
- avoids shared mutable state

## Reference database

Migrated Access local/static tables live in:

```text
reference/reference.sqlite
```

The runtime DB attaches it as:

```sql
ATTACH DATABASE 'reference.sqlite' AS refdb;
```

## Transformation strategy

Use ordered SQL scripts:

```text
001_create_reference_defaults.sql
010_normalize_servicer.sql
020_join_sources.sql
030_create_final_export.sql
```

Each script should be deterministic and idempotent.

## Output strategy

The final CSV is exported from `final_export`.
Column order is controlled by `030_create_final_export.sql`.
Sort order must be explicit.

from access_batch_engine.config import load_config


def test_load_local_config():
    config = load_config("config/appsettings.local.json")
    assert config.app_name == "AccessBatchReplacement"
    assert "deal_id" in config.required_columns

from pathlib import Path
import sys

from access_batch_engine import main as app_main


def test_end_to_end_local(monkeypatch, tmp_path):
    output_file = tmp_path / "output.csv"
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "prog",
            "--job-id",
            "PYTEST_E2E",
            "--input-file",
            "data/input/sample_servicer_file.csv",
            "--output-file",
            str(output_file),
            "--config",
            "config/appsettings.local.json",
        ],
    )

    code = app_main.run()
    assert int(code) == 0
    assert output_file.exists()
    assert "loan_id" in output_file.read_text(encoding="utf-8-sig")

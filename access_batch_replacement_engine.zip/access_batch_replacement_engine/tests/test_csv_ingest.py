import sqlite3
from pathlib import Path

from access_batch_engine.ingest_csv import load_csv_to_table, validate_input_file


def test_load_sample_csv(tmp_path):
    input_file = Path("data/input/sample_servicer_file.csv")
    required = ["deal_id", "loan_id", "period", "current_balance", "status"]
    header = validate_input_file(input_file, required, "utf-8-sig")
    assert "loan_id" in header

    conn = sqlite3.connect(tmp_path / "test.sqlite")
    rows = load_csv_to_table(conn, input_file, "stg_servicer_file", "utf-8-sig", ",")
    assert rows == 3

$ErrorActionPreference = "Stop"

$JobId = "LOCAL_TEST_001"
$InputFile = ".\data\input\sample_servicer_file.csv"
$OutputFile = ".\data\output\sample_output.csv"
$Config = ".\config\appsettings.local.json"

& .\.venv\Scripts\python.exe -m access_batch_engine.main `
  --job-id $JobId `
  --input-file $InputFile `
  --output-file $OutputFile `
  --config $Config

exit $LASTEXITCODE

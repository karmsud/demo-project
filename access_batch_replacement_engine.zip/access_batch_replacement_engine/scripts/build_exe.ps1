$ErrorActionPreference = "Stop"

& .\.venv\Scripts\pyinstaller.exe `
  --onefile `
  --name AccessBatchReplacement `
  --paths ".\src" `
  --add-data "src\access_batch_engine\sql;access_batch_engine\sql" `
  ".\src\access_batch_engine\main.py"

Write-Host "Build complete: .\dist\AccessBatchReplacement.exe"

@echo off
setlocal

set JOB_ID=%~1
set INPUT_FILE=%~2
set OUTPUT_FILE=%~3
set CONFIG_FILE=%~4

if "%JOB_ID%"=="" (
  echo Usage: run_job.bat JOB_ID INPUT_FILE OUTPUT_FILE CONFIG_FILE
  exit /b 8
)

.\.venv\Scripts\python.exe -m access_batch_engine.main ^
  --job-id "%JOB_ID%" ^
  --input-file "%INPUT_FILE%" ^
  --output-file "%OUTPUT_FILE%" ^
  --config "%CONFIG_FILE%"

exit /b %ERRORLEVEL%

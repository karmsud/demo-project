# Access Batch Replacement Engine

A Windows-first, unattended Python batch engine that replaces a legacy Microsoft Access macro export workflow.

The engine:
- Accepts an input servicer CSV file from an enterprise batch queue.
- Creates a job-specific SQLite runtime database.
- Loads CSV data into staging tables.
- Loads migrated Access reference/static tables from SQLite.
- Optionally pulls current source data from SQL Server.
- Runs deterministic SQL/Python transformation logic.
- Saves final/audit data into SQLite.
- Exports a CSV output file.
- Returns explicit exit codes for Active Batch or any scheduler.

This is not a web app and has no user interface. SQLite is private embedded runtime state for the executable.

## Fast start on Windows

```powershell
cd access_batch_replacement_engine
.\scripts\setup.ps1
.\scripts\run_local.ps1
```

## Example batch invocation

```powershell
.\.venv\Scripts\python.exe -m access_batch_engine.main `
  --job-id "LOCAL_TEST_001" `
  --input-file ".\data\input\sample_servicer_file.csv" `
  --output-file ".\data\output\sample_output.csv" `
  --config ".\config\appsettings.local.json"
```

## Build executable

```powershell
.\scripts\build_exe.ps1
```

Output:

```text
dist\AccessBatchReplacement.exe
```

## Repository map

```text
src/access_batch_engine/   Application code
src/access_batch_engine/sql Transformation SQL scripts
config/                    Runtime configuration
scripts/                   Windows setup, run, build scripts
docs/sdd/                  Spec-driven development artifacts
docs/agents/               Agent role guidance for Copilot Chat
docs/skills/               Compact skill files for Copilot
docs/prompts/              Prompt library split by task
tests/                     Pytest tests
data/                      Local sample input/output/runtime/log folders
```

## Exit codes

See `src/access_batch_engine/exit_codes.py`.

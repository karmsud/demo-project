# Agent Routing Guide

Use this file as a lightweight map for Copilot Chat agent-style work.

## Agent 1: Batch Architect

Owns:
- command-line contract
- exit codes
- folder strategy
- scheduler integration
- idempotency and reruns

Read:
- `docs/sdd/spec.md`
- `docs/sdd/architecture.md`
- `docs/skills/batch-operations-skill.md`

## Agent 2: Python Engineer

Owns:
- Python modules
- config loading
- logging
- SQLite lifecycle
- CSV ingest/export
- tests

Read:
- `docs/sdd/plan.md`
- `docs/skills/python-batch-skill.md`
- `docs/skills/testing-skill.md`

## Agent 3: Data Migration Engineer

Owns:
- Access schema extraction
- reference table migration
- Access SQL to SQLite SQL translation
- parity validation

Read:
- `docs/sdd/data-contract.md`
- `docs/skills/access-migration-skill.md`
- `docs/skills/sqlite-transform-skill.md`

## Agent 4: QA / Validation Engineer

Owns:
- baseline Access output comparison
- row count checks
- column order checks
- reconciliation output
- negative tests

Read:
- `docs/sdd/test-strategy.md`
- `docs/skills/testing-skill.md`

## Working rule

Do not load all agent and skill files together.
Pick the smallest role-specific set.

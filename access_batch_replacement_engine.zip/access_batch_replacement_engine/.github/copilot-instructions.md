# Copilot Instructions

You are assisting with a Windows-first Python batch application.

## Mission

Replace a legacy Microsoft Access macro export workflow with an unattended Python/SQLite executable.

## Non-negotiables

- No web app.
- No React/Vite.
- No UI.
- No cloud database.
- SQLite is private runtime state used only by this job.
- Output CSV is the official artifact.
- Batch scheduler compatibility is mandatory.
- Windows PowerShell and `.bat` examples first.
- Keep files small and modular.

## Architecture

Active Batch or scheduler calls an executable with:
- job id
- input servicer CSV path
- output CSV path
- config path
- optional deal id

The executable:
1. Loads config.
2. Validates input CSV.
3. Creates job-specific SQLite runtime DB.
4. Loads CSV into staging.
5. Optionally queries SQL Server.
6. Runs ordered SQL transformations.
7. Writes final table.
8. Exports CSV.
9. Logs all key steps.
10. Returns explicit exit code.

## Coding rules

- Use stdlib where practical.
- Use `pyodbc` only for Access/SQL Server connectivity.
- Keep transformation SQL in `src/access_batch_engine/sql/`.
- Keep business rules outside `main.py`.
- Never hardcode enterprise paths in Python.
- Use config or command-line args.
- Make failure modes explicit.
- Preserve deterministic output order.
- Add tests for schema validation and transformations.

## Context-window rule

Read only the smallest relevant file first.
Prefer these entry points:
- `docs/sdd/spec.md`
- `docs/sdd/plan.md`
- `docs/prompts/implementation-prompts.md`
- `docs/skills/python-batch-skill.md`

Avoid loading every markdown file at once.

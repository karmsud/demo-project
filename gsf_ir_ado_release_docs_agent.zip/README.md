# GSF IR ADO Release Docs Agent

This scaffold is for **Use Case #2**:

> The user provides CSV exports from Azure DevOps (ADO) / TFS.  
> The agent consumes them and generates documentation:
> - A **knowledge base document** (structured SDLC view),
> - A **technical document for developers**, and
> - An **end‑user release notes document**.

There is **no Q&A chatbot** here. This is a **pure analyzer / document generator agent**.
All logic lives in pre‑written Python scripts; the agent only runs those scripts.

---

## 1. Folder layout

After unzipping you’ll see:

```text
gsf_ir_ado_release_docs_agent/
  requirements.txt
  README.md

  data/
    ado/
      raw/
        # <-- you drop ADO/TFS CSV exports here
        # e.g. ado_export_release_2026_01.csv

  scripts/
    generate_release_docs.py   # main script to build all 3 docs

  .github/
    AGENTS.md
    agents/
      gsf-ir-ado-release-docs.agent.md
    skills/
      ado-release-docs/
        SKILL.md
        data/
          kb_sdlc.md             # generated knowledge base doc
          dev_technical_notes.md # generated technical dev doc
          release_notes_user.md  # generated end‑user release notes
    prompts/
      generate-ado-release-docs.prompt.md
```

You do **not** need any embeddings, graphs, or extra services.  
Everything is simple pandas‑based grouping and formatting.

---

## 2. One‑time Python setup

From the repo root in PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

---

## 3. CSV expectations (ADO / TFS exports)

The script expects your CSV exports to contain (or be mappable to) columns like:

- `ID`
- `Title`
- `Work Item Type`
- `State`
- `Area Path`
- `Iteration Path`   (used as “release / sprint / iteration name”)
- `Tags`
- `Description`      (or similar text / acceptance criteria)

If some columns are missing, the script will create them as empty strings, but the
more you provide, the better the docs.

Put your exported CSV files under:

- `data/ado/raw/`

Examples:

- `data/ado/raw/ado_export_release_2026_01.csv`
- `data/ado/raw/ado_export_release_2026_02.csv`

You can use one file per release or multiple; the script will filter by release name.

---

## 4. Script: generate_release_docs.py

This is the **only** script you (or the agent) need to call.

It:

1. Loads all CSV files matching an input glob.
2. Optionally **filters** to rows whose `Iteration Path` contains a given release name.
3. Generates three Markdown docs:

   - `kb_sdlc.md`
     - Structured knowledge base, grouped by `Iteration Path` then work item.
   - `dev_technical_notes.md`
     - Developer‑oriented change log, grouped by `Area Path` and `Work Item Type`.
   - `release_notes_user.md`
     - End‑user release notes, grouped by category: Features, Bug Fixes, Other Changes.

### CLI interface

From repo root (venv active):

```powershell
python scripts\generate_release_docs.py `
  --input-glob "data/ado/raw/*.csv" `
  --release-name "2026.01" `
  --out-kb .github/skills/ado-release-docs/data/kb_sdlc.md `
  --out-dev .github/skills/ado-release-docs/data/dev_technical_notes.md `
  --out-user .github/skills/ado-release-docs/data/release_notes_user.md
```

- `--input-glob` (required): glob for CSV exports.
- `--release-name` (optional but recommended):
  - If provided, only rows whose `Iteration Path` contains this string (case‑insensitive)
    are used.
  - If omitted, **all** rows are used, and the docs will contain multiple releases.
- The three `--out-*` paths are where the Markdown docs are written.

---

## 5. What each document looks like

### 5.1 Knowledge base: kb_sdlc.md

- Top level: `# SDLC Knowledge Base – <Release Name or All Releases>`
- Groups by `Iteration Path`:

  ```md
  ## Release: ProjectX\Release 2026.01

  ### [1234] Add new payment API
  - Work Item Type: User Story
  - State: Done
  - Area: ProjectX\Payments
  - Tags: Payments; API

  Detailed description text...
  ```

This is your “everything in one place” SDLC view — good for PMs, leads,
and as an internal KB.

### 5.2 Developer technical doc: dev_technical_notes.md

- Top level: `# Technical Change Log – <Release Name>`
- Groups by `Area Path`, then by `Work Item Type`:

  ```md
  ## Area: ProjectX\Payments

  ### User Story
  - [1234] Add new payment API (State: Done; Tags: Payments; API)
  - [1250] Enhance fraud checks (State: In Progress; Tags: Fraud)

  ### Bug
  - [1301] Fix timeout issue in capture flow (State: Resolved; Tags: Timeout)
  ```

This is optimized for developers: see what changed in each subsystem, by type.

### 5.3 End‑user release notes: release_notes_user.md

- Top: `# Release Notes – <Release Name>`
- Sections:

  ```md
  ## New Features / Enhancements
  - [1234] Add new payment API
  - [1250] Enhance fraud checks

  ## Bug Fixes
  - [1301] Fix timeout issue in payment capture

  ## Other Changes
  - [1400] Refactor internal logging framework
  ```

This is what you can lightly polish and send to stakeholders / end users.

---

## 6. VS Code + GitHub Copilot Agent wiring

This repo also contains a Copilot **agent** and a **skill** so you can run this
via VS Code chat instead of remembering CLI commands.

### 6.1 Enable skills & agents

In VS Code settings (JSON):

```json
{
  "chat.useAgentSkills": true,
  "chat.useAgentsMdFile": true
}
```

### 6.2 Agent: GSF IR ADO Release Docs Agent

Defined in:

- `.github/agents/gsf-ir-ado-release-docs.agent.md`

Behavior:

- Asks you:
  - Where your CSVs live (glob),
  - The release name string (e.g., `2026.01` or `ProjectX\Release 2026.01`).
- Uses the `ado-release-docs` skill to run `generate_release_docs.py`.
- Once docs are generated, it can:
  - Open and summarize `kb_sdlc.md`,
  - Open and summarize `dev_technical_notes.md`,
  - Open and present `release_notes_user.md` (for you to copy‑paste out).

### 6.3 Skill: ado-release-docs

Defined in:

- `.github/skills/ado-release-docs/SKILL.md`

It tells Copilot **exactly** how to:

- Run `generate_release_docs.py` from the terminal.
- Use the output docs as the source of truth.
- Respect the rule: *never write or modify Python; only call the script*.

### 6.4 Prompt: generate-ado-release-docs

Defined in:

- `.github/prompts/generate-ado-release-docs.prompt.md`

You’ll call this from chat as `/generate-ado-release-docs` with the
**GSF IR ADO Release Docs Agent** selected. It will:

1. Ask for:
   - CSV glob (default `data/ado/raw/*.csv`),
   - Release name string.
2. Run the script.
3. Show you where the docs were generated and optionally paste summaries.

---

## 7. Typical usage flow (end‑to‑end)

1. **Export from ADO/TFS**  
   Use the ADO UI to export relevant work items (for a release or period) to CSV.

2. **Save CSVs**  
   Save them under: `data/ado/raw/` in this repo.

3. **Open repo in VS Code**  
   Ensure venv is active, dependencies installed.

4. **Generate docs via CLI (optional first time)**  

   ```powershell
   python scripts\generate_release_docs.py `
     --input-glob "data/ado/raw/*.csv" `
     --release-name "2026.01" `
     --out-kb .github/skills/ado-release-docs/data/kb_sdlc.md `
     --out-dev .github/skills/ado-release-docs/data/dev_technical_notes.md `
     --out-user .github/skills/ado-release-docs/data/release_notes_user.md
   ```

5. **Generate docs via Copilot Agent**  

   - Select **GSF IR ADO Release Docs Agent** in Copilot Chat.
   - Run `/generate-ado-release-docs`.
   - Answer its questions (glob + release name).
   - Let it run the script and then show you the docs.

6. **Publish**  
   - Use `kb_sdlc.md` inside your internal KB / Confluence.
   - Use `dev_technical_notes.md` for dev-facing documentation.
   - Use `release_notes_user.md` for end‑user / stakeholder updates.

That’s it – no Q&A, no embeddings, just a deterministic document‑generator pipeline.

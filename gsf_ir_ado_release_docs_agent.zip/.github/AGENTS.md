# Global agent instructions

This repository contains **read‑only analyzer agents**.

- Agents must not write or modify Python code.
- Agents must not call external web APIs or browse the internet.
- All outputs must be derived from ADO/TFS CSV exports under `data/ado/raw/`
  and the generated Markdown docs under `.github/skills/ado-release-docs/data/`.

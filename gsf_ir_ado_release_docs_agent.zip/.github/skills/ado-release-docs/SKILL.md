---
name: ado-release-docs
description: >
  Use this skill to analyze ADO/TFS CSV exports and generate three Markdown
  documents: a knowledge base, a technical dev doc, and end‑user release notes.
---

# ADO Release Docs Skill

This skill wraps the script `scripts/generate_release_docs.py`.

It generates three documents, given CSV exports from Azure DevOps / TFS:

- `kb_sdlc.md` – SDLC knowledge base (grouped by iteration and work item),
- `dev_technical_notes.md` – technical change log for developers,
- `release_notes_user.md` – end‑user release notes.

Artifacts live under:

- Raw CSVs: `data/ado/raw/*.csv`
- Output docs: `.github/skills/ado-release-docs/data/*.md`

## Strict rules

- Do **not** write or modify Python code. Only call the existing script.
- Do **not** use web search; only use the CSV data and generated docs.
- When there is a conflict between your own reasoning and the script output,
  always defer to the script output.

## Workflow – generate docs

Use this when a user has exported CSVs and wants documentation.

1. Ask the user for:
   - The CSV glob pattern (default: `data/ado/raw/*.csv`),
   - The release name string, if they want to filter (e.g. `2026.01` or
     `ProjectX\Release 2026.01`).

2. Use the `terminal` tool to run:

   ```bash
   python scripts/generate_release_docs.py ^
     --input-glob "data/ado/raw/*.csv" ^
     --release-name "<release name or leave empty>" ^
     --out-kb .github/skills/ado-release-docs/data/kb_sdlc.md ^
     --out-dev .github/skills/ado-release-docs/data/dev_technical_notes.md ^
     --out-user .github/skills/ado-release-docs/data/release_notes_user.md
   ```

   - If the user wants **all releases**, omit `--release-name`.

3. After the command completes, open the generated Markdown files and:

   - Confirm to the user that the docs were created,
   - Offer to summarize or highlight key points,
   - Paste relevant sections (especially from `release_notes_user.md`) into chat
     when asked.

## Usage patterns

- When the user says “I’ve exported the latest release from ADO, help me
  generate release notes”:
  - Ask for release name string and confirm CSV location.
  - Run the script as above.
  - Present `release_notes_user.md` as their release notes draft.

- When the user wants a more detailed, technical picture for developers:
  - Use `dev_technical_notes.md` as the primary source.
  - Optionally reference `kb_sdlc.md` when they need more context.

- When the user wants a full knowledge base:
  - Point them to `kb_sdlc.md` and optionally summarize sections.

# GSF IR Release Notes Agent

This scaffold defines a **GSF IR Release Notes Agent** for VS Code + GitHub Copilot.

High-level:

- You export SDLC work items (stories, epics, bugs) from Azure DevOps / TFS to CSV.
- Drop those CSVs into `data/sdlc/raw/`.
- Run `scripts/build_sdlc_kb.py` to build:
  - `sdlc_enhanced.md` (Markdown KB),
  - `sdlc_embeddings.json` (semantic index),
  - `sdlc_graph.json` (NetworkX graph with metadata).
- The agent:
  - Answers release / scope questions via `answer_sdlc_question.py`.
  - Generates release notes via `generate_release_notes.py`.

Expected CSV columns (or similar):

- ID
- Title
- Work Item Type
- State
- Area Path
- Iteration Path  (used as release / sprint)
- Tags
- Description

## One-time setup

From the repo root in PowerShell:

    python -m venv .venv
    .\.venv\Scripts\Activate.ps1
    pip install -r requirements.txt
    python -m nltk.downloader punkt   # optional, for NLP helpers later

Then:

1. Place your CSV exports in `data/sdlc/raw/`.
2. Build the KB:

       python scripts\build_sdlc_kb.py ^
         --input-glob "data/sdlc/raw/*.csv" ^
         --kb-version "2026.01" ^
         --out-markdown .github/skills/sdlc-kb/data/sdlc_enhanced.md ^
         --out-embeddings .github/skills/sdlc-kb/data/sdlc_embeddings.json ^
         --out-graph .github/skills/sdlc-kb/data/sdlc_graph.json

3. To answer a question from the CLI:

       python scripts\answer_sdlc_question.py ^
         --question "What changed in Sprint 2026.01 for Payments?" ^
         --context-text "User-facing changes only." ^
         --markdown .github/skills/sdlc-kb/data/sdlc_enhanced.md ^
         --embeddings .github/skills/sdlc-kb/data/sdlc_embeddings.json ^
         --graph .github/skills/sdlc-kb/data/sdlc_graph.json ^
         --top-k 10 ^
         --mode quick ^
         --out .github/skills/sdlc-kb/data/last_answer.json

4. To generate release notes from the CLI:

       python scripts\generate_release_notes.py ^
         --graph .github/skills/sdlc-kb/data/sdlc_graph.json ^
         --release-filter "2026.01" ^
         --out-markdown .github/skills/sdlc-kb/data/release_notes_2026_01.md

VS Code agent + prompts are under `.github/` and wired for the name
**GSF IR Release Notes Agent**.

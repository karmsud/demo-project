import argparse
import glob
import os
import json
from typing import List, Dict, Any, Optional

import pandas as pd
import numpy as np
from sentence_transformers import SentenceTransformer
import networkx as nx
from networkx.readwrite import json_graph

REQUIRED_COLS = [
    "ID",
    "Title",
    "Work Item Type",
    "State",
    "Area Path",
    "Iteration Path",
    "Tags",
    "Description",
]

def load_csvs(pattern: str) -> pd.DataFrame:
    paths = glob.glob(pattern)
    if not paths:
        raise SystemExit(f"No CSV files matched pattern: {pattern}")
    frames = []
    for p in paths:
        df = pd.read_csv(p)
        df["__source_file"] = os.path.basename(p)
        frames.append(df)
    df_all = pd.concat(frames, ignore_index=True)
    for col in REQUIRED_COLS:
        if col not in df_all.columns:
            df_all[col] = ""
    return df_all

def build_sections(df: pd.DataFrame) -> List[Dict[str, Any]]:
    sections: List[Dict[str, Any]] = []
    for idx, row in df.iterrows():
        wid = str(row["ID"]) if str(row["ID"]) != "nan" else str(idx)
        title = str(row["Title"]) if not pd.isna(row["Title"]) else ""
        work_item_type = str(row["Work Item Type"])
        state = str(row["State"])
        area = str(row["Area Path"])
        iteration = str(row["Iteration Path"])
        tags = str(row["Tags"])
        desc = str(row["Description"]) if not pd.isna(row["Description"]) else ""

        heading = f"[{wid}] {title}".strip()
        body_lines = [
            f"Work Item Type: {work_item_type}",
            f"State: {state}",
            f"Area: {area}",
            f"Iteration: {iteration}",
            f"Tags: {tags}",
            "",
            desc,
        ]

        sections.append(
            {
                "id": int(idx),
                "work_item_id": wid,
                "title": title,
                "heading": heading,
                "body": body_lines,
                "work_item_type": work_item_type,
                "state": state,
                "area_path": area,
                "iteration_path": iteration,
                "tags": tags,
            }
        )
    return sections

def build_enhanced_markdown(sections: List[Dict[str, Any]]) -> str:
    releases: Dict[str, List[Dict[str, Any]]] = {}
    for sec in sections:
        rel = sec["iteration_path"] or "Unassigned"
        releases.setdefault(rel, []).append(sec)

    lines: List[str] = ["# SDLC Knowledge Base (Enhanced)", ""]

    for release_name in sorted(releases.keys()):
        lines.append(f"## Release: {release_name}")
        lines.append("")
        for sec in sorted(releases[release_name], key=lambda s: s["work_item_id"]):
            lines.append(f"### {sec['heading']}")
            lines.append("")
            lines.append(f"- Work Item Type: {sec['work_item_type']}")
            lines.append(f"- State: {sec['state']}")
            lines.append(f"- Area: {sec['area_path']}")
            lines.append(f"- Tags: {sec['tags']}")
            lines.append("")
            if sec["body"] and sec["body"][-1].strip():
                lines.append(sec["body"][-1])
                lines.append("")
        lines.append("")
    return "\n".join(lines)

def build_embeddings(
    sections: List[Dict[str, Any]],
    model_name: str = "sentence-transformers/all-MiniLM-L6-v2",
    kb_version: Optional[str] = None,
) -> Dict[str, Any]:
    model = SentenceTransformer(model_name)
    texts = []
    for sec in sections:
        text = f"{sec['heading']}\n" + " ".join(sec["body"])
        texts.append(text)
    embs = model.encode(texts, convert_to_numpy=True, normalize_embeddings=True)

    data: Dict[str, Any] = {
        "model_name": model_name,
        "kb_version": kb_version,
        "sections": [],
    }
    for sec, emb in zip(sections, embs):
        data["sections"].append(
            {
                "id": sec["id"],
                "work_item_id": sec["work_item_id"],
                "heading": sec["heading"],
                "iteration_path": sec["iteration_path"],
                "area_path": sec["area_path"],
                "work_item_type": sec["work_item_type"],
                "tags": sec["tags"],
                "embedding": emb.tolist(),
            }
        )
    return data

def build_graph(sections: List[Dict[str, Any]]) -> nx.Graph:
    G = nx.Graph()
    for sec in sections:
        text = f"{sec['heading']}\n" + " ".join(sec["body"])
        G.add_node(
            sec["id"],
            work_item_id=sec["work_item_id"],
            heading=sec["heading"],
            title=sec["title"],
            text=text,
            work_item_type=sec["work_item_type"],
            state=sec["state"],
            area_path=sec["area_path"],
            iteration_path=sec["iteration_path"],
            tags=sec["tags"],
        )
    by_iter: Dict[str, List[int]] = {}
    for sec in sections:
        by_iter.setdefault(sec["iteration_path"], []).append(sec["id"])
    for rel, node_ids in by_iter.items():
        node_ids = sorted(node_ids)
        for i in range(len(node_ids) - 1):
            G.add_edge(
                node_ids[i],
                node_ids[i + 1],
                relation="same_iteration",
                label=rel,
            )
    return G

def main():
    parser = argparse.ArgumentParser(
        description="Build SDLC KB artifacts from ADO/TFS CSV exports."
    )
    parser.add_argument(
        "--input-glob",
        type=str,
        required=True,
        help="Glob pattern for input CSV files, e.g. 'data/sdlc/raw/*.csv'.",
    )
    parser.add_argument(
        "--kb-version",
        type=str,
        default=None,
        help="Optional KB version label (e.g., '2026.01').",
    )
    parser.add_argument(
        "--out-markdown",
        type=str,
        required=True,
        help="Output enhanced Markdown path.",
    )
    parser.add_argument(
        "--out-embeddings",
        type=str,
        required=True,
        help="Output embeddings JSON path.",
    )
    parser.add_argument(
        "--out-graph",
        type=str,
        required=True,
        help="Output graph JSON path.",
    )
    args = parser.parse_args()

    df = load_csvs(args.input_glob)
    sections = build_sections(df)

    markdown = build_enhanced_markdown(sections)
    os.makedirs(os.path.dirname(args.out_markdown), exist_ok=True)
    with open(args.out_markdown, "w", encoding="utf-8") as f:
        f.write(markdown)

    embeddings = build_embeddings(sections, kb_version=args.kb_version)
    os.makedirs(os.path.dirname(args.out_embeddings), exist_ok=True)
    with open(args.out_embeddings, "w", encoding="utf-8") as f:
        json.dump(embeddings, f, indent=2)

    G = build_graph(sections)
    os.makedirs(os.path.dirname(args.out_graph), exist_ok=True)
    with open(args.out_graph, "w", encoding="utf-8") as f:
        json.dump(json_graph.node_link_data(G), f, indent=2)

    print("SDLC KB build complete.")
    print(f"- Enhanced Markdown: {args.out_markdown}")
    print(f"- Embeddings JSON : {args.out_embeddings}")
    print(f"- Graph JSON      : {args.out_graph}")
    if args.kb_version:
        print(f"- KB version      : {args.kb_version}")

if __name__ == "__main__":
    main()

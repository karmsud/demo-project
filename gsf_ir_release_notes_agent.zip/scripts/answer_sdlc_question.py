import argparse
import json
import os
from typing import Any, Dict, List, Tuple, Optional
from datetime import datetime

import numpy as np
from sentence_transformers import SentenceTransformer
import networkx as nx
from networkx.readwrite import json_graph

def load_embeddings(path: str) -> Tuple[str, Optional[str], np.ndarray, List[Dict[str, Any]]]:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    model_name = data["model_name"]
    kb_version = data.get("kb_version")
    sections = data["sections"]
    embs = np.array([s["embedding"] for s in sections], dtype=float)
    return model_name, kb_version, embs, sections

def load_graph(path: str) -> nx.Graph:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return json_graph.node_link_graph(data)

def build_query_embedding(model_name: str, question: str, context_text: str) -> np.ndarray:
    model = SentenceTransformer(model_name)
    full = (question or "") + "\n" + (context_text or "")
    return model.encode(full, convert_to_numpy=True, normalize_embeddings=True)

def rank_sections(
    query_emb: np.ndarray,
    section_embs: np.ndarray,
    sections_meta: List[Dict[str, Any]],
    top_k: int,
) -> List[Dict[str, Any]]:
    scores = section_embs @ query_emb
    indices = np.argsort(scores)[::-1][:top_k]
    results: List[Dict[str, Any]] = []
    for rank, idx in enumerate(indices, start=1):
        m = sections_meta[idx]
        results.append(
            {
                "rank": rank,
                "score": float(scores[idx]),
                "id": m["id"],
                "work_item_id": m["work_item_id"],
                "heading": m["heading"],
                "iteration_path": m.get("iteration_path"),
                "area_path": m.get("area_path"),
                "work_item_type": m.get("work_item_type"),
                "tags": m.get("tags"),
            }
        )
    return results

def confidence_band(score: float) -> str:
    if score >= 0.8:
        return "high"
    if score >= 0.5:
        return "medium"
    return "low"

def extract_item_from_graph(G: nx.Graph, node_id: int) -> Dict[str, Any]:
    node = G.nodes.get(node_id, {})
    return {
        "work_item_id": node.get("work_item_id"),
        "heading": node.get("heading"),
        "title": node.get("title"),
        "text": node.get("text"),
        "work_item_type": node.get("work_item_type"),
        "state": node.get("state"),
        "area_path": node.get("area_path"),
        "iteration_path": node.get("iteration_path"),
        "tags": node.get("tags"),
    }

def summarize_item(item: Dict[str, Any], mode: str = "quick") -> str:
    title = item.get("title") or item.get("heading") or ""
    wtype = item.get("work_item_type") or ""
    state = item.get("state") or ""
    area = item.get("area_path") or ""
    tags = item.get("tags") or ""
    base = f"[{item.get('work_item_id')}] {title}"
    meta_parts = []
    if wtype:
        meta_parts.append(wtype)
    if state:
        meta_parts.append(state)
    if area:
        meta_parts.append(f"Area: {area}")
    if tags:
        meta_parts.append(f"Tags: {tags}")
    meta = "; ".join(meta_parts)
    if mode == "quick":
        return f"{base} ({meta})" if meta else base
    text = (item.get("text") or "").replace("\n", " ")
    preview = text[:220] + ("..." if len(text) > 220 else "")
    if meta:
        return f"{base} ({meta}) — {preview}"
    return f"{base} — {preview}"

def build_answer_markdown(
    ranked_items: List[Dict[str, Any]],
    G: nx.Graph,
    kb_version: Optional[str],
    mode: str = "quick",
) -> Tuple[str, List[Dict[str, Any]], float, str]:
    if not ranked_items:
        md = (
            "I could not find relevant work items in the SDLC knowledge base "
            "for this question. Try refining the timeframe, module, or release "
            "name, or verify that the CSV exports contain the relevant items."
        )
        return md, [], 0.0, "low"

    items: List[Dict[str, Any]] = []
    for item in ranked_items:
        node_data = extract_item_from_graph(G, item["id"])
        merged = {**item, **node_data}
        merged["summary"] = summarize_item(merged, mode=mode)
        items.append(merged)

    max_score = max(i["score"] for i in items)
    band = confidence_band(max_score)
    overall_confidence = float(max_score)

    lines: List[str] = []
    lines.append("## SDLC / Release Summary")
    lines.append("")
    lines.append(f"_Confidence: {band} (score {overall_confidence:.3f})_")
    if kb_version:
        lines.append(f"_KB Version: {kb_version}_")
    lines.append("")

    by_release: Dict[str, List[Dict[str, Any]]] = {}
    for it in items:
        rel = it.get("iteration_path") or "Unassigned"
        by_release.setdefault(rel, []).append(it)

    for rel, rel_items in sorted(by_release.items(), key=lambda x: x[0]):
        lines.append(f"### Release: {rel}")
        lines.append("")
        for it in rel_items:
            lines.append(f"- {it['summary']} (score {it['score']:.3f})")
        lines.append("")

    lines.append("### References")
    lines.append("")
    for it in items:
        lines.append(
            f"- Work Item `{it['work_item_id']}` – {it.get('title') or it.get('heading')} "
            f"(Type: {it.get('work_item_type')}, Release: {it.get('iteration_path')})"
        )
    lines.append("")

    if band == "low":
        lines.append(
            "> Confidence is low. You may want to narrow the question "
            "to a specific release, module, or timeframe."
        )
        lines.append("")

    return "\n".join(lines), items, overall_confidence, band

def append_query_log(
    log_path: str,
    question: str,
    context_text: str,
    kb_version: Optional[str],
    items: List[Dict[str, Any]],
    confidence: float,
    band: str,
) -> None:
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    record = {
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "question": question,
        "context_text": context_text,
        "kb_version": kb_version,
        "top_items": [
            {
                "rank": i["rank"],
                "score": i["score"],
                "work_item_id": i.get("work_item_id"),
                "iteration_path": i.get("iteration_path"),
                "work_item_type": i.get("work_item_type"),
                "title": i.get("title"),
            }
            for i in items
        ],
        "confidence": confidence,
        "confidence_band": band,
    }
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")

def main():
    parser = argparse.ArgumentParser(
        description="Answer an SDLC / release question using precomputed KB artifacts."
    )
    parser.add_argument("--question", type=str, required=True, help="User question.")
    parser.add_argument(
        "--context-text",
        type=str,
        default="",
        help="Optional extra context: timeframe, module, release names, etc.",
    )
    parser.add_argument(
        "--markdown",
        type=str,
        required=True,
        help="Path to enhanced Markdown (for reference only here).",
    )
    parser.add_argument(
        "--embeddings",
        type=str,
        required=True,
        help="Path to embeddings JSON produced by build_sdlc_kb.py.",
    )
    parser.add_argument(
        "--graph",
        type=str,
        required=True,
        help="Path to graph JSON produced by build_sdlc_kb.py.",
    )
    parser.add_argument(
        "--top-k",
        type=int,
        default=10,
        help="Maximum number of candidate work items to return.",
    )
    parser.add_argument(
        "--mode",
        type=str,
        default="quick",
        choices=["quick", "deep"],
        help="Answer mode: 'quick' for concise summaries, 'deep' for more detail.",
    )
    parser.add_argument(
        "--out",
        type=str,
        required=True,
        help="Output JSON path for the structured answer.",
    )
    parser.add_argument(
        "--log-path",
        type=str,
        default=".github/skills/sdlc-kb/data/query_log.jsonl",
        help="Where to append query logs.",
    )
    args = parser.parse_args()

    model_name, kb_version, section_embs, sections_meta = load_embeddings(args.embeddings)
    query_emb = build_query_embedding(model_name, args.question, args.context_text)
    ranked = rank_sections(query_emb, section_embs, sections_meta, top_k=args.top_k)
    G = load_graph(args.graph)

    answer_markdown, items, confidence, band = build_answer_markdown(
        ranked, G, kb_version, mode=args.mode
    )

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    output = {
        "question": args.question,
        "context_text": args.context_text,
        "answer_markdown": answer_markdown,
        "items": items,
        "confidence": confidence,
        "confidence_band": band,
        "kb_version": kb_version,
    }
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2)

    append_query_log(
        args.log_path,
        args.question,
        args.context_text,
        kb_version,
        items,
        confidence,
        band,
    )

    print("Answer written to", args.out)
    print(f"Confidence band: {band} (score {confidence:.3f})")
    print("Top candidate work items:")
    for it in items:
        print(
            f"- Rank {it['rank']}: [{it.get('work_item_id')}] {it.get('title')} "
            f"(Release={it.get('iteration_path')}, score={it['score']:.3f})"
        )

if __name__ == "__main__":
    main()

"""Simple regression harness for the SDLC KB."""

import json
import subprocess
import sys
from typing import List, Dict, Any

TEST_CASES = [
    # {
    #     "name": "Example Payments sprint",
    #     "question": "What changed in Sprint 2026.01 for the Payments module?",
    #     "context_text": "Payments module, user-facing changes.",
    #     "expected_work_item_ids": ["1234", "5678"],
    # },
]

def run_answer_script(
    question: str,
    context_text: str,
    top_k: int = 10,
    mode: str = "quick",
    out_path: str = ".github/skills/sdlc-kb/data/test_answer.json",
) -> Dict[str, Any]:
    cmd = [
        sys.executable,
        "scripts/answer_sdlc_question.py",
        "--question",
        question,
        "--context-text",
        context_text,
        "--markdown",
        ".github/skills/sdlc-kb/data/sdlc_enhanced.md",
        "--embeddings",
        ".github/skills/sdlc-kb/data/sdlc_embeddings.json",
        "--graph",
        ".github/skills/sdlc-kb/data/sdlc_graph.json",
        "--top-k",
        str(top_k),
        "--mode",
        mode,
        "--out",
        out_path,
    ]
    subprocess.check_call(cmd)
    with open(out_path, "r", encoding="utf-8") as f:
        return json.load(f)

def main():
    if not TEST_CASES:
        print("No TEST_CASES defined. Edit scripts/test_sdlc_kb.py to add some.")
        return

    passed = 0
    for case in TEST_CASES:
        print(f"Running test: {case['name']}")
        result = run_answer_script(
            question=case["question"],
            context_text=case.get("context_text", ""),
            top_k=10,
            mode="quick",
        )
        candidate_ids = [str(i.get("work_item_id")) for i in result.get("items", [])]
        expected_ids = [str(x) for x in case["expected_work_item_ids"]]
        if any(eid in candidate_ids for eid in expected_ids):
            print(f"  PASS: Expected one of {expected_ids}, got candidates {candidate_ids}")
            passed += 1
        else:
            print(f"  FAIL: Expected one of {expected_ids}, got candidates {candidate_ids}")

    print(f"Summary: {passed}/{len(TEST_CASES)} tests passed.")

if __name__ == "__main__":
    main()

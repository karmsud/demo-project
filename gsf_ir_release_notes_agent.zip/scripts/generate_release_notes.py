import argparse
import json
import os
from typing import Dict, Any, List

import networkx as nx
from networkx.readwrite import json_graph

def load_graph(path: str) -> nx.Graph:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return json_graph.node_link_graph(data)

def categorize(item_type: str) -> str:
    t = (item_type or "").lower()
    if any(x in t for x in ["feature", "user story", "product backlog item", "story"]):
        return "features"
    if "bug" in t:
        return "bugs"
    return "other"

def main():
    parser = argparse.ArgumentParser(
        description="Generate Markdown release notes for a given release filter using the SDLC graph."
    )
    parser.add_argument(
        "--graph",
        type=str,
        required=True,
        help="Path to sdlc_graph.json produced by build_sdlc_kb.py.",
    )
    parser.add_argument(
        "--release-filter",
        type=str,
        required=True,
        help="Case-insensitive substring matched against Iteration Path.",
    )
    parser.add_argument(
        "--out-markdown",
        type=str,
        required=True,
        help="Output Markdown path for the release notes.",
    )
    args = parser.parse_args()

    G = load_graph(args.graph)
    filt = args.release_filter.lower()

    items: List[Dict[str, Any]] = []
    for node_id, data in G.nodes(data=True):
        iteration = (data.get("iteration_path") or "").lower()
        if filt in iteration:
            items.append(
                {
                    "work_item_id": data.get("work_item_id"),
                    "title": data.get("title") or data.get("heading"),
                    "iteration_path": data.get("iteration_path"),
                    "work_item_type": data.get("work_item_type"),
                    "state": data.get("state"),
                    "area_path": data.get("area_path"),
                    "tags": data.get("tags"),
                    "text": data.get("text") or "",
                }
            )

    os.makedirs(os.path.dirname(args.out_markdown), exist_ok=True)

    if not items:
        with open(args.out_markdown, "w", encoding="utf-8") as f:
            f.write(
                f"# Release Notes for filter '{args.release_filter}'\n\n"
                "No matching work items were found in the SDLC graph.\n"
            )
        print("No items found for filter; wrote empty release notes.")
        return

    sections = {"features": [], "bugs": [], "other": []}
    for it in items:
        cat = categorize(it["work_item_type"] or "")
        sections[cat].append(it)

    def summarize_item(it):
        base = f"[{it['work_item_id']}] {it['title']}"
        meta_parts = []
        if it["state"]:
            meta_parts.append(it["state"])
        if it["area_path"]:
            meta_parts.append(f"Area: {it['area_path']}")
        if it["tags"]:
            meta_parts.append(f"Tags: {it['tags']}")
        meta = "; ".join(meta_parts)
        return f"{base} ({meta})" if meta else base

    release_name = items[0]["iteration_path"] or args.release_filter

    lines: List[str] = []
    lines.append(f"# Release Notes - {release_name}")
    lines.append("")

    if sections["features"]:
        lines.append("## New Features / Enhancements")
        lines.append("")
        for it in sections["features"]:
            lines.append(f"- {summarize_item(it)}")
        lines.append("")

    if sections["bugs"]:
        lines.append("## Bug Fixes")
        lines.append("")
        for it in sections["bugs"]:
            lines.append(f"- {summarize_item(it)}")
        lines.append("")

    if sections["other"]:
        lines.append("## Other Changes")
        lines.append("")
        for it in sections["other"]:
            lines.append(f"- {summarize_item(it)}")
        lines.append("")

    with open(args.out_markdown, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    print(f"Release notes written to {args.out_markdown}")
    print(f"Total items included: {len(items)}")

if __name__ == "__main__":
    main()

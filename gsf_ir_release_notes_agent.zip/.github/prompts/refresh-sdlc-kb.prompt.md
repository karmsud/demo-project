---
name: refresh-sdlc-kb
description: Admin-only workflow to rebuild the SDLC knowledge base from CSV exports.
agent: GSF IR Release Notes Agent
tools: ['terminal', 'codebase', 'search']
argument-hint: Confirm the CSV glob and KB version label.
---

Help an admin refresh the SDLC KB:

1. Confirm CSV glob (e.g., data/sdlc/raw/*.csv) and KB version label.
2. Explain you will run the build script.
3. Use terminal to call `build_sdlc_kb.py` per the `sdlc-kb` skill.
4. Summarize what was rebuilt and the KB version.

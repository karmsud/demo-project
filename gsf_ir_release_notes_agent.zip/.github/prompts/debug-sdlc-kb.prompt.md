---
name: debug-sdlc-kb
description: Inspect top candidate work items for a query.
agent: GSF IR Release Notes Agent
tools: ['terminal', 'codebase', 'search']
argument-hint: Provide a sample SDLC question and any context.
---

Help a developer debug SDLC KB retrieval:

1. Ask for a representative question and context.
2. Run `answer_sdlc_question.py` with top-k=10 (quick mode).
3. Open `last_answer.json` and show candidate work items and scores.
4. Suggest ways to tune CSV exports or naming if needed.

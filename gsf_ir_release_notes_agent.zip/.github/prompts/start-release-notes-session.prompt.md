---
name: start-release-notes-session
description: Start a guided SDLC / release analysis session.
agent: GSF IR Release Notes Agent
tools: ['codebase', 'search', 'terminal']
argument-hint: Briefly describe what you want to know about releases, sprints, or modules.
---

Start a new SDLC / release analysis session:

1. Greet the user.
2. Ask for:
   - release / sprint / iteration names or filters,
   - modules / areas of interest,
   - timeframe,
   - quick vs deep answer preference.
3. Use the `sdlc-kb` skill and `answer_sdlc_question.py` to produce the answer.
4. Present:
   - Summary,
   - Changes grouped by release,
   - Key work items,
   - KB version & confidence band.

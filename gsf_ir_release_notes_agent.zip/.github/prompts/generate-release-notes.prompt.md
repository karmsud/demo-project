---
name: generate-release-notes
description: Generate structured release notes for a given release / iteration filter.
agent: GSF IR Release Notes Agent
tools: ['terminal', 'codebase', 'search']
argument-hint: Specify the release or iteration filter (e.g., 2026.01).
---

Help the user generate release notes:

1. Ask for a release / iteration filter string.
2. Run `generate_release_notes.py` with that filter.
3. Open the generated Markdown and return it as the release notes.

# Global agent instructions

- This repo contains read-only SDLC / release-notes agents.
- Answers must be based ONLY on CSV exports and derived artifacts.
- Do not write or modify Python code at runtime.
- Do not call external web APIs or browse the internet.

---
name: sdlc-kb
description: Use this skill to analyze SDLC / ADO / TFS work items and releases from CSV exports.
---

# SDLC KB Skill

This skill uses pre-written Python scripts to:

- Build a knowledge base from CSV exports.
- Answer SDLC / release questions.
- Generate release notes.

Artifacts:

- Raw CSVs: `data/sdlc/raw/*.csv`
- Enhanced Markdown: `.github/skills/sdlc-kb/data/sdlc_enhanced.md`
- Embeddings: `.github/skills/sdlc-kb/data/sdlc_embeddings.json`
- Graph: `.github/skills/sdlc-kb/data/sdlc_graph.json`
- Query log: `.github/skills/sdlc-kb/data/query_log.jsonl`

## Admin: refresh SDLC KB

When an admin says new CSV exports are ready:

1. Confirm the glob (usually `data/sdlc/raw/*.csv`) and a KB version label.
2. Run via terminal:

   python scripts/build_sdlc_kb.py ^
     --input-glob "data/sdlc/raw/*.csv" ^
     --kb-version "<KB version label>" ^
     --out-markdown .github/skills/sdlc-kb/data/sdlc_enhanced.md ^
     --out-embeddings .github/skills/sdlc-kb/data/sdlc_embeddings.json ^
     --out-graph .github/skills/sdlc-kb/data/sdlc_graph.json

3. Summarize what was rebuilt.

## Q&A: answer SDLC / release questions

1. Collect from the user:
   - Question.
   - Modules / areas.
   - Release / sprint / timeframe.
   - Preference for quick vs deep answer.

2. Run via terminal:

   python scripts/answer_sdlc_question.py ^
     --question "<user question>" ^
     --context-text "<modules, timeframe, etc.>" ^
     --markdown .github/skills/sdlc-kb/data/sdlc_enhanced.md ^
     --embeddings .github/skills/sdlc-kb/data/sdlc_embeddings.json ^
     --graph .github/skills/sdlc-kb/data/sdlc_graph.json ^
     --top-k 10 ^
     --mode quick ^
     --out .github/skills/sdlc-kb/data/last_answer.json

3. Open `last_answer.json` and answer using:
   - answer_markdown
   - items
   - confidence / confidence_band
   - kb_version

If confidence band is low, tell the user and suggest narrowing the question.

## Release notes

1. Ask for a release / iteration filter (substring of Iteration Path).
2. Run via terminal:

   python scripts/generate_release_notes.py ^
     --graph .github/skills/sdlc-kb/data/sdlc_graph.json ^
     --release-filter "<filter>" ^
     --out-markdown .github/skills/sdlc-kb/data/release_notes_temp.md

3. Open `release_notes_temp.md` and return its contents as the answer.

"""
Document Conversion Script
==========================
Extracts raw text from PDF and Word documents for AI enhancement.

Usage:
    python convert_documents.py <deal_folder>
    
Example:
    python convert_documents.py "C:/Users/Karmsud/PaymentEngine/vba_models/CWALT 2007-23CB"

This script:
1. Reads all PDF/Word/text files from {deal_folder}/raw_documents/
2. Extracts raw text from each
3. Saves extracted text to {deal_folder}/extracted_text/
4. GHCP then enhances these into governing_docs/
"""

import os
import sys
from pathlib import Path
from datetime import datetime


def extract_pdf_text(pdf_path: Path) -> str:
    """Extract text from PDF using PyMuPDF (fitz)."""
    try:
        import fitz  # PyMuPDF
    except ImportError:
        print("ERROR: PyMuPDF not installed. Run: pip install PyMuPDF")
        sys.exit(1)
    
    text_parts = []
    doc = fitz.open(pdf_path)
    
    for page_num, page in enumerate(doc, 1):
        text = page.get_text()
        if text.strip():
            text_parts.append(f"\n{'='*60}\nPAGE {page_num}\n{'='*60}\n")
            text_parts.append(text)
    
    doc.close()
    return "".join(text_parts)


def extract_word_text(docx_path: Path) -> str:
    """Extract text from Word document using python-docx."""
    try:
        from docx import Document
    except ImportError:
        print("ERROR: python-docx not installed. Run: pip install python-docx")
        sys.exit(1)
    
    doc = Document(docx_path)
    text_parts = []
    
    for para in doc.paragraphs:
        if para.text.strip():
            text_parts.append(para.text)
    
    # Also extract tables
    for table in doc.tables:
        text_parts.append("\n[TABLE]\n")
        for row in table.rows:
            row_text = " | ".join(cell.text.strip() for cell in row.cells)
            text_parts.append(row_text)
        text_parts.append("[/TABLE]\n")
    
    return "\n".join(text_parts)


def extract_excel_text(xlsx_path: Path) -> str:
    """Extract text from Excel using openpyxl."""
    try:
        from openpyxl import load_workbook
    except ImportError:
        print("ERROR: openpyxl not installed. Run: pip install openpyxl")
        sys.exit(1)
    
    wb = load_workbook(xlsx_path, data_only=True)
    text_parts = []
    
    for sheet_name in wb.sheetnames:
        sheet = wb[sheet_name]
        text_parts.append(f"\n{'='*60}\nSHEET: {sheet_name}\n{'='*60}\n")
        
        for row in sheet.iter_rows():
            row_values = []
            for cell in row:
                if cell.value is not None:
                    row_values.append(str(cell.value))
            if row_values:
                text_parts.append(" | ".join(row_values))
    
    wb.close()
    return "\n".join(text_parts)


def extract_text_file(txt_path: Path) -> str:
    """Read plain text file."""
    with open(txt_path, 'r', encoding='utf-8', errors='ignore') as f:
        return f.read()


def process_document(file_path: Path) -> tuple[str, str]:
    """
    Process a single document and return (extracted_text, file_type).
    """
    suffix = file_path.suffix.lower()
    
    if suffix == '.pdf':
        return extract_pdf_text(file_path), 'PDF'
    elif suffix in ['.docx', '.doc']:
        return extract_word_text(file_path), 'Word'
    elif suffix in ['.xlsx', '.xls']:
        return extract_excel_text(file_path), 'Excel'
    elif suffix in ['.txt', '.text']:
        return extract_text_file(file_path), 'Text'
    else:
        print(f"  SKIP: Unsupported format {suffix}")
        return None, None


def convert_all_documents(deal_folder: str):
    """
    Main function: Convert all documents in raw_documents/ to extracted_text/
    """
    deal_path = Path(deal_folder)
    raw_docs_path = deal_path / "raw_documents"
    extracted_path = deal_path / "extracted_text"
    
    # Validate
    if not deal_path.exists():
        print(f"ERROR: Deal folder not found: {deal_path}")
        sys.exit(1)
    
    if not raw_docs_path.exists():
        print(f"ERROR: raw_documents/ folder not found in {deal_path}")
        print("Create the folder and add your PDF/Word documents.")
        sys.exit(1)
    
    # Create output folder
    extracted_path.mkdir(exist_ok=True)
    
    # Get all documents
    supported_extensions = {'.pdf', '.docx', '.doc', '.xlsx', '.xls', '.txt', '.text'}
    documents = [f for f in raw_docs_path.iterdir() 
                 if f.is_file() 
                 and f.suffix.lower() in supported_extensions
                 and not f.name.startswith('~$')]  # Skip temp files
    
    if not documents:
        print(f"ERROR: No supported documents found in {raw_docs_path}")
        print(f"Supported formats: {supported_extensions}")
        sys.exit(1)
    
    print(f"\n{'='*60}")
    print(f"DOCUMENT CONVERSION")
    print(f"{'='*60}")
    print(f"Deal: {deal_path.name}")
    print(f"Input: {raw_docs_path}")
    print(f"Output: {extracted_path}")
    print(f"Documents found: {len(documents)}")
    print(f"{'='*60}\n")
    
    # Process each document
    results = []
    for doc in sorted(documents):
        print(f"Processing: {doc.name}...", end=" ")
        
        try:
            text, file_type = process_document(doc)
            
            if text:
                # Save extracted text
                output_name = doc.stem + "_extracted.txt"
                output_path = extracted_path / output_name
                
                # Add header with metadata
                header = f"""{'='*60}
EXTRACTED TEXT
{'='*60}
Source File: {doc.name}
File Type: {file_type}
Extracted: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
{'='*60}

"""
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(header + text)
                
                char_count = len(text)
                print(f"OK ({char_count:,} chars)")
                results.append((doc.name, output_name, file_type, char_count))
            else:
                print("SKIPPED")
                
        except Exception as e:
            print(f"ERROR: {e}")
            results.append((doc.name, "ERROR", str(e), 0))
    
    # Print summary
    print(f"\n{'='*60}")
    print("EXTRACTION COMPLETE")
    print(f"{'='*60}")
    print(f"\n{'Source File':<40} {'Output File':<40} {'Type':<10} {'Chars':>12}")
    print("-" * 105)
    for source, output, ftype, chars in results:
        if output == "ERROR":
            print(f"{source:<40} {'ERROR: ' + ftype:<40}")
        else:
            print(f"{source:<40} {output:<40} {ftype:<10} {chars:>12,}")
    
    total_chars = sum(r[3] for r in results if r[1] != "ERROR")
    print("-" * 105)
    print(f"{'TOTAL':<40} {'':<40} {'':<10} {total_chars:>12,}")
    
    print(f"\n✓ Extracted text saved to: {extracted_path}")
    print(f"\nNEXT STEP: Open GHCP and paste the enhancement prompt from DOCUMENT_CONVERSION_GUIDE.md")
    print(f"           Point it to: {extracted_path}")


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        print("\nUsage: python convert_documents.py <deal_folder>")
        print("\nExample:")
        print('  python convert_documents.py "C:/Users/Karmsud/PaymentEngine/vba_models/CWALT 2007-23CB"')
        sys.exit(1)
    
    deal_folder = sys.argv[1]
    convert_all_documents(deal_folder)


if __name__ == "__main__":
    main()

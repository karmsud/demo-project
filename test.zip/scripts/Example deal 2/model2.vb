Sub Gen_Dec()
Dim k As Integer ' define k as ordinary variable to cycle the different prepay speeds in below for loop
Workbooks("Distribution.xlsm").Sheets("Certs").Select
k = Cells(32, 1)

Dim SheetName1 As String ' define r as ordinary variable to cycle through all loans, r = 1 to 110
    If k = 1 Then
    SheetName1 = "Scenario I"
    ElseIf k = 2 Then
    SheetName1 = "Scenario II"
    ElseIf k = 3 Then
    SheetName1 = "Scenario III"
    ElseIf k = 4 Then
    SheetName1 = "Scenario IV"
    Else
    SheetName1 = "Scenario V"
    End If
    
Dim Orig_Cert_Bal(1 To 20) As Double
Dim Cert_Bal(1 To 20) As Double
Dim Cert_Bal_PPT(1 To 359, 1 To 20) As Double
Dim Cert_Principal_Paid(1 To 20) As Double
Dim Cert_Interest_Paid(1 To 20) As Double
Dim PassThruRate(1 To 20) As Double

Dim ClassM1_PDA As Double
Dim ClassM1_DA As Double
Dim ClassM2_PDA As Double
Dim ClassM2_DA As Double
Dim ClassM3_PDA As Double
Dim ClassM3_DA As Double
Dim ClassM4_PDA As Double
Dim ClassM4_DA As Double
Dim ClassM5_PDA As Double
Dim ClassM5_DA As Double
Dim ClassM6_PDA As Double
Dim ClassM6_DA As Double
Dim ClassM7_PDA As Double
Dim ClassM7_DA As Double
Dim ClassM8_PDA As Double
Dim ClassM8_DA As Double
Dim ClassM9_PDA As Double
Dim ClassM9_DA As Double
Dim ClassB1_PDA As Double
Dim ClassB1_DA As Double
Dim ClassB2_PDA As Double
Dim ClassB2_DA As Double
    
Dim Count As Integer
Dim Orig_Pool_Bal As Double
Dim Pool_Bal(1 To 361) As Double
Dim Loan_Grp_1_Principal(1 To 360) As Double
Dim Loan_Grp_2_Principal(1 To 360) As Double
Dim Loan_Grp_1_Interest(1 To 360) As Double
Dim Loan_Grp_2_Interest(1 To 360) As Double

Orig_Pool_Bal = 881499700.9 'Opening Pool Balance
Pool_Bal(1) = Orig_Pool_Bal

Workbooks("Distribution.xlsm").Sheets(SheetName1).Select
For R = 2 To 360
    Loan_Grp_1_Principal(R - 1) = Cells(R, 2)
    Loan_Grp_1_Interest(R - 1) = Cells(R, 3)
    Loan_Grp_2_Principal(R - 1) = Cells(R, 4)
    Loan_Grp_2_Interest(R - 1) = Cells(R, 5)
    Pool_Bal(R) = Cells(R, 7)
Next R

            Dim ClassA1_Principal_Allocation_Percentage As Double
            Dim ClassA2_Principal_Allocation_Percentage As Double
            Dim ClassA1_Distribution_Amount As Double
            Dim ClassA2_Distribution_Amount As Double
            
            Dim Prin_ClassA1_1 As Double
            Dim Prin_ClassA1_2 As Double
            Dim Prin_ClassA2_1(1 To 4) As Double
            Dim Prin_ClassA2_2(1 To 4) As Double
            
'IRA = Interest Remittance Amount
'PRA = Principal Remittance Amount
'PDA = Principal Distribution Amount
'EPDA = Extra Principal Distribution Amount
'BPDA = Basic Principal Distribution Amount
'TMES = Total Monthly Excess Spread
'SEP = Senior Enhancement %
'SSEP = Specified Senior Enhancement %
'SPB = Stated Principal Balance
'TMES = Total Monthly Excess Spread

Dim IRA(1 To 360) As Double
Dim TMES(1 To 360) As Double
Dim PRA(1 To 360) As Double
Dim BPDA(1 To 360) As Double
Dim EPDA(1 To 360) As Double
Dim PDA(1 To 360) As Double

Dim StepDown As Boolean
Dim Senior_ClassA_Bal As Double
Dim SSEP As Double
Dim SEP As Double
SSEP = 0.413

Dim OC_Excess(1 To 360) As Double
Dim OC_Deficiency(1 To 360) As Double
Dim OC_Reduction_Amt(1 To 360) As Double
Dim OC_Specified(1 To 360) As Double
Dim OC_Floor As Double
OC_Floor = 0.005 * Orig_Pool_Bal

Dim Sum As Double
Dim n As Integer

Sum = 0
Workbooks("Distribution.xlsm").Sheets("Certs").Select
            'Get All Certificate Pass Thru Rates in an Array
            For R = 2 To 21
                PassThruRate(R - 1) = Cells(R, 4)
            Next R
            
            'Set Starting Balance of the certificates.
            For R = 2 To 20
                Cert_Bal(R - 1) = Cells(R, 2)
                Orig_Cert_Bal(R - 1) = Cert_Bal(R - 1)
                Sum = Sum + Cert_Bal(R - 1)
            Next R
            Cert_Bal(20) = Pool_Bal(1) - Sum
            Orig_Cert_Bal(20) = Cert_Bal(20)

For n = 1 To 359
    'Define IRA and PRA
    IRA(n) = Loan_Grp_1_Interest(n) + Loan_Grp_2_Interest(n)
    PRA(n) = Loan_Grp_1_Principal(n) + Loan_Grp_2_Principal(n)
    
    'Calculate Senior Enchancement Percentage
    Senior_ClassA_Bal = Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5)
    Subordinate_Class_Bal = Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8) + Cert_Bal(9) + Cert_Bal(10) + Cert_Bal(11) + Cert_Bal(12) + Cert_Bal(13) + Cert_Bal(4) + Cert_Bal(15) + Cert_Bal(16) + Cert_Bal(17) + Cert_Bal(18) + Cert_Bal(19)
    SEP = (Pool_Bal(n) - Senior_ClassA_Bal) / Pool_Bal(n)
    
    '***************** Add Special Clause for month in which Senior is zero by paying current month *******************
    'Define StepDown True/False
    If Senior_ClassA_Bal = 0 Then
        StepDown = True
    ElseIf n > 36 Then
        If SEP > SSEP Then
            StepDown = True
        End If
    Else
        StepDown = False
    End If
      
    'Define Specified OC
        If StepDown = False Then
            OC_Specified(n) = 0.014 * Pool_Bal(1)
        Else
            OC_Specified(n) = Application.WorksheetFunction.Max(0.028 * Pool_Bal(n + 1), OC_Floor)
        End If
        
        If (Senior_ClassA_Bal + Subordinate_Class_Bal) = 0 Then
            OC_Specified(n) = 0
        End If
        
    OC_Excess(n) = Application.WorksheetFunction.Max(0, Cert_Bal(20) - OC_Specified(n))
    OC_Deficiency(n) = Application.WorksheetFunction.Max(0, OC_Specified(n) - Cert_Bal(20))

    'Calculate Interest Payable to Each Class
    Dim Int_Paid_Sum As Double
    Int_Paid_Sum = 0
   
    For R = 1 To 20
        Cert_Interest_Paid(R) = Cert_Bal(R) * PassThruRate(R) / 12
        Int_Paid_Sum = Int_Paid_Sum + Cert_Interest_Paid(R)
    Next R
    
    If IRA(n) > Int_Paid_Sum Then
        Cells(n + 1, 8) = 1
    End If
    
    If IRA(n) > OC_Excess(n) Then
        Cells(n + 1, 9) = 1
    End If
        
    'Set Total Monthly Excess Spread
    TMES(n) = Application.WorksheetFunction.Max(0, IRA(n) - Int_Paid_Sum)
    
    'Set Basic Principal Distribution Amount BPDA              ********** Add some Special Clause **************
    BPDA(n) = Application.WorksheetFunction.Max(0, PRA(n) - OC_Excess(n))
    
    'Set Extra Principal Distribution Amount EPDA
    EPDA(n) = Application.WorksheetFunction.Min(TMES(n), OC_Deficiency(n))
    
    'Set Principal Distribution Amount PDA
    PDA(n) = EPDA(n) + BPDA(n)
If (Senior_ClassA_Bal + Subordinate_Class_Bal) > 0 Then
    
    Count = 0
    If (Senior_ClassA_Bal - PDA(n)) <= 0 Then '/// Special Case
        Count = Count + 1
    End If
    If Count = 1 Then
            If (Subordinate_Class_Bal + Cert_Bal(20)) > 0 Then 'If Any Subordinate Classes(M1-B2) or OC class Exsits //////////////////////////
                      
            ClassA1_Principal_Allocation_Percentage = Loan_Grp_1_Principal(n) / (Loan_Grp_1_Principal(n) + Loan_Grp_2_Principal(n))
            ClassA2_Principal_Allocation_Percentage = Loan_Grp_2_Principal(n) / (Loan_Grp_1_Principal(n) + Loan_Grp_2_Principal(n))
            ClassA1_Distribution_Amount = ClassA1_Principal_Allocation_Percentage * PDA(n)
            ClassA2_Distribution_Amount = ClassA2_Principal_Allocation_Percentage * PDA(n)
            
            'Payoff Class A1 using Group 1 Principal
            Prin_ClassA1_1 = Application.WorksheetFunction.Min(Cert_Bal(1), ClassA1_Distribution_Amount)
            ClassA1_Distribution_Amount = ClassA1_Distribution_Amount - Prin_ClassA1_1
            Cert_Bal(1) = Cert_Bal(1) - Prin_ClassA1_1
            
            'Payoff Class A2A to A2D using Group 2 Principal
            For i = 1 To 4
                Prin_ClassA2_2(i) = Application.WorksheetFunction.Min(Cert_Bal(i + 1), ClassA2_Distribution_Amount)
                ClassA2_Distribution_Amount = ClassA2_Distribution_Amount - Prin_ClassA2_2(i)
                Cert_Bal(i + 1) = Cert_Bal(i + 1) - Prin_ClassA2_2(i)
            Next i
            
            'Payoff Class A1 using Group 2 Principal
            Prin_ClassA1_2 = Application.WorksheetFunction.Min(Cert_Bal(1), ClassA2_Distribution_Amount)
            ClassA2_Distribution_Amount = ClassA2_Distribution_Amount - Prin_ClassA1_2
            Cert_Bal(1) = Cert_Bal(1) - Prin_ClassA1_2
            Cert_Principal_Paid(1) = Prin_ClassA1_1 + Prin_ClassA1_2
            
            'Payoff Class A2A to A2D using Group 1 Principal
            For i = 1 To 4
                Prin_ClassA2_1(i) = Application.WorksheetFunction.Min(Cert_Bal(i + 1), ClassA1_Distribution_Amount)
                ClassA1_Distribution_Amount = ClassA1_Distribution_Amount - Prin_ClassA2_1(i)
                Cert_Bal(i + 1) = Cert_Bal(i + 1) - Prin_ClassA2_1(i)
                Cert_Principal_Paid(i + 1) = Prin_ClassA2_1(i) + Prin_ClassA2_2(i)
            Next i
            
            'Principal Distribution Amount Left After Paying Senior Classes:
            PDA(n) = PDA(n) - (Cert_Principal_Paid(1) + Cert_Principal_Paid(2) + Cert_Principal_Paid(3) + Cert_Principal_Paid(4) + Cert_Principal_Paid(5))
            
        Else 'If Subordinate Class Balance is Zero, pay all senior certificates pro-rata //////////////////////////
            For i = 1 To 5
             Cert_Principal_Paid(i) = Cert_Bal(i) * PDA(n) / Senior_ClassA_Bal
             Cert_Bal(i) = Cert_Bal(i) - Cert_Principal_Paid(i)
            Next i
        End If
        
        'Now Pay the Class M1:
        
        ClassM1_PDA = Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6)) - Application.WorksheetFunction.Min(0.668 * Pool_Bal(n + 1), Pool_Bal(n + 1) - OC_Floor)))
        ClassM1_DA = Application.WorksheetFunction.Min(PDA(n), ClassM1_PDA)
        Cert_Principal_Paid(6) = Application.WorksheetFunction.Min(Cert_Bal(6), ClassM1_DA)
        Cert_Bal(6) = Cert_Bal(6) - Cert_Principal_Paid(6)
        PDA(n) = PDA(n) - Cert_Principal_Paid(6)
        
        'Now Pay the Class M2:
        
        ClassM2_PDA = Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7)) - Application.WorksheetFunction.Min(0.733 * Pool_Bal(n + 1), Pool_Bal(n + 1) - OC_Floor)))
        ClassM2_DA = Application.WorksheetFunction.Min(PDA(n), ClassM2_PDA)
        Cert_Principal_Paid(7) = Application.WorksheetFunction.Min(Cert_Bal(7), ClassM2_DA)
        Cert_Bal(7) = Cert_Bal(7) - Cert_Principal_Paid(7)
        PDA(n) = PDA(n) - Cert_Principal_Paid(7)
        
        'Now Pay the Class M3:
        
        ClassM3_PDA = Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8)) - Application.WorksheetFunction.Min(0.771 * Pool_Bal(n + 1), Pool_Bal(n + 1) - OC_Floor)))
        ClassM3_DA = Application.WorksheetFunction.Min(PDA(n), ClassM3_PDA)
        Cert_Principal_Paid(8) = Application.WorksheetFunction.Min(Cert_Bal(8), ClassM3_DA)
        Cert_Bal(8) = Cert_Bal(8) - Cert_Principal_Paid(8)
        PDA(n) = PDA(n) - Cert_Principal_Paid(8)
    
        'Now Pay the Class M4:
        
        ClassM4_PDA = Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8) + Cert_Bal(9)) - Application.WorksheetFunction.Min(0.805 * Pool_Bal(n + 1), Pool_Bal(n + 1) - OC_Floor)))
        ClassM4_DA = Application.WorksheetFunction.Min(PDA(n), ClassM4_PDA)
        Cert_Principal_Paid(9) = Application.WorksheetFunction.Min(Cert_Bal(9), ClassM4_DA)
        Cert_Bal(9) = Cert_Bal(9) - Cert_Principal_Paid(9)
        PDA(n) = PDA(n) - Cert_Principal_Paid(9)
        
        'Now Pay the Class M5:
       
        ClassM5_PDA = Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8) + Cert_Bal(9) + Cert_Bal(10)) - Application.WorksheetFunction.Min(0.838 * Pool_Bal(n + 1), Pool_Bal(n + 1) - OC_Floor)))
        ClassM5_DA = Application.WorksheetFunction.Min(PDA(n), ClassM5_PDA)
        Cert_Principal_Paid(10) = Application.WorksheetFunction.Min(Cert_Bal(10), ClassM5_DA)
        Cert_Bal(10) = Cert_Bal(10) - Cert_Principal_Paid(10)
        PDA(n) = PDA(n) - Cert_Principal_Paid(10)
        
        'Now Pay the Class M6:
        
        ClassM6_PDA = Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8) + Cert_Bal(9) + Cert_Bal(10) + Cert_Bal(11)) - Application.WorksheetFunction.Min(0.869 * Pool_Bal(n + 1), Pool_Bal(n + 1) - OC_Floor)))
        ClassM6_DA = Application.WorksheetFunction.Min(PDA(n), ClassM6_PDA)
        Cert_Principal_Paid(11) = Application.WorksheetFunction.Min(Cert_Bal(11), ClassM6_DA)
        Cert_Bal(11) = Cert_Bal(11) - Cert_Principal_Paid(11)
        PDA(n) = PDA(n) - Cert_Principal_Paid(11)
        
        'Now Pay the Class M7:
        
        ClassM7_PDA = Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8) + Cert_Bal(9) + Cert_Bal(10) + Cert_Bal(11) + Cert_Bal(12)) - Application.WorksheetFunction.Min(0.897 * Pool_Bal(n + 1), Pool_Bal(n + 1) - OC_Floor)))
        ClassM7_DA = Application.WorksheetFunction.Min(PDA(n), ClassM7_PDA)
        Cert_Principal_Paid(12) = Application.WorksheetFunction.Min(Cert_Bal(12), ClassM7_DA)
        Cert_Bal(12) = Cert_Bal(12) - Cert_Principal_Paid(12)
        PDA(n) = PDA(n) - Cert_Principal_Paid(12)
        
        'Now Pay the Class M8:
       
        ClassM8_PDA = Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8) + Cert_Bal(9) + Cert_Bal(10) + Cert_Bal(11) + Cert_Bal(12) + Cert_Bal(13)) - Application.WorksheetFunction.Min(0.922 * Pool_Bal(n + 1), Pool_Bal(n + 1) - OC_Floor)))
        ClassM8_DA = Application.WorksheetFunction.Min(PDA(n), ClassM8_PDA)
        Cert_Principal_Paid(13) = Application.WorksheetFunction.Min(Cert_Bal(13), ClassM8_DA)
        Cert_Bal(13) = Cert_Bal(13) - Cert_Principal_Paid(13)
        PDA(n) = PDA(n) - Cert_Principal_Paid(13)
        
        'Now Pay the Class M9:
            
        ClassM9_PDA = Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8) + Cert_Bal(9) + Cert_Bal(10) + Cert_Bal(11) + Cert_Bal(12) + Cert_Bal(13) + Cert_Bal(14)) - Application.WorksheetFunction.Min(0.938 * Pool_Bal(n + 1), Pool_Bal(n + 1) - OC_Floor)))
        ClassM9_DA = Application.WorksheetFunction.Min(PDA(n), ClassM9_PDA)
        Cert_Principal_Paid(14) = Application.WorksheetFunction.Min(Cert_Bal(14), ClassM9_DA)
        Cert_Bal(14) = Cert_Bal(14) - Cert_Principal_Paid(14)
        PDA(n) = PDA(n) - Cert_Principal_Paid(14)
        
        'Now Pay the Class B1:
        
        ClassB1_PDA = Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8) + Cert_Bal(9) + Cert_Bal(10) + Cert_Bal(11) + Cert_Bal(12) + Cert_Bal(13) + Cert_Bal(14) + Cert_Bal(15)) - Application.WorksheetFunction.Min(0.952 * Pool_Bal(n + 1), Pool_Bal(n + 1) - OC_Floor)))
        ClassB1_DA = Application.WorksheetFunction.Min(PDA(n), ClassB1_PDA)
        Cert_Principal_Paid(15) = Application.WorksheetFunction.Min(Cert_Bal(15), ClassB1_DA)
        Cert_Bal(15) = Cert_Bal(15) - Cert_Principal_Paid(15)
        PDA(n) = PDA(n) - Cert_Principal_Paid(15)
        
        'Now Pay the Class B2:
       
        ClassB2_PDA = Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8) + Cert_Bal(9) + Cert_Bal(10) + Cert_Bal(11) + Cert_Bal(12) + Cert_Bal(13) + Cert_Bal(14) + Cert_Bal(15) + Cert_Bal(16)) - Application.WorksheetFunction.Min(0.972 * Pool_Bal(n + 1), Pool_Bal(n + 1) - OC_Floor)))
        ClassB2_DA = Application.WorksheetFunction.Min(PDA(n), ClassB2_PDA)
        Cert_Principal_Paid(16) = Application.WorksheetFunction.Min(Cert_Bal(16), ClassB2_DA)
        Cert_Bal(16) = Cert_Bal(16) - Cert_Principal_Paid(16)
        PDA(n) = PDA(n) - Cert_Principal_Paid(16)
        
    

Else
If StepDown = False Then  'Before Step Down: ///////////////////////////////////////////////////////////////////////
    
        'First Pay the R,RC,RX Class Certificates
        'Paying off R, RC, RX Class
        For i = 17 To 19
            Cert_Principal_Paid(i) = Application.WorksheetFunction.Min(Cert_Bal(i), PDA(n))
            PDA(n) = PDA(n) - Cert_Principal_Paid(i)
            Cert_Bal(i) = Cert_Bal(i) - Cert_Principal_Paid(i)
        Next i
                
        If (Subordinate_Class_Bal + Cert_Bal(20)) > 0 Then 'If Any Subordinate Classes(M1-B2) or OC class Exsits //////////////////////////
                      
            ClassA1_Principal_Allocation_Percentage = Loan_Grp_1_Principal(n) / (Loan_Grp_1_Principal(n) + Loan_Grp_2_Principal(n))
            ClassA2_Principal_Allocation_Percentage = Loan_Grp_2_Principal(n) / (Loan_Grp_1_Principal(n) + Loan_Grp_2_Principal(n))
            ClassA1_Distribution_Amount = ClassA1_Principal_Allocation_Percentage * PDA(n)
            ClassA2_Distribution_Amount = ClassA2_Principal_Allocation_Percentage * PDA(n)
            
            'Payoff Class A1 using Group 1 Principal
            Prin_ClassA1_1 = Application.WorksheetFunction.Min(Cert_Bal(1), ClassA1_Distribution_Amount)
            ClassA1_Distribution_Amount = ClassA1_Distribution_Amount - Prin_ClassA1_1
            Cert_Bal(1) = Cert_Bal(1) - Prin_ClassA1_1
            
            'Payoff Class A2A to A2D using Group 2 Principal
            For i = 1 To 4
                Prin_ClassA2_2(i) = Application.WorksheetFunction.Min(Cert_Bal(i + 1), ClassA2_Distribution_Amount)
                ClassA2_Distribution_Amount = ClassA2_Distribution_Amount - Prin_ClassA2_2(i)
                Cert_Bal(i + 1) = Cert_Bal(i + 1) - Prin_ClassA2_2(i)
            Next i
            
            'Payoff Class A1 using Group 2 Principal
            Prin_ClassA1_2 = Application.WorksheetFunction.Min(Cert_Bal(1), ClassA2_Distribution_Amount)
            ClassA2_Distribution_Amount = ClassA2_Distribution_Amount - Prin_ClassA1_2
            Cert_Bal(1) = Cert_Bal(1) - Prin_ClassA1_2
            Cert_Principal_Paid(1) = Prin_ClassA1_1 + Prin_ClassA1_2
            
            'Payoff Class A2A to A2D using Group 1 Principal
            For i = 1 To 4
                Prin_ClassA2_1(i) = Application.WorksheetFunction.Min(Cert_Bal(i + 1), ClassA1_Distribution_Amount)
                ClassA1_Distribution_Amount = ClassA1_Distribution_Amount - Prin_ClassA2_1(i)
                Cert_Bal(i + 1) = Cert_Bal(i + 1) - Prin_ClassA2_1(i)
                Cert_Principal_Paid(i + 1) = Prin_ClassA2_1(i) + Prin_ClassA2_2(i)
            Next i
            
            'Principal Distribution Amount Left After Paying Senior Classes:
            PDA(n) = PDA(n) - (Cert_Principal_Paid(1) + Cert_Principal_Paid(2) + Cert_Principal_Paid(3) + Cert_Principal_Paid(4) + Cert_Principal_Paid(5))
            
        Else 'If Subordinate Class Balance is Zero, pay all senior certificates pro-rata //////////////////////////
            For i = 1 To 5
             Cert_Principal_Paid(i) = Cert_Bal(i) * PDA(n) / Senior_ClassA_Bal
             Cert_Bal(i) = Cert_Bal(i) - Cert_Principal_Paid(i)
            Next i
        End If
         
        'Now Pay All M1-B2 Classes Sequentially:
        For i = 6 To 16
            Cert_Principal_Paid(i) = Application.WorksheetFunction.Min(Cert_Bal(i), PDA(n))
            PDA(n) = PDA(n) - Cert_Principal_Paid(i)
            Cert_Bal(i) = Cert_Bal(i) - Cert_Principal_Paid(i)
        Next i
        
Else ' If Step Down is True ////////////////////////////////////////////////////////////////////////////////
    
    Dim ClassA_PDA As Double
    Dim ClassA_DA As Double
    
    ClassA_PDA = Application.WorksheetFunction.Max(0, (Senior_ClassA_Bal - Application.WorksheetFunction.Min(0.587 * Pool_Bal(n + 1), Pool_Bal(n + 1) - OC_Floor)))
    ClassA_DA = Application.WorksheetFunction.Min(PDA(n), ClassA_PDA)
    
    If (Subordinate_Class_Bal + Cert_Bal(20)) > 0 Then 'If Any Subordinate Classes(M1-B2) or OC class Exsits //////////////////////////
        
            ClassA1_Principal_Allocation_Percentage = Loan_Grp_1_Principal(n) / (Loan_Grp_1_Principal(n) + Loan_Grp_2_Principal(n))
            ClassA2_Principal_Allocation_Percentage = Loan_Grp_2_Principal(n) / (Loan_Grp_1_Principal(n) + Loan_Grp_2_Principal(n))
            ClassA1_Distribution_Amount = ClassA1_Principal_Allocation_Percentage * ClassA_DA
            ClassA2_Distribution_Amount = ClassA2_Principal_Allocation_Percentage * ClassA_DA
            
            'Payoff Class A1 using Group 1 Principal
            Prin_ClassA1_1 = Application.WorksheetFunction.Min(Cert_Bal(1), ClassA1_Distribution_Amount)
            ClassA1_Distribution_Amount = ClassA1_Distribution_Amount - Prin_ClassA1_1
            Cert_Bal(1) = Cert_Bal(1) - Prin_ClassA1_1
            
            'Payoff Class A2A to A2D using Group 2 Principal
            For i = 1 To 4
                Prin_ClassA2_2(i) = Application.WorksheetFunction.Min(Cert_Bal(i + 1), ClassA2_Distribution_Amount)
                ClassA2_Distribution_Amount = ClassA2_Distribution_Amount - Prin_ClassA2_2(i)
                Cert_Bal(i + 1) = Cert_Bal(i + 1) - Prin_ClassA2_2(i)
            Next i
            
            'Payoff Class A1 using Group 2 Principal
            Prin_ClassA1_2 = Application.WorksheetFunction.Min(Cert_Bal(1), ClassA2_Distribution_Amount)
            ClassA2_Distribution_Amount = ClassA2_Distribution_Amount - Prin_ClassA1_2
            Cert_Bal(1) = Cert_Bal(1) - Prin_ClassA1_2
            Cert_Principal_Paid(1) = Prin_ClassA1_1 + Prin_ClassA1_2
            
            'Payoff Class A2A to A2D using Group 1 Principal
            For i = 1 To 4
                Prin_ClassA2_1(i) = Application.WorksheetFunction.Min(Cert_Bal(i + 1), ClassA1_Distribution_Amount)
                ClassA1_Distribution_Amount = ClassA1_Distribution_Amount - Prin_ClassA2_1(i)
                Cert_Bal(i + 1) = Cert_Bal(i + 1) - Prin_ClassA2_1(i)
                Cert_Principal_Paid(i + 1) = Prin_ClassA2_1(i) + Prin_ClassA2_2(i)
            Next i
            
            'Principal Distribution Amount Left After Paying Senior Classes:
            PDA(n) = PDA(n) - (Cert_Principal_Paid(1) + Cert_Principal_Paid(2) + Cert_Principal_Paid(3) + Cert_Principal_Paid(4) + Cert_Principal_Paid(5))
            
        Else 'If Subordinate Class Balance is Zero, pay all senior certificates pro-rata //////////////////////////
            For i = 1 To 5
             Cert_Principal_Paid(i) = Cert_Bal(i) * PDA(n) / Senior_ClassA_Bal
             Cert_Bal(i) = Cert_Bal(i) - Cert_Principal_Paid(i)
            Next i
        End If
        
        'Now Pay the Class M1:
        
        ClassM1_PDA = Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6)) - Application.WorksheetFunction.Min(0.668 * Pool_Bal(n + 1), Pool_Bal(n + 1) - OC_Floor)))
        ClassM1_DA = Application.WorksheetFunction.Min(PDA(n), ClassM1_PDA)
        Cert_Principal_Paid(6) = Application.WorksheetFunction.Min(Cert_Bal(6), ClassM1_DA)
        Cert_Bal(6) = Cert_Bal(6) - Cert_Principal_Paid(6)
        PDA(n) = PDA(n) - Cert_Principal_Paid(6)
        
        'Now Pay the Class M2:
        
        ClassM2_PDA = Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7)) - Application.WorksheetFunction.Min(0.733 * Pool_Bal(n + 1), Pool_Bal(n + 1) - OC_Floor)))
        ClassM2_DA = Application.WorksheetFunction.Min(PDA(n), ClassM2_PDA)
        Cert_Principal_Paid(7) = Application.WorksheetFunction.Min(Cert_Bal(7), ClassM2_DA)
        Cert_Bal(7) = Cert_Bal(7) - Cert_Principal_Paid(7)
        PDA(n) = PDA(n) - Cert_Principal_Paid(7)
        
        'Now Pay the Class M3:
        
        ClassM3_PDA = Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8)) - Application.WorksheetFunction.Min(0.771 * Pool_Bal(n + 1), Pool_Bal(n + 1) - OC_Floor)))
        ClassM3_DA = Application.WorksheetFunction.Min(PDA(n), ClassM3_PDA)
        Cert_Principal_Paid(8) = Application.WorksheetFunction.Min(Cert_Bal(8), ClassM3_DA)
        Cert_Bal(8) = Cert_Bal(8) - Cert_Principal_Paid(8)
        PDA(n) = PDA(n) - Cert_Principal_Paid(8)
    
        'Now Pay the Class M4:
        
        ClassM4_PDA = Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8) + Cert_Bal(9)) - Application.WorksheetFunction.Min(0.805 * Pool_Bal(n + 1), Pool_Bal(n + 1) - OC_Floor)))
        ClassM4_DA = Application.WorksheetFunction.Min(PDA(n), ClassM4_PDA)
        Cert_Principal_Paid(9) = Application.WorksheetFunction.Min(Cert_Bal(9), ClassM4_DA)
        Cert_Bal(9) = Cert_Bal(9) - Cert_Principal_Paid(9)
        PDA(n) = PDA(n) - Cert_Principal_Paid(9)
        
        'Now Pay the Class M5:
       
        ClassM5_PDA = Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8) + Cert_Bal(9) + Cert_Bal(10)) - Application.WorksheetFunction.Min(0.838 * Pool_Bal(n + 1), Pool_Bal(n + 1) - OC_Floor)))
        ClassM5_DA = Application.WorksheetFunction.Min(PDA(n), ClassM5_PDA)
        Cert_Principal_Paid(10) = Application.WorksheetFunction.Min(Cert_Bal(10), ClassM5_DA)
        Cert_Bal(10) = Cert_Bal(10) - Cert_Principal_Paid(10)
        PDA(n) = PDA(n) - Cert_Principal_Paid(10)
        
        'Now Pay the Class M6:
        
        ClassM6_PDA = Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8) + Cert_Bal(9) + Cert_Bal(10) + Cert_Bal(11)) - Application.WorksheetFunction.Min(0.869 * Pool_Bal(n + 1), Pool_Bal(n + 1) - OC_Floor)))
        ClassM6_DA = Application.WorksheetFunction.Min(PDA(n), ClassM6_PDA)
        Cert_Principal_Paid(11) = Application.WorksheetFunction.Min(Cert_Bal(11), ClassM6_DA)
        Cert_Bal(11) = Cert_Bal(11) - Cert_Principal_Paid(11)
        PDA(n) = PDA(n) - Cert_Principal_Paid(11)
        
        'Now Pay the Class M7:
        
        ClassM7_PDA = Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8) + Cert_Bal(9) + Cert_Bal(10) + Cert_Bal(11) + Cert_Bal(12)) - Application.WorksheetFunction.Min(0.897 * Pool_Bal(n + 1), Pool_Bal(n + 1) - OC_Floor)))
        ClassM7_DA = Application.WorksheetFunction.Min(PDA(n), ClassM7_PDA)
        Cert_Principal_Paid(12) = Application.WorksheetFunction.Min(Cert_Bal(12), ClassM7_DA)
        Cert_Bal(12) = Cert_Bal(12) - Cert_Principal_Paid(12)
        PDA(n) = PDA(n) - Cert_Principal_Paid(12)
        
        'Now Pay the Class M8:
       
        ClassM8_PDA = Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8) + Cert_Bal(9) + Cert_Bal(10) + Cert_Bal(11) + Cert_Bal(12) + Cert_Bal(13)) - Application.WorksheetFunction.Min(0.922 * Pool_Bal(n + 1), Pool_Bal(n + 1) - OC_Floor)))
        ClassM8_DA = Application.WorksheetFunction.Min(PDA(n), ClassM8_PDA)
        Cert_Principal_Paid(13) = Application.WorksheetFunction.Min(Cert_Bal(13), ClassM8_DA)
        Cert_Bal(13) = Cert_Bal(13) - Cert_Principal_Paid(13)
        PDA(n) = PDA(n) - Cert_Principal_Paid(13)
        
        'Now Pay the Class M9:
            
        ClassM9_PDA = Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8) + Cert_Bal(9) + Cert_Bal(10) + Cert_Bal(11) + Cert_Bal(12) + Cert_Bal(13) + Cert_Bal(14)) - Application.WorksheetFunction.Min(0.938 * Pool_Bal(n + 1), Pool_Bal(n + 1) - OC_Floor)))
        ClassM9_DA = Application.WorksheetFunction.Min(PDA(n), ClassM9_PDA)
        Cert_Principal_Paid(14) = Application.WorksheetFunction.Min(Cert_Bal(14), ClassM9_DA)
        Cert_Bal(14) = Cert_Bal(14) - Cert_Principal_Paid(14)
        PDA(n) = PDA(n) - Cert_Principal_Paid(14)
        
        'Now Pay the Class B1:
        
        ClassB1_PDA = Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8) + Cert_Bal(9) + Cert_Bal(10) + Cert_Bal(11) + Cert_Bal(12) + Cert_Bal(13) + Cert_Bal(14) + Cert_Bal(15)) - Application.WorksheetFunction.Min(0.952 * Pool_Bal(n + 1), Pool_Bal(n + 1) - OC_Floor)))
        ClassB1_DA = Application.WorksheetFunction.Min(PDA(n), ClassB1_PDA)
        Cert_Principal_Paid(15) = Application.WorksheetFunction.Min(Cert_Bal(15), ClassB1_DA)
        Cert_Bal(15) = Cert_Bal(15) - Cert_Principal_Paid(15)
        PDA(n) = PDA(n) - Cert_Principal_Paid(15)
        
        'Now Pay the Class B2:
       
        ClassB2_PDA = Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8) + Cert_Bal(9) + Cert_Bal(10) + Cert_Bal(11) + Cert_Bal(12) + Cert_Bal(13) + Cert_Bal(14) + Cert_Bal(15) + Cert_Bal(16)) - Application.WorksheetFunction.Min(0.972 * Pool_Bal(n + 1), Pool_Bal(n + 1) - OC_Floor)))
        ClassB2_DA = Application.WorksheetFunction.Min(PDA(n), ClassB2_PDA)
        Cert_Principal_Paid(16) = Application.WorksheetFunction.Min(Cert_Bal(16), ClassB2_DA)
        Cert_Bal(16) = Cert_Bal(16) - Cert_Principal_Paid(16)
        PDA(n) = PDA(n) - Cert_Principal_Paid(16)
        
        
End If
End If
End If

'Principal And Interest Payments to X Class: All Excess Interest over the OC Definicency will go to X class
    Cert_Interest_Paid(20) = Application.WorksheetFunction.Max(0, TMES(n) - OC_Deficiency(n))
    Cert_Principal_Paid(20) = OC_Excess(n) - OC_Deficiency(n)
    Cert_Bal(20) = Cert_Bal(20) - Cert_Principal_Paid(20)
    
    For i = 1 To 19
        Cert_Bal_PPT(n, i) = 100 * (Cert_Bal(i) / Orig_Cert_Bal(i))
    Next i
    
    
Next n


'Print the output Cashflow
Workbooks("Distribution.xlsm").Sheets("Payments").Select
Workbooks("Distribution.xlsm").Sheets("Payments").Cells.ClearContents
Cells(1, 1) = "Month"
Cells(1, 2) = "A1"
Cells(1, 3) = "A2A"
Cells(1, 4) = "A2B"
Cells(1, 5) = "A2C"
Cells(1, 6) = "A2D"
Cells(1, 7) = "M1"
Cells(1, 8) = "M2"
Cells(1, 9) = "M3"
Cells(1, 10) = "M4"
Cells(1, 11) = "M5"
Cells(1, 12) = "M6"
Cells(1, 13) = "M7"
Cells(1, 14) = "M8"
Cells(1, 15) = "M9"
Cells(1, 16) = "B1"
Cells(1, 17) = "B2"
Cells(1, 18) = "R"
Cells(1, 19) = "RC"
Cells(1, 20) = "RX"
Cells(1, 21) = "X"

        For n = 1 To 359
        Cells(n + 1, 1) = n
            For i = 1 To 20
                Cells(n + 1, i + 1) = Cert_Bal_PPT(n, i)
            Next i
        Next n

End Sub

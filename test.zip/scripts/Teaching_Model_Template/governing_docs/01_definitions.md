# Defined Terms - Bear Stearns Asset Backed Securities I LLC, Series 2006-HE2

## Document Information
- **Source**: Pooling and Servicing Agreement, Article I - Definitions
- **Purpose**: This document defines all terms used in the waterfall and payment calculations
- **AI Instruction**: Extract parameter values from these definitions. Each defined term includes the exact legal language and, where applicable, the mathematical interpretation.

---

## Key Deal Constants

### Closing Date
**Legal Text**: "Closing Date: February 28, 2006."
- **Value**: 2006-02-28
- **Usage**: Reference point for time-based calculations

### Cut-off Date
**Legal Text**: "Cut-off Date: The close of business on February 1, 2006."
- **Value**: 2006-02-01
- **Usage**: Date for initial pool balance calculations

### Cut-off Date Principal Balance (Original Pool Balance)
**Legal Text**: "The aggregate Cut-off Date Principal Balance of the Mortgage Loans is $706,145,220.67."
- **Value**: 706145220.67
- **Usage**: Denominator for percentage calculations, OC targets

### Stepdown Date
**Legal Text**: "Stepdown Date: The later to occur of (a) the Distribution Date in March 2009 and (b) the first Distribution Date on which the Current Specified Enhancement Percentage is greater than or equal to 50.20%."
- **Interpretation**: 
  - Condition (a): Distribution month >= 37 (March 2009 is month 37 from March 2006)
  - Condition (b): Current Enhancement >= 50.20%
  - Both conditions must be met (later of = both satisfied)
- **Mathematical Test**: `stepdown_eligible = (month >= 37) AND (enhancement_pct >= 0.5020)`

### Servicing Fee Rate
**Legal Text**: "Servicing Fee Rate: 0.500% per annum."
- **Value**: 0.00500
- **Usage**: Deducted from gross interest before distribution

### Trustee Fee
**Legal Text**: "Trustee Fee: As to each Mortgage Loan and any Distribution Date, a per annum fee equal to 0.0065%"
- **Value**: 0.000065
- **Usage**: Deducted from gross interest before distribution

### Reserve Fund Deposit
**Legal Text**: "Reserve Fund Deposit: With respect to the Reserve Fund, an amount equal to $5,000"
- **Value**: 5000
- **Usage**: Target reserve fund balance

---

## Overcollateralization Definitions

### Overcollateralization Amount
**Legal Text**: "Overcollateralization Amount: With respect to any Distribution Date, the excess, if any, of the aggregate Stated Principal Balance of the Mortgage Loans as of the last day of the related Due Period (after giving effect to scheduled payments of principal due during the related Due Period, to the extent received or advanced, and unscheduled collections of principal received during the related Prepayment Period, and after reduction for Realized Losses incurred during the related Due Period) over the aggregate Certificate Principal Balance of the Certificates (other than the Class CE Certificates and Class P Certificates) on such Distribution Date (after taking into account the payment of principal other than any Extra Principal Distribution Amount on such Certificates)."

- **Mathematical Formula**:
```
OC_Amount = Ending_Pool_Balance - Sum(Certificate_Balances for Classes A and M)
```
- **Note**: Class CE and Class P are excluded from the certificate balance sum

### Overcollateralization Target Amount
**Legal Text**: "Overcollateralization Target Amount: With respect to any Distribution Date (a) prior to the Stepdown Date, 3.65% of the aggregate Stated Principal Balance of the Mortgage Loans as of the Cut-off Date, (b) on or after the Stepdown Date and if a Trigger Event is not in effect, the greater of (i) the lesser of (1) 3.65% of the aggregate Stated Principal Balance of the Mortgage Loans as of the Cut-off Date and (2) 7.30% of the then current aggregate Stated Principal Balance of the Mortgage Loans... and (ii) $3,530,726 or (c) on or after the Stepdown Date and if a Trigger Event is in effect, the Overcollateralization Target Amount for the immediately preceding Distribution Date."

- **Extracted Values**:
  - OC Floor Percentage: 3.65% (0.0365)
  - OC Stepdown Percentage: 7.30% (0.0730)
  - OC Minimum Amount: $3,530,726
  
- **Mathematical Formula**:
```python
if not stepdown_eligible:
    # Case (a): Prior to Stepdown Date
    OC_Target = 0.0365 * Original_Pool_Balance
elif stepdown_eligible and not trigger_active:
    # Case (b): After Stepdown, no Trigger
    OC_Target = max(
        min(0.0365 * Original_Pool_Balance, 0.0730 * Current_Pool_Balance),
        3530726
    )
else:
    # Case (c): After Stepdown with Trigger
    OC_Target = Prior_Month_OC_Target
```

### Overcollateralization Release Amount
**Legal Text**: "Overcollateralization Release Amount: With respect to any Distribution Date, the lesser of (x) the Principal Remittance Amount for such Distribution Date and (y) the excess, if any, of (i) the Overcollateralization Amount for such Distribution Date... over (ii) the Overcollateralization Target Amount"

- **Mathematical Formula**:
```python
OC_Excess = max(0, OC_Amount - OC_Target)
OC_Release = min(Principal_Remittance, OC_Excess)
```

---

## Credit Enhancement Definitions

### Current Specified Enhancement Percentage
**Legal Text**: "Current Specified Enhancement Percentage: With respect to any Distribution Date, the percentage obtained by dividing (x) the sum of (i) the aggregate Certificate Principal Balance of the Class M Certificates and (ii) the Overcollateralization Amount, in each case prior to the distribution of the Principal Distribution Amount on such Distribution Date, by (y) the aggregate Stated Principal Balance of the Mortgage Loans as of the end of the related Due Period."

- **Mathematical Formula**:
```python
Enhancement_Pct = (Sum_M_Class_Balances + OC_Amount) / Ending_Pool_Balance
```

---

## Certificate Margin Definitions

### Certificate Margins (Pre-Optional Termination Date)
**Legal Text** (extracted for each class):

| Class | Margin | Source Text |
|-------|--------|-------------|
| I-A-1 | 0.080% | "With respect to the Class I-A-1 Certificates... 0.080% per annum" |
| I-A-2 | 0.200% | "With respect to the Class I-A-2 Certificates... 0.200% per annum" |
| I-A-3 | 0.320% | "With respect to the Class I-A-3 Certificates... 0.320% per annum" |
| II-A | 0.200% | "With respect to the Class II-A Certificates... 0.200% per annum" |
| M-1 | 0.400% | "With respect to the Class M-1 Certificates... 0.400% per annum" |
| M-2 | 0.410% | "With respect to the Class M-2 Certificates... 0.410% per annum" |
| M-3 | 0.430% | "With respect to the Class M-3 Certificates... 0.430% per annum" |
| M-4 | 0.600% | "With respect to the Class M-4 Certificates... 0.600% per annum" |
| M-5 | 0.600% | "With respect to the Class M-5 Certificates... 0.600% per annum" |
| M-6 | 0.730% | "With respect to the Class M-6 Certificates... 0.730% per annum" |
| M-7 | 1.400% | "With respect to the Class M-7 Certificates... 1.400% per annum" |
| M-8 | 1.550% | "With respect to the Class M-8 Certificates... 1.550% per annum" |
| M-9 | 2.250% | "With respect to the Class M-9 Certificates... 2.250% per annum" |
| M-10 | 2.250% | "With respect to the Class M-10 Certificates... 2.250% per annum" |

---

## Principal Distribution Amount Definitions (Lockout Percentages)

These define the subordination floors used in post-stepdown principal distribution.

### Class A Principal Distribution Amount
**Legal Text**: "Class A Principal Distribution Amount: For any Distribution Date, an amount equal to the lesser of (x) the Principal Distribution Amount for such Distribution Date and (y) the excess, if any, of (i) the aggregate Certificate Principal Balance of the Class A Certificates immediately prior to such Distribution Date, over (ii) the lesser of (a) the product of (1) **49.80%** and (2) the aggregate Stated Principal Balance of the Mortgage Loans... and (b) the aggregate Stated Principal Balance... minus $3,530,726."

- **Lockout Percentage**: 49.80% (0.4980)
- **Floor Amount**: $3,530,726

### Class M-1 through M-10 Principal Distribution Amounts
| Class | Lockout Percentage | Legal Reference |
|-------|-------------------|-----------------|
| M-1 | 59.10% | "the product of (x) 59.10% and (y) the aggregate Stated Principal Balance" |
| M-2 | 66.50% | "the product of (x) 66.50% and (y) the aggregate Stated Principal Balance" |
| M-3 | 71.00% | "the product of (x) 71.00% and (y) the aggregate Stated Principal Balance" |
| M-4 | 74.90% | "the product of (x) 74.90% and (y) the aggregate Stated Principal Balance" |
| M-5 | 78.60% | "the product of (x) 78.60% and (y) the aggregate Stated Principal Balance" |
| M-6 | 82.00% | "the product of (x) 82.00% and (y) the aggregate Stated Principal Balance" |
| M-7 | 85.10% | "the product of (x) 85.10% and (y) the aggregate Stated Principal Balance" |
| M-8 | 87.90% | "the product of (x) 87.90% and (y) the aggregate Stated Principal Balance" |
| M-9 | 90.20% | "the product of (x) 90.20% and (y) the aggregate Stated Principal Balance" |
| M-10 | 92.70% | "the product of (x) 92.70% and (y) the aggregate Stated Principal Balance" |

---

## Interest Calculation Definitions

### Accrual Period
**Legal Text**: "Accrual Period: With respect to the Certificates (other than the Class CE, Class P and the Residual Certificates) and any Distribution Date, the period from and including the immediately preceding Distribution Date (or with respect to the first Accrual Period, the Closing Date) to and including the day prior to such Distribution Date... All calculations of interest on the Certificates (other than the Class CE, Class P and the Residual Certificates) will be made on the basis of the **actual number of days elapsed** in the related Accrual Period."

- **Day Count**: Actual/360 (actual days in period, 360-day year)
- **Formula**: `Interest = Balance × (LIBOR + Margin) × (Actual_Days / 360)`

### Class CE Accrual
**Legal Text**: "With respect to the Class CE Certificates and the Class CE Interest and any Distribution Date, the calendar month immediately preceding such Distribution Date. All calculations of interest on the Class CE Interest and the Class CE Certificates will be made on the basis of a **360-day year consisting of twelve 30-day months**."

- **Day Count**: 30/360
- **Note**: Class CE uses different day count than other classes

### Pass-Through Rate
**Legal Text**: "Pass-Through Rate: With respect to the Class A Certificates and Class M Certificates and any Distribution Date, a rate per annum equal to the lesser of (i) the related One-Month LIBOR Pass-Through Rate for such Distribution Date and (ii) the related Net Rate Cap for such Distribution Date."

- **Formula**: `Pass_Through_Rate = min(LIBOR + Margin, Net_Rate_Cap)`

### Current Interest
**Legal Text**: "Current Interest: As of any Distribution Date... (i) the interest accrued on the Certificate Principal Balance or Certificate Notional Amount... during the related Accrual Period at the applicable Pass-Through Rate plus any amount previously distributed with respect to interest for such Certificate that has been recovered as a voidable preference... minus (ii) the sum of (a) any Prepayment Interest Shortfall for such Distribution Date, to the extent not covered by Compensating Interest and (b) any Relief Act Interest Shortfalls"

- **Note**: Interest shortfalls reduce current interest due

---

## Trigger Definitions

### Trigger Event
**Legal Text**: "Trigger Event: With respect to any Distribution Date, a Trigger Event exists if (i) a Delinquency Event shall have occurred and be continuing or (ii) the aggregate amount of Realized Losses on the Mortgage Loans since the Cut-off Date as a percentage of the aggregate Cut-off Date Principal Balance of the Mortgage Loans exceeds the applicable percentages set forth below"

- **Two Conditions** (either triggers):
  1. Delinquency Event (see below)
  2. Cumulative Loss exceeds schedule

### Delinquency Event
**Legal Text**: "Delinquency Event: A Delinquency Event shall have occurred and be continuing if at any time, (x) the percent equivalent of a fraction, the numerator of which is the aggregate Stated Principal Balance of the Mortgage Loans that are 60 days or more Delinquent (including for this purpose any such Mortgage Loans in bankruptcy or foreclosure and Mortgage Loans with respect to which the related Mortgaged Property is REO Property), and the denominator of which is the aggregate Stated Principal Balance of all of the Mortgage Loans as of the last day of the related Due Period exceeds (y) **31.75%** of the Current Specified Enhancement Percentage."

- **Mathematical Test**:
```python
DQ_Ratio = (DQ_60_Plus + Bankruptcy + Foreclosure + REO) / Pool_Balance
DQ_Trigger = DQ_Ratio > (0.3175 * Enhancement_Pct)
```

---

## Other Key Definitions

### Interest Funds
**Legal Text** (summarized): Interest funds for each loan group equals:
- Scheduled interest collected (less servicing fee, trustee fee, LPMI fee)
- Plus: Advances relating to interest
- Plus: Compensating Interest
- Plus: Interest portion of liquidation proceeds
- Minus: Net Swap Payments to Swap Provider

### Principal Funds
**Legal Text** (summarized): Principal funds for each loan group equals:
- Scheduled principal collected
- Plus: Advances relating to principal
- Plus: Prepayments
- Plus: Principal portion of repurchases
- Plus: Principal portion of liquidation proceeds

### Excess Spread
**Legal Text**: "Excess Spread: With respect to any Distribution Date, the excess, if any, of (i) the Interest Funds for such Distribution Date over (ii) the sum of the Current Interest on the Class A Certificates and Class M Certificates and Interest Carry Forward Amounts on the Class A Certificates"

### Extra Principal Distribution Amount
**Legal Text**: "Extra Principal Distribution Amount: With respect to any Distribution Date, the lesser of (i) the excess, if any, of the Overcollateralization Target Amount for such Distribution Date over the Overcollateralization Amount for such Distribution Date... and (ii) the Excess Spread for such Distribution Date."

- **Purpose**: Converts excess spread to principal to build OC

### Principal Distribution Amount
**Legal Text**: "Principal Distribution Amount: With respect to each Distribution Date, an amount equal to (x) the Principal Funds for such Distribution Date plus (y) any Extra Principal Distribution Amount for such Distribution Date, less (z) any Overcollateralization Release Amount."

---

## Certificate Classes Summary

| Class | Original Balance | Type | Group | Interest-Bearing | Principal-Bearing |
|-------|-----------------|------|-------|-----------------|-------------------|
| I-A-1 | $198,258,000 | Senior | 1 | Yes | Yes |
| I-A-2 | $74,638,000 | Senior | 1 | Yes | Yes |
| I-A-3 | $14,310,000 | Senior | 1 | Yes | Yes |
| II-A | $241,697,000 | Senior | 2 | Yes | Yes |
| M-1 | $32,836,000 | Mezzanine | Both | Yes | Yes |
| M-2 | $26,127,000 | Mezzanine | Both | Yes | Yes |
| M-3 | $15,888,000 | Mezzanine | Both | Yes | Yes |
| M-4 | $13,770,000 | Mezzanine | Both | Yes | Yes |
| M-5 | $13,064,000 | Mezzanine | Both | Yes | Yes |
| M-6 | $12,004,000 | Mezzanine | Both | Yes | Yes |
| M-7 | $10,945,000 | Mezzanine | Both | Yes | Yes |
| M-8 | $9,886,000 | Mezzanine | Both | Yes | Yes |
| M-9 | $8,121,000 | Mezzanine | Both | Yes | Yes |
| M-10 | $8,827,000 | Mezzanine | Both | Yes | Yes |
| P | $100 | Prepayment Penalty | N/A | No | Yes |
| R-1 | $0 | Residual | N/A | No | No |
| R-2 | $0 | Residual | N/A | No | No |
| R-3 | $0 | Residual | N/A | No | No |
| RX | $0 | Residual | N/A | No | No |
| CE | $706,145,220.18 | Credit Enhancement | Both | Yes | Yes |

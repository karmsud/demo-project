Sub Bond_Admin_BS006HE2()

'Define variables:

'KEY:
'IRA = Interest Remittance Amount
'PRA = Principal Remittance Amount
'PDA = Principal Distribution Amount
'EPDA = Extra Principal Distribution Amount
'BPDA = Basic Principal Distribution Amount
'TMES = Total Monthly Excess Spread
'SEP = Senior Enhancement %
'SSEP = Specified Senior Enhancement %
'SPB = Stated Principal Balance
'TMES = Total Monthly Excess Spread

Dim Orig_Cert_Bal(1 To 20) As Double
Dim Cert_Bal(1 To 20) As Double
Dim Cert_Bal_PPT(1 To 20) As Double
Dim Cert_Principal_Paid(1 To 20) As Double
Dim Cert_Interest_Paid(1 To 20) As Double
Dim Cert_Interest_Due(1 To 20) As Double
Dim Cert_Margin(1 To 20) As Double
Dim Net_Rate_Cap(1 To 20) As Double
Dim Libor_Margin(1 To 20) As Double
Dim PassThruRate(1 To 20) As Double

Dim ClassM1_PDA As Double
Dim ClassM2_PDA As Double
Dim ClassM3_PDA As Double
Dim ClassM4_PDA As Double
Dim ClassM5_PDA As Double
Dim ClassM6_PDA As Double
Dim ClassM7_PDA As Double
Dim ClassM8_PDA As Double
Dim ClassM9_PDA As Double
Dim ClassM10_PDA As Double

Dim One_Mth_Libor As Double
Dim Orig_Pool_Bal As Double
Orig_Pool_Bal = 706145220.18 'Opening Pool Balance

Dim Pool_Bal As Double
Dim Ending_Pool_Bal As Double
Dim Pool_Bal_Grp1 As Double
Dim Pool_Bal_Grp2 As Double
Dim Ending_Pool_Bal_Grp1 As Double
Dim Ending_Pool_Bal_Grp2 As Double
Dim Loan_Grp_1_Principal As Double
Dim Loan_Grp_2_Principal As Double
Dim Loan_Grp_1_Interest As Double
Dim Loan_Grp_2_Interest As Double
Dim Dist_Count As Double

Dim ClassA1_Principal_Allocation_Percentage As Double
Dim ClassA2_Principal_Allocation_Percentage As Double
Dim ClassA1_Distribution_Amount As Double
Dim ClassA2_Distribution_Amount As Double
            
Dim Prin_Class_I_A(1 To 3) As Double
Dim Prin_Class_II_A As Double
            
Dim IRA As Double
Dim TMES As Double
Dim PRA As Double
Dim BPDA As Double
Dim EPDA As Double
Dim PDA As Double

Dim StepDown As Boolean
Dim Prior_Month_StepDown As Boolean
Dim Trigger As Boolean
Dim Loss_Trigger As Boolean
Dim DQ_Trigger As Boolean
Dim DQ_PCT As Double
Dim Loss_PCT As Double
Dim Senior_ClassA_Bal As Double
Dim SSEP As Double
Dim SEP As Double
SSEP = 0.502

Dim OC_Current As Double
Dim OC_Excess As Double
Dim OC_Deficiency As Double
Dim OC_Reduction_Amt As Double
Dim OC_Specified As Double
Dim OC_Floor As Double
OC_Floor = 0.0365 * Orig_Pool_Bal

Dim Loan_Grp_1_Cum_Realized_Loss As Double
Dim Loan_Grp_2_Cum_Realized_Loss As Double
Dim Cum_Realized_Loss As Double

Dim Net_Swap_Pmt As Double
Dim Swap_Termination_Pmt As Double

Dim Sum As Double
Dim Orig_Sum As Double
Dim R As Integer
Dim Actual_Days As Integer
Dim PPIS As Double
Dim Relief_Act_Shortfall As Double
Dim Reserve_Fund As Double

 Workbooks("BS006HE2_Bond_Admin_Model_v1.xlsm").Sheets("Input Data").Select
 Pool_Bal = Cells(13, 22)
 Ending_Pool_Bal = Cells(13, 111)
 
    For R = 14 To 17
        Pool_Bal_Grp1 = Pool_Bal_Grp1 + Cells(R, 22)
        Ending_Pool_Bal_Grp1 = Ending_Pool_Bal_Grp1 + Cells(R, 111)
    Next R
        
    For R = 18 To 21
        Pool_Bal_Grp2 = Pool_Bal_Grp2 + Cells(R, 22)
        Ending_Pool_Bal_Grp2 = Ending_Pool_Bal_Grp2 + Cells(R, 111)
    Next R
    
'Set Starting Balance of the certificates.
 Workbooks("BS006HE2_Bond_Admin_Model_v1.xlsm").Sheets("Note Cals").Select
    For R = 2 To 20
        Cert_Bal(R - 1) = Cells(R, 3)
        Orig_Cert_Bal(R - 1) = Cells(R, 2)
        Sum = Sum + Cert_Bal(R - 1)
        Orig_Sum = Orig_Sum + Orig_Cert_Bal(R - 1)
    Next R
    
    Cert_Bal(20) = Pool_Bal - Sum + Cert_Bal(15)
    Orig_Cert_Bal(20) = Orig_Pool_Bal - Orig_Sum + Cert_Bal(15)
    
    Workbooks("BS006HE2_Bond_Admin_Model_v1.xlsm").Sheets("Manual Input").Select
    'The One Month LIBOR for the month
    One_Mth_Libor = Cells(2, 2)
    
    'Actual Days in the Month
    Actual_Days = Cells(3, 2)
    
    'Pull in the Distribution Count
    Dist_Count = Cells(4, 2)
    
    'Pull in the PPIS
    PPIS = Cells(5, 2)
    
    'Pull in the Relief_Act_Shortfall
     Relief_Act_Shortfall = Cells(6, 2)
    
    
'Reserve_Fund
    If Dist_Count = 1 Then
        Reserve_Fund = 5000
    Else
        Reserve_Fund = Cells(7, 2)
    End If
    
'Calculate Senior Enchancement Percentage
    Senior_ClassA_Bal = Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4)
    Subordinate_Class_Bal = Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8) + Cert_Bal(9) + Cert_Bal(10) + Cert_Bal(11) + Cert_Bal(12) + Cert_Bal(13) + Cert_Bal(14)
    OC_Current = Pool_Bal - (Senior_ClassA_Bal + Subordinate_Class_Bal)
    SEP = (Pool_Bal - Senior_ClassA_Bal) / Pool_Bal

'Define StepDown True/False
    Prior_Month_StepDown = False
    If Cells(1, 2) = 1 Then
        Prior_Month_StepDown = True
    End If
    
    If Senior_ClassA_Bal = 0 Then
        StepDown = True
    ElseIf Prior_Month_StepDown = True Then
        StepDown = True
    ElseIf n > 36 And SEP > SSEP Then
        StepDown = True
    Else
        StepDown = False
    End If

'Extract Issue Level Data from Input Data tab
Workbooks("BS006HE2_Bond_Admin_Model_v1.xlsm").Sheets("Input Data").Select
    Loan_Grp_1_Principal = 0
    Loan_Grp_1_Interest = 0
    Loan_Grp_2_Principal = 0
    Loan_Grp_2_Interest = 0
    
    For R = 14 To 17
        Loan_Grp_1_Principal = Loan_Grp_1_Principal + Cells(R, 253)
        Loan_Grp_1_Interest = Loan_Grp_1_Interest + Cells(R, 40)
    Next R
        
    For R = 18 To 21
        Loan_Grp_2_Principal = Loan_Grp_2_Principal + Cells(R, 253)
        Loan_Grp_2_Interest = Loan_Grp_2_Interest + Cells(R, 40)
    Next R

    Loan_Grp_1_Interest = Loan_Grp_1_Interest / 12
    Loan_Grp_2_Interest = Loan_Grp_2_Interest / 12

    'Define IRA and PRA
    IRA = Loan_Grp_1_Interest + Loan_Grp_2_Interest
    PRA = Loan_Grp_1_Principal + Loan_Grp_2_Principal

    Workbooks("BS006HE2_Bond_Admin_Model_v1.xlsm").Sheets("Note Cals").Select
    Cells(24, 1) = "Loan_Grp_1_Interest"
    Cells(25, 1) = "Loan_Grp_2_Interest"
    Cells(26, 1) = "Loan_Grp_1_Principal"
    Cells(27, 1) = "Loan_Grp_2_Principal"
    Cells(28, 1) = "IRA"
    Cells(29, 1) = "PRA"
    Cells(30, 1) = "StepDown"
    Cells(31, 1) = "One_Mth_Libor"
    Cells(32, 1) = "Actual_Days"
    Cells(33, 1) = "PPIS"
    Cells(34, 1) = "Dist_Count"
    Cells(35, 1) = "Relief-Act-Shortfall"
    
    Cells(24, 2) = Loan_Grp_1_Interest
    Cells(25, 2) = Loan_Grp_2_Interest
    Cells(26, 2) = Loan_Grp_1_Principal
    Cells(27, 2) = Loan_Grp_2_Principal
    Cells(28, 2) = IRA
    Cells(29, 2) = PRA
    Cells(30, 2) = StepDown
    Cells(31, 2) = One_Mth_Libor
    Cells(32, 2) = Actual_Days
    Cells(33, 2) = PPIS
    Cells(34, 2) = Dist_Count
    Cells(35, 2) = Relief_Act_Shortfall
    
    Workbooks("BS006HE2_Bond_Admin_Model_v1.xlsm").Sheets("Input Data").Select
    
'Loss Trigger Event
    Loan_Grp_1_Cum_Realized_Loss = 0
    Loan_Grp_2_Cum_Realized_Loss = 0
    
    For R = 14 To 18
        Loan_Grp_1_Cum_Realized_Loss = Loan_Grp_1_Cum_Realized_Loss + Cells(R, 32)
    Next R
    
    For R = 19 To 22
        Loan_Grp_2_Cum_Realized_Loss = Loan_Grp_2_Cum_Realized_Loss + Cells(R, 32)
    Next R
    
    Cum_Realized_Loss = Loan_Grp_1_Cum_Realized_Loss + Loan_Grp_2_Cum_Realized_Loss
    Loss_PCT = Cum_Realized_Loss / Orig_Pool_Bal
    
    If Dist_Count > 72 And DQ_PCT > 0.0775 Then
        Loss_Trigger = True
    ElseIf Dist_Count > 60 And Dist_Count < 73 And DQ_PCT > 0.0725 Then
        Loss_Trigger = True
    ElseIf Dist_Count > 48 And Dist_Count < 61 And DQ_PCT > 0.058 Then
        Loss_Trigger = True
    ElseIf Dist_Count > 36 And Dist_Count < 49 And DQ_PCT > 0.037 Then
        Loss_Trigger = True
    Else
        Loss_Trigger = False
    End If
        
    Workbooks("BS006HE2_Bond_Admin_Model_v1.xlsm").Sheets("Note Cals").Select
    Cells(36, 1) = "Loss_Trigger"
    Cells(36, 2) = Loss_Trigger
    Workbooks("BS006HE2_Bond_Admin_Model_v1.xlsm").Sheets("Input Data").Select
    
'DQ Trigger Event
    Dim DQ_Bucket_1 As Double
    Dim DQ_Bucket_2 As Double
    Dim DQ_Bucket_3 As Double
    Dim DQ_Bucket_4  As Double
    Dim DQ_And_Bk_Bucket_1 As Double
    Dim DQ_And_Bk_Bucket_2 As Double
    Dim DQ_And_Bk_Bucket_3 As Double
    Dim DQ_And_Bk_Bucket_4 As Double
    Dim Reo_Bal As Double
    Dim Bk_Bal As Double
    Dim Foreclosure_Bal As Double
    
    DQ_Bucket_1 = Cells(13, 73)
    DQ_Bucket_2 = Cells(13, 75)
    DQ_Bucket_3 = Cells(13, 77)
    DQ_Bucket_4 = Cells(13, 79)
    
    DQ_And_Bk_Bucket_1 = Cells(2, 34)
    DQ_And_Bk_Bucket_2 = Cells(2, 36)
    DQ_And_Bk_Bucket_3 = Cells(2, 38)
    DQ_And_Bk_Bucket_4 = Cells(2, 40)
    
    Reo_Bal = Cells(13, 255)
    Bk_Bal = Cells(13, 17)
    Foreclosure_Bal = Cells(13, 119)
    
    DQ_PCT = (DQ_Bucket_3 + DQ_Bucket_4 + Reo_Bal + Bk_Bal + Foreclosure_Bal - DQ_And_Bk_Bucket_3 - DQ_And_Bk_Bucket_4) / Pool_Bal
    
    If DQ_PCT > (0.3175 * SEP) Then
        DQ_Trigger = True
    Else
        DQ_Trigger = False
    End If

    Workbooks("BS006HE2_Bond_Admin_Model_v1.xlsm").Sheets("Note Cals").Select
        Cells(37, 1) = "DQ_Trigger"
        Cells(37, 2) = DQ_Trigger
    Workbooks("BS006HE2_Bond_Admin_Model_v1.xlsm").Sheets("Input Data").Select
    
'Check Trigger Event Active
    If DQ_Trigger = True Or Loss_Trigger = True Then
        Trigger = True
    Else
        Trigger = False
    End If
    
    Workbooks("BS006HE2_Bond_Admin_Model_v1.xlsm").Sheets("Note Cals").Select
        Cells(38, 1) = "Trigger"
        Cells(38, 2) = Trigger
    Workbooks("BS006HE2_Bond_Admin_Model_v1.xlsm").Sheets("Input Data").Select
    
'Define Target OC
    If StepDown = False Then
        OC_Specified = 0.0365 * Pool_Bal
    ElseIf StepDown = True And Trigger = False Then
        OC_Specified = Application.WorksheetFunction.Max(Application.WorksheetFunction.Min(0.073 * Ending_Pool_Bal, OC_Floor), 3530726)
    ElseIf StepDown = True And Trigger = True Then
        OC_Specified = OC_Current
    End If
    
    Workbooks("BS006HE2_Bond_Admin_Model_v1.xlsm").Sheets("Note Cals").Select
        Cells(39, 1) = "OC_Specified"
        Cells(39, 2) = OC_Specified
        Cells(40, 1) = "Senior_ClassA_Bal"
        Cells(40, 2) = Senior_ClassA_Bal
        Cells(41, 1) = "Subordinate_Class_Bal"
        Cells(41, 2) = Subordinate_Class_Bal
    Workbooks("BS006HE2_Bond_Admin_Model_v1.xlsm").Sheets("Input Data").Select
    
    If (Senior_ClassA_Bal + Subordinate_Class_Bal) = 0 Then
        OC_Specified = 0
    End If
        
    OC_Excess = Application.WorksheetFunction.Max(0, Cert_Bal(20) - OC_Specified)
    OC_Deficiency = Application.WorksheetFunction.Max(0, OC_Specified - Cert_Bal(20))

 Workbooks("BS006HE2_Bond_Admin_Model_v1.xlsm").Sheets("Note Cals").Select
        Cells(42, 1) = "OC_Excess"
        Cells(42, 2) = OC_Excess
        Cells(43, 1) = "OC_Deficiency"
        Cells(43, 2) = OC_Deficiency
 Workbooks("BS006HE2_Bond_Admin_Model_v1.xlsm").Sheets("Input Data").Select
 
'Optional Termination Event
    If Ending_Pool_Bal < 0.1 * Orig_Pool_Bal Then
        OPT_Trigger = True
    Else
        OPT_Trigger = False
    End If

Workbooks("BS006HE2_Bond_Admin_Model_v1.xlsm").Sheets("Note Cals").Select
        Cells(43, 1) = "OPT_Trigger"
        Cells(43, 2) = OPT_Trigger
 Workbooks("BS006HE2_Bond_Admin_Model_v1.xlsm").Sheets("Input Data").Select
 

 
'Certifcate Margin
    If OPT_Trigger = False Then
        Cert_Margin(1) = 0.0008
        Cert_Margin(2) = 0.002
        Cert_Margin(3) = 0.0032
        Cert_Margin(4) = 0.002
        Cert_Margin(5) = 0.004
        Cert_Margin(6) = 0.0041
        Cert_Margin(7) = 0.0043
        Cert_Margin(8) = 0.006
        Cert_Margin(9) = 0.006
        Cert_Margin(10) = 0.0073
        Cert_Margin(11) = 0.014
        Cert_Margin(12) = 0.0155
        Cert_Margin(13) = 0.0225
        Cert_Margin(14) = 0.0225
    Else
        Cert_Margin(1) = 0.0008
        Cert_Margin(2) = 0.004
        Cert_Margin(3) = 0.0064
        Cert_Margin(4) = 0.004
        Cert_Margin(5) = 0.006
        Cert_Margin(6) = 0.00615
        Cert_Margin(7) = 0.00645
        Cert_Margin(8) = 0.009
        Cert_Margin(9) = 0.009
        Cert_Margin(10) = 0.01095
        Cert_Margin(11) = 0.021
        Cert_Margin(12) = 0.0235
        Cert_Margin(13) = 0.03375
        Cert_Margin(14) = 0.03375
    End If

'One Month LIBOR Pass-Through rate
    For R = 1 To 14
        Libor_Margin(R) = One_Mth_Libor + Cert_Margin(R)
    Next R

Net_Swap_Pmt = 0
Swap_Termination_Pmt = 0

'Net Rate Cap
    Net_Rate_Cap(1) = Application.WorksheetFunction.Max((((Loan_Grp_1_Interest * 12 / Pool_Bal_Grp1) * (30 / Actual_Days)) - ((Net_Swap_Pmt + Swap_Termination_Pmt) * 12 / Pool_Bal)), 0)
    Net_Rate_Cap(2) = Net_Rate_Cap(1)
    Net_Rate_Cap(3) = Net_Rate_Cap(1)
    
    Net_Rate_Cap(4) = Application.WorksheetFunction.Max((((Loan_Grp_2_Interest * 12 / Pool_Bal_Grp2) * (30 / Actual_Days)) - ((Net_Swap_Pmt + Swap_Termination_Pmt) * 12 / Pool_Bal)), 0)
    Net_Rate_Cap(5) = Application.WorksheetFunction.Max(((((Loan_Grp_1_Interest + Loan_Grp_2_Interest) * 12 / Pool_Bal) * (30 / Actual_Days)) - ((Net_Swap_Pmt + Swap_Termination_Pmt) * 12 / Pool_Bal)), 0)
    
    For R = 6 To 14
        Net_Rate_Cap(R) = Net_Rate_Cap(5)
    Next R
    
'Pass-Through Rate
    For R = 1 To 14
        PassThruRate(R) = Application.WorksheetFunction.Min(Net_Rate_Cap(R), Libor_Margin(R))
    Next R

'Calculate Current Interest Payable to Each Class
    Dim Current_Interest(1 To 20) As Double
    For R = 1 To 14
        Current_Interest(R) = Cert_Bal(R) * PassThruRate(R) * Actual_Days / 360
    Next R
           
'Prior Basis Risk Shortfall Calculation
    Workbooks("BS006HE2_Bond_Admin_Model_v1.xlsm").Sheets("Interest_Shortfall").Select
    Dim Cum_Unpaid_Basis_Risk_Shortfall(1 To 20) As Double
    Dim Int_On_Unpaid_Basis_Risk_Shortfall(1 To 20) As Double
    For R = 2 To 15
        Cum_Unpaid_Basis_Risk_Shortfall(R - 1) = Cells(R, 2)
        Int_On_Unpaid_Basis_Risk_Shortfall(R - 1) = Cum_Unpaid_Basis_Risk_Shortfall(R - 1) * PassThruRate(R - 1) * Actual_Days / 360
        Cum_Unpaid_Basis_Risk_Shortfall(R - 1) = Cum_Unpaid_Basis_Risk_Shortfall(R - 1) + Int_On_Unpaid_Basis_Risk_Shortfall(R - 1)
    Next R

'Prior Interest Carry Forward Amount Calculation
    Dim Cum_unpaid_int_carry_fwd_amt(1 To 20) As Double
    Dim Int_On_Unpaid_int_carry_fwd_amt(1 To 20) As Double
    For R = 25 To 44
        Cum_unpaid_int_carry_fwd_amt(R - 24) = Cells(R, 2)
        Int_On_Unpaid_int_carry_fwd_amt(R - 24) = Cum_unpaid_int_carry_fwd_amt(R - 24) * PassThruRate(R - 24) * Actual_Days / 360
        Cum_unpaid_int_carry_fwd_amt(R - 24) = Cum_unpaid_int_carry_fwd_amt(R - 24) + Int_On_Unpaid_int_carry_fwd_amt(R - 24)
    Next R

 

'Current Interest and Interest Carry Forward Amount Due
    For R = 1 To 14
        Cert_Interest_Due(R) = Current_Interest(R) + Cum_unpaid_int_carry_fwd_amt(R)
        Cert_Interest_Paid(R) = 0
    Next R




Workbooks("BS006HE2_Bond_Admin_Model_v1.xlsm").Sheets("Note Cals").Select
        Cells(44, 1) = "IRA"
        Cells(44, 2) = IRA
Workbooks("BS006HE2_Bond_Admin_Model_v1.xlsm").Sheets("Input Data").Select
 
'Interest Distributions:
    For R = 1 To 3
        Cert_Interest_Paid(R) = Application.WorksheetFunction.Min(Cert_Interest_Due(R), Loan_Grp_1_Interest)
        Cert_Interest_Due(R) = Cert_Interest_Due(R) - Cert_Interest_Paid(R)
        Loan_Grp_1_Interest = Loan_Grp_1_Interest - Cert_Interest_Paid(R)
        IRA = IRA - Cert_Interest_Paid(R)
    Next R

    Cert_Interest_Paid(4) = Application.WorksheetFunction.Min(Cert_Interest_Due(4), Loan_Grp_2_Interest)
    Cert_Interest_Due(4) = Cert_Interest_Due(4) - Cert_Interest_Paid(4)
    Loan_Grp_2_Interest = Loan_Grp_2_Interest - Cert_Interest_Paid(4)
    IRA = IRA - Cert_Interest_Paid(4)
    
    'Interest Cross
     Cert_Interest_Paid(4) = Cert_Interest_Paid(4) + Application.WorksheetFunction.Min(Cert_Interest_Due(4), Loan_Grp_1_Interest)
     Loan_Grp_1_Interest = Loan_Grp_1_Interest - Application.WorksheetFunction.Min(Cert_Interest_Due(4), Loan_Grp_1_Interest)
     IRA = IRA - Application.WorksheetFunction.Min(Cert_Interest_Due(4), Loan_Grp_1_Interest)
     Cert_Interest_Due(4) = Cert_Interest_Due(4) - Application.WorksheetFunction.Min(Cert_Interest_Due(4), Loan_Grp_1_Interest)
     
    For R = 1 To 3
        Cert_Interest_Paid(R) = Cert_Interest_Paid(R) + Application.WorksheetFunction.Min(Cert_Interest_Due(R), Loan_Grp_2_Interest)
        Loan_Grp_2_Interest = Loan_Grp_2_Interest - Application.WorksheetFunction.Min(Cert_Interest_Due(R), Loan_Grp_2_Interest)
        IRA = IRA - Application.WorksheetFunction.Min(Cert_Interest_Due(R), Loan_Grp_2_Interest)
        Cert_Interest_Due(R) = Cert_Interest_Due(R) - Application.WorksheetFunction.Min(Cert_Interest_Due(R), Loan_Grp_2_Interest)
    Next R
    
    For R = 5 To 14
        Cert_Interest_Paid(R) = Cert_Interest_Paid(R) + Application.WorksheetFunction.Min(Cert_Interest_Due(R), IRA)
        IRA = IRA - Application.WorksheetFunction.Min(Cert_Interest_Due(R), IRA)
        Cert_Interest_Due(R) = Cert_Interest_Due(R) - Application.WorksheetFunction.Min(Cert_Interest_Due(R), IRA)
    Next R
    
Dim Int_Sum As Double
Int_Sum = 0
For R = 1 To 14
Int_Sum = Int_Sum + Cert_Interest_Paid(R)
Next R
    
Workbooks("BS006HE2_Bond_Admin_Model_v1.xlsm").Sheets("Note Cals").Select
        Cells(45, 1) = "Remaining IRA"
        Cells(45, 2) = IRA
        Cells(46, 1) = "Int_Sum"
        Cells(46, 2) = Int_Sum
Workbooks("BS006HE2_Bond_Admin_Model_v1.xlsm").Sheets("Input Data").Select

    
'Current Interest Carry Forward Amount
    Dim cur_int_carry_forward_amt(1 To 20) As Double
    For R = 1 To 14
        cur_int_carry_forward_amt(R) = Cert_Interest_Due(R)
    Next R

 
'Set Total Monthly Excess Spread
    TMES = Application.WorksheetFunction.Max(0, IRA)
    
'Set Basic Principal Distribution Amount BPDA
    BPDA = Application.WorksheetFunction.Max(0, PRA - OC_Excess)
    
'Set Extra Principal Distribution Amount EPDA
    EPDA = Application.WorksheetFunction.Min(TMES, OC_Deficiency)
    TMES = TMES - EPDA
    
'Set Principal Distribution Amount PDA
    PDA = EPDA + BPDA


 


'Principal Distributions:
If StepDown = False Or Trigger = True Then  'Before Step Down: ///////////////////////////////
        
            ClassA1_Principal_Allocation_Percentage = Loan_Grp_1_Principal / (Loan_Grp_1_Principal + Loan_Grp_2_Principal)
            ClassA2_Principal_Allocation_Percentage = Loan_Grp_2_Principal / (Loan_Grp_1_Principal + Loan_Grp_2_Principal)
            ClassA1_Distribution_Amount = ClassA1_Principal_Allocation_Percentage * PDA
            ClassA2_Distribution_Amount = ClassA2_Principal_Allocation_Percentage * PDA
            
            
            
            'Payoff Class I-A-1, I-A-2, I-A-3 using Group 1 Principal
            For i = 1 To 3
                Prin_Class_I_A(i) = Prin_Class_I_A(i) + Application.WorksheetFunction.Min(Cert_Bal(i), ClassA1_Distribution_Amount)
                ClassA1_Distribution_Amount = ClassA1_Distribution_Amount - Prin_Class_I_A(i)
                Cert_Bal(i) = Cert_Bal(i) - Prin_Class_I_A(i)
            Next i
            
           
            
            
            'Payoff Class II_A using Group 2 Principal
            Prin_Class_II_A = Prin_Class_II_A + Application.WorksheetFunction.Min(Cert_Bal(4), ClassA2_Distribution_Amount)
            ClassA2_Distribution_Amount = ClassA2_Distribution_Amount - Prin_Class_II_A
            Cert_Bal(4) = Cert_Bal(4) - Prin_Class_II_A
            
            
            'Payoff Class II_A using Group 1 Principal
            Prin_Class_II_A = Prin_Class_II_A + Application.WorksheetFunction.Min(Cert_Bal(4), ClassA1_Distribution_Amount)
            ClassA1_Distribution_Amount = ClassA1_Distribution_Amount - Application.WorksheetFunction.Min(Cert_Bal(4), ClassA1_Distribution_Amount)
            Cert_Bal(4) = Cert_Bal(4) - Application.WorksheetFunction.Min(Cert_Bal(4), ClassA1_Distribution_Amount)
            
            Cert_Principal_Paid(4) = Prin_Class_II_A
            
            'Payoff Class I-A-1, I-A-2, I-A-3 using Group 2 Principal (Prorata)
            For i = 1 To 3
                Prin_Class_I_A(i) = Prin_Class_I_A(i) + Application.WorksheetFunction.Min(Cert_Bal(i), ClassA2_Distribution_Amount * Cert_Bal(i) / (Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3)))
                ClassA2_Distribution_Amount = ClassA2_Distribution_Amount - Application.WorksheetFunction.Min(Cert_Bal(i), ClassA2_Distribution_Amount * Cert_Bal(i) / (Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3)))
                Cert_Bal(i) = Cert_Bal(i) - Application.WorksheetFunction.Min(Cert_Bal(i), ClassA2_Distribution_Amount * Cert_Bal(i) / (Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3)))
                Cert_Principal_Paid(i) = Prin_Class_I_A(i)
            Next i
            
            'Principal Distribution Amount Left After Paying Senior Classes:
            PDA = PDA - (Cert_Principal_Paid(1) + Cert_Principal_Paid(2) + Cert_Principal_Paid(3) + Cert_Principal_Paid(4))
    
        'Now Pay All M1-M10 Classes Sequentially:
        For i = 5 To 14
            Cert_Principal_Paid(i) = Application.WorksheetFunction.Min(Cert_Bal(i), PDA)
            PDA = PDA - Cert_Principal_Paid(i)
            Cert_Bal(i) = Cert_Bal(i) - Cert_Principal_Paid(i)
        Next i
        
ElseIf StepDown = True And Trigger = False Then 'After Step Down: ///////////////////////////////////////////////////////////////////////
    
    Dim ClassA_PDA As Double
    ClassA_PDA = Application.WorksheetFunction.Min(PDA, Application.WorksheetFunction.Max(Senior_ClassA_Bal - Application.WorksheetFunction.Min(0.498 * End_Pool_Bal, End_Pool_Bal - 3530726), 0))
            ClassA1_Principal_Allocation_Percentage = Loan_Grp_1_Principal / (Loan_Grp_1_Principal + Loan_Grp_2_Principal)
            ClassA2_Principal_Allocation_Percentage = Loan_Grp_2_Principal / (Loan_Grp_1_Principal + Loan_Grp_2_Principal)
            ClassA1_Distribution_Amount = ClassA1_Principal_Allocation_Percentage * ClassA_PDA
            ClassA2_Distribution_Amount = ClassA2_Principal_Allocation_Percentage * ClassA_PDA
            
            'Payoff Class I-A-1, I-A-2, I-A-3 using Group 1 Principal
            For i = 1 To 3
                Prin_Class_I_A(i) = Prin_Class_I_A(i) + Application.WorksheetFunction.Min(Cert_Bal(i), ClassA1_Distribution_Amount)
                ClassA1_Distribution_Amount = ClassA1_Distribution_Amount - Prin_Class_I_A(i)
                Cert_Bal(i) = Cert_Bal(i) - Prin_Class_I_A(i)
            Next i
            
           

            'Payoff Class II_A using Group 2 Principal
            Prin_Class_II_A = Prin_Class_II_A + Application.WorksheetFunction.Min(Cert_Bal(4), ClassA2_Distribution_Amount)
            ClassA2_Distribution_Amount = ClassA2_Distribution_Amount - Prin_Class_II_A
            Cert_Bal(4) = Cert_Bal(4) - Prin_Class_II_A
            
            'Payoff Class II_A using Group 1 Principal
            Prin_Class_II_A = Prin_Class_II_A + Application.WorksheetFunction.Min(Cert_Bal(1), ClassA1_Distribution_Amount)
            ClassA1_Distribution_Amount = ClassA1_Distribution_Amount - Prin_Class_II_A
            Cert_Bal(4) = Cert_Bal(4) - Prin_Class_II_A
            
            Cert_Principal_Paid(4) = Prin_Class_II_A
            
            'Payoff Class I-A-1, I-A-2, I-A-3 using Group 2 Principal
            For i = 1 To 3
                Prin_Class_I_A(i) = Prin_Class_I_A(i) + Application.WorksheetFunction.Min(Cert_Bal(i), ClassA2_Distribution_Amount)
                ClassA2_Distribution_Amount = ClassA2_Distribution_Amount - Prin_Class_I_A(i)
                Cert_Bal(i) = Cert_Bal(i) - Prin_Class_I_A(i)
                Cert_Principal_Paid(i) = Prin_Class_I_A(i)
            Next i
            
            'Principal Distribution Amount Left After Paying Senior Classes:
            PDA = PDA - (Cert_Principal_Paid(1) + Cert_Principal_Paid(2) + Cert_Principal_Paid(3) + Cert_Principal_Paid(4))
            
        'Now Pay the Class M1:
        ClassM1_PDA = Application.WorksheetFunction.Min(PDA, Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5)) - Application.WorksheetFunction.Min(0.591 * Ending_Pool_Bal, Ending_Pool_Bal - 3530726))))
        Cert_Principal_Paid(5) = Application.WorksheetFunction.Min(Cert_Bal(5), ClassM1_PDA)
        Cert_Bal(5) = Cert_Bal(5) - Cert_Principal_Paid(5)
        PDA = PDA - Cert_Principal_Paid(5)
        
        'Now Pay the Class M2:
        ClassM2_PDA = Application.WorksheetFunction.Min(PDA, Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6)) - Application.WorksheetFunction.Min(0.665 * Ending_Pool_Bal, Ending_Pool_Bal - 3530726))))
        Cert_Principal_Paid(6) = Application.WorksheetFunction.Min(Cert_Bal(6), ClassM2_PDA)
        Cert_Bal(6) = Cert_Bal(6) - Cert_Principal_Paid(6)
        PDA = PDA - Cert_Principal_Paid(6)
        
        'Now Pay the Class M3:
        ClassM3_PDA = Application.WorksheetFunction.Min(PDA, Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7)) - Application.WorksheetFunction.Min(0.71 * Ending_Pool_Bal, Ending_Pool_Bal - 3530726))))
        Cert_Principal_Paid(7) = Application.WorksheetFunction.Min(Cert_Bal(7), ClassM3_PDA)
        Cert_Bal(7) = Cert_Bal(7) - Cert_Principal_Paid(7)
        PDA = PDA - Cert_Principal_Paid(7)
        
        'Now Pay the Class M4:
        ClassM4_PDA = Application.WorksheetFunction.Min(PDA, Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8)) - Application.WorksheetFunction.Min(0.749 * Ending_Pool_Bal, Ending_Pool_Bal - 3530726))))
        Cert_Principal_Paid(8) = Application.WorksheetFunction.Min(Cert_Bal(8), ClassM4_PDA)
        Cert_Bal(8) = Cert_Bal(8) - Cert_Principal_Paid(8)
        PDA = PDA - Cert_Principal_Paid(8)
        
        'Now Pay the Class M5:
        ClassM5_PDA = Application.WorksheetFunction.Min(PDA, Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8) + Cert_Bal(9)) - Application.WorksheetFunction.Min(0.786 * Ending_Pool_Bal, Ending_Pool_Bal - 3530726))))
        Cert_Principal_Paid(9) = Application.WorksheetFunction.Min(Cert_Bal(9), ClassM5_PDA)
        Cert_Bal(9) = Cert_Bal(9) - Cert_Principal_Paid(9)
        PDA = PDA - Cert_Principal_Paid(9)
        
        'Now Pay the Class M6:
        ClassM6_PDA = Application.WorksheetFunction.Min(PDA, Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8) + Cert_Bal(9) + Cert_Bal(10)) - Application.WorksheetFunction.Min(0.82 * Ending_Pool_Bal, Ending_Pool_Bal - 3530726))))
        Cert_Principal_Paid(10) = Application.WorksheetFunction.Min(Cert_Bal(10), ClassM6_PDA)
        Cert_Bal(10) = Cert_Bal(10) - Cert_Principal_Paid(10)
        PDA = PDA - Cert_Principal_Paid(10)
        
        'Now Pay the Class M7:
        ClassM7_PDA = Application.WorksheetFunction.Min(PDA, Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8) + Cert_Bal(9) + Cert_Bal(10) + Cert_Bal(11)) - Application.WorksheetFunction.Min(0.851 * Ending_Pool_Bal, Ending_Pool_Bal - 3530726))))
        Cert_Principal_Paid(11) = Application.WorksheetFunction.Min(Cert_Bal(11), ClassM7_PDA)
        Cert_Bal(11) = Cert_Bal(11) - Cert_Principal_Paid(11)
        PDA = PDA - Cert_Principal_Paid(11)
        
        'Now Pay the Class M8:
        ClassM8_PDA = Application.WorksheetFunction.Min(PDA, Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8) + Cert_Bal(9) + Cert_Bal(10) + Cert_Bal(11) + Cert_Bal(12)) - Application.WorksheetFunction.Min(0.879 * Ending_Pool_Bal, Ending_Pool_Bal - 3530726))))
        Cert_Principal_Paid(12) = Application.WorksheetFunction.Min(Cert_Bal(12), ClassM1_PDA)
        Cert_Bal(12) = Cert_Bal(12) - Cert_Principal_Paid(12)
        PDA = PDA - Cert_Principal_Paid(12)
        
        'Now Pay the Class M9:
        ClassM9_PDA = Application.WorksheetFunction.Min(PDA, Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8) + Cert_Bal(9) + Cert_Bal(10) + Cert_Bal(11) + Cert_Bal(12) + Cert_Bal(13)) - Application.WorksheetFunction.Min(0.902 * Ending_Pool_Bal, Ending_Pool_Bal - 3530726))))
        Cert_Principal_Paid(13) = Application.WorksheetFunction.Min(Cert_Bal(13), ClassM1_PDA)
        Cert_Bal(13) = Cert_Bal(13) - Cert_Principal_Paid(13)
        PDA = PDA - Cert_Principal_Paid(13)
        
        'Now Pay the Class M10:
        ClassM10_PDA = Application.WorksheetFunction.Min(PDA, Application.WorksheetFunction.Max(0, ((Cert_Bal(1) + Cert_Bal(2) + Cert_Bal(3) + Cert_Bal(4) + Cert_Bal(5) + Cert_Bal(6) + Cert_Bal(7) + Cert_Bal(8) + Cert_Bal(9) + Cert_Bal(10) + Cert_Bal(11) + Cert_Bal(12) + Cert_Bal(13) + Cert_Bal(14)) - Application.WorksheetFunction.Min(0.927 * Ending_Pool_Bal, Ending_Pool_Bal - 3530726))))
        Cert_Principal_Paid(14) = Application.WorksheetFunction.Min(Cert_Bal(14), ClassM1_PDA)
        Cert_Bal(14) = Cert_Bal(14) - Cert_Principal_Paid(14)
        PDA = PDA - Cert_Principal_Paid(14)
        
End If



Dim Excess_CashFlow As Double
Excess_CashFlow = TMES + PDA

 
Dim Ratio(1 To 4) As Double
Dim Class_A_Int_Carry_Fwd_Amt As Double
Class_A_Int_Carry_Fwd_Amt = cur_int_carry_forward_amt(1) + cur_int_carry_forward_amt(2) + cur_int_carry_forward_amt(3) + cur_int_carry_forward_amt(4)

If Class_A_Int_Carry_Fwd_Amt > 0 Then
For R = 1 To 4
Ratio(R) = cur_int_carry_forward_amt(R) / (Class_A_Int_Carry_Fwd_Amt)
Next R
End If

'Remaining Carry Forward Amount Interest Distributions:
    For R = 1 To 4
        Cert_Interest_Paid(R) = Cert_Interest_Paid(R) + Application.WorksheetFunction.Min(cur_int_carry_forward_amt(R), Ratio(R) * Excess_CashFlow)
        cur_int_carry_forward_amt(R) = cur_int_carry_forward_amt(R) - Application.WorksheetFunction.Min(cur_int_carry_forward_amt(R), Ratio(R) * Excess_CashFlow)
        Excess_CashFlow = Excess_CashFlow - Application.WorksheetFunction.Min(cur_int_carry_forward_amt(R), Ratio(R) * Excess_CashFlow)
    Next R

    For R = 5 To 14
        Cert_Interest_Paid(R) = Cert_Interest_Paid(R) + Application.WorksheetFunction.Min(cur_int_carry_forward_amt(R), Excess_CashFlow)
        Excess_CashFlow = Excess_CashFlow - Application.WorksheetFunction.Min(cur_int_carry_forward_amt(R), Excess_CashFlow)
    Next R

Reserve_Fund = Reserve_Fund + Excess_CashFlow

Dim Ratio_Basis_Risk_Shortfall(1 To 4) As Double
Dim Class_A_Basis_Risk_Shortfall_Amt As Double
Class_A_Basis_Risk_Shortfall_Amt = Cum_Unpaid_Basis_Risk_Shortfall(1) + Cum_Unpaid_Basis_Risk_Shortfall(2) + Cum_Unpaid_Basis_Risk_Shortfall(3) + Cum_Unpaid_Basis_Risk_Shortfall(4)


If Class_A_Basis_Risk_Shortfall_Amt > 0 Then
For R = 1 To 4
Ratio_Basis_Risk_Shortfall(R) = Cum_Unpaid_Basis_Risk_Shortfall(R) / Class_A_Basis_Risk_Shortfall_Amt
Next R
End If

'Pay basis risk carry forward amount
    For R = 1 To 4
        Cert_Interest_Paid(R) = Cert_Interest_Paid(R) + Application.WorksheetFunction.Min(Cum_Unpaid_Basis_Risk_Shortfall(R), Ratio_Basis_Risk_Shortfall(R) * Reserve_Fund)
        cur_int_carry_forward_amt(R) = cur_int_carry_forward_amt(R) - Application.WorksheetFunction.Min(Cum_Unpaid_Basis_Risk_Shortfall(R), Ratio_Basis_Risk_Shortfall(R) * Reserve_Fund)
        Reserve_Fund = Reserve_Fund - Application.WorksheetFunction.Min(Cum_Unpaid_Basis_Risk_Shortfall(R), Ratio_Basis_Risk_Shortfall(R) * Reserve_Fund)
    Next R
    
    For R = 5 To 14
        Cert_Interest_Paid(R) = Cert_Interest_Paid(R) + Application.WorksheetFunction.Min(Cum_Unpaid_Basis_Risk_Shortfall(R), Reserve_Fund)
        Reserve_Fund = Reserve_Fund - Application.WorksheetFunction.Min(Cum_Unpaid_Basis_Risk_Shortfall(R), Reserve_Fund)
    Next R
    
    Excess_CashFlow = Reserve_Fund
    Reserve_Fund = 0
    Reserve_Fund = Application.WorksheetFunction.Min(5000, Excess_CashFlow)
    Excess_CashFlow = Excess_CashFlow - Reserve_Fund



'Relief Act Shortfall
Excess_CashFlow = Application.WorksheetFunction.Max(Excess_CashFlow - Relief_Act_Shortfall, 0)

'PPIS
Excess_CashFlow = Application.WorksheetFunction.Max(Excess_CashFlow - PPIS, 0)

'Principal And Interest Payments to X Class: All Excess Interest over the OC Definicency will go to X class
    Cert_Interest_Paid(20) = Excess_CashFlow
    Cert_Principal_Paid(20) = OC_Excess - OC_Deficiency
    Cert_Bal(20) = Cert_Bal(20) - Cert_Principal_Paid(20)

'Class P Distributions
Cert_Principal_Paid(15) = 0
Cert_Interest_Paid(15) = Cells(13, 222)

'Class R1,R2,R3,RX Distributions
Cert_Principal_Paid(16) = 0
Cert_Interest_Paid(16) = 0
Cert_Principal_Paid(17) = 0
Cert_Interest_Paid(17) = 0
Cert_Principal_Paid(18) = 0
Cert_Interest_Paid(18) = 0
Cert_Principal_Paid(19) = 0
Cert_Interest_Paid(19) = 0

'Print the payments
Workbooks("BS006HE2_Bond_Admin_Model_v1.xlsm").Sheets("Note Cals").Select
  For i = 1 To 20
      Cells(i + 1, 4) = Cert_Interest_Paid(i)
      Cells(i + 1, 5) = Cert_Principal_Paid(i)
  Next i
 
End Sub



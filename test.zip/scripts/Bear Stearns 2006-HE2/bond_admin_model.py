"""
Bond Administration Model for Bear Stearns 2006-HE2 Deal
Python rewrite of VBA code from model1.vb

This script models monthly cash flow distributions for the MBS deal.
It reads inputs from CSV files, performs calculations, and outputs results to CSV.

Requirements: pip install pandas numpy
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple

def parse_value(val) -> float:
    """Parse string or numeric to float, handling $ , -"""
    if isinstance(val, str):
        val = val.replace('$', '').replace(',', '').strip()
        if val in ['-', '', 'NULL']:
            return 0.0
        try:
            return float(val)
        except ValueError:
            return 0.0
    return float(val) if pd.notna(val) else 0.0

# Constants and configuration
CERT_MARGINS_NORMAL = {
    1: 0.0008, 2: 0.002, 3: 0.0032, 4: 0.002,
    5: 0.004, 6: 0.0041, 7: 0.0043, 8: 0.006,
    9: 0.006, 10: 0.0073, 11: 0.014, 12: 0.0155,
    13: 0.0225, 14: 0.0225
}

CERT_MARGINS_OPT = {
    1: 0.0008, 2: 0.004, 3: 0.0064, 4: 0.004,
    5: 0.006, 6: 0.00615, 7: 0.00645, 8: 0.009,
    9: 0.009, 10: 0.01095, 11: 0.021, 12: 0.0235,
    13: 0.03375, 14: 0.03375
}

OC_FLOOR = 0.0365 * 706145220.18  # 3.65% of original pool balance
RESERVE_FLOOR = 5000
SSEP = 0.502  # Specified Senior Enhancement %
OC_MIN = 3530726

def load_input_data(base_path: str) -> Dict[str, pd.DataFrame]:
    """
    Load CSV files into pandas DataFrames, mimicking Excel sheets.

    Args:
        base_path: Directory path where CSV files are located (e.g., 'c:/data/')

    Returns:
        Dict of DataFrames: {'input_data': df, 'note_cals': df, 'manual_input': df, 'interest_shortfall': df}
    """
    files = {
        'input_data': 'input_data.csv',
        'note_cals': 'note_cals.csv',
        'manual_input': 'manual_input.csv',
        'interest_shortfall': 'interest_shortfall.csv'
    }
    data = {}
    for key, filename in files.items():
        try:
            if key == 'manual_input':
                data[key] = pd.read_csv(f"{base_path}/{filename}", header=None)
            elif key == 'input_data':
                df = pd.read_csv(f"{base_path}/{filename}", header=0)
                data[key] = df.set_index('Item')['Value'].to_dict()
            else:
                data[key] = pd.read_csv(f"{base_path}/{filename}", header=0)
        except FileNotFoundError:
            raise FileNotFoundError(f"Required file {filename} not found in {base_path}")
    return data

def extract_manual_inputs(df_manual: pd.DataFrame) -> Dict[str, float]:
    """
    Extract scalar inputs from manual_input.csv.

    Assumes the CSV has no headers and data starts from row 0.
    """
    inputs = {}
    # Map row indices to keys (0-based, no header)
    mappings = {
        0: 'prior_month_stepdown',
        1: 'one_mth_libor',
        2: 'actual_days',
        3: 'dist_count',
        4: 'ppis',
        5: 'relief_act_shortfall',
        6: 'reserve_fund'
    }
    for row_idx, key in mappings.items():
        if row_idx < len(df_manual):
            value = df_manual.iloc[row_idx, 1]
            if isinstance(value, str):
                # Remove $ and commas if present
                value = value.replace('$', '').replace(',', '').strip()
                if value in ['-', '']:
                    value = 0
                else:
                    value = float(value)
            inputs[key] = value
        else:
            inputs[key] = 0
    return inputs

def initialize_certificates(df_note_cals: pd.DataFrame) -> Tuple[List[float], List[float]]:
    """
    Initialize certificate balances from note_cals.csv.

    Returns:
        orig_cert_bal: List of original balances (indices 1-20)
        cert_bal: List of current balances (indices 1-20)
    """
    orig_cert_bal = [0] * 21  # 1-based indexing
    cert_bal = [0] * 21
    for r in range(0, 20):  # Rows 1-20 in 1-based (pandas 0-19)
        orig_val = df_note_cals.iloc[r, 1]  # Column B (1)
        curr_val = df_note_cals.iloc[r, 2]  # Column C (2)
        if isinstance(orig_val, str):
            orig_val = orig_val.replace('$', '').replace(',', '').strip()
            orig_val = 0 if orig_val in ['-', ''] else float(orig_val)
        if isinstance(curr_val, str):
            curr_val = curr_val.replace('$', '').replace(',', '').strip()
            curr_val = 0 if curr_val in ['-', ''] else float(curr_val)
        cert_bal[r+1] = curr_val
        orig_cert_bal[r+1] = orig_val
        # Sum for adjustment
    # Adjust for class 20 (CE class)
    orig_cert_bal[20] = 706145220.18 - sum(orig_cert_bal[1:15]) + orig_cert_bal[15]
    return orig_cert_bal, cert_bal

def calculate_pool_metrics(data_input: Dict[str, float]) -> Dict[str, float]:
    """
    Calculate pool balances, IRA, PRA, etc. from input_data.
    """
    pool_bal = data_input['pool_bal']
    ending_pool_bal = data_input['ending_pool_bal']
    pool_bal_grp1 = data_input['pool_bal_grp1']
    pool_bal_grp2 = data_input['pool_bal_grp2']
    ending_pool_bal_grp1 = data_input['ending_pool_bal_grp1']
    ending_pool_bal_grp2 = data_input['ending_pool_bal_grp2']

    loan_grp_1_principal = data_input['loan_grp_1_principal']
    loan_grp_1_interest = data_input['loan_grp_1_interest']
    loan_grp_2_principal = data_input['loan_grp_2_principal']
    loan_grp_2_interest = data_input['loan_grp_2_interest']

    ira = loan_grp_1_interest + loan_grp_2_interest
    pra = loan_grp_1_principal + loan_grp_2_principal

    return {
        'pool_bal': pool_bal, 'ending_pool_bal': ending_pool_bal,
        'pool_bal_grp1': pool_bal_grp1, 'pool_bal_grp2': pool_bal_grp2,
        'ending_pool_bal_grp1': ending_pool_bal_grp1, 'ending_pool_bal_grp2': ending_pool_bal_grp2,
        'loan_grp_1_principal': loan_grp_1_principal, 'loan_grp_1_interest': loan_grp_1_interest,
        'loan_grp_2_principal': loan_grp_2_principal, 'loan_grp_2_interest': loan_grp_2_interest,
        'ira': ira, 'pra': pra
    }

def calculate_senior_metrics(cert_bal: List[float], pool_bal: float) -> Dict[str, float]:
    """
    Calculate SEP, OC, etc.
    """
    senior_class_a_bal = sum(cert_bal[1:5])  # 1-4
    subordinate_class_bal = sum(cert_bal[5:15])  # 5-14
    oc_current = pool_bal - (senior_class_a_bal + subordinate_class_bal)
    sep = (pool_bal - senior_class_a_bal) / pool_bal if pool_bal > 0 else 0
    return {
        'senior_class_a_bal': senior_class_a_bal,
        'subordinate_class_bal': subordinate_class_bal,
        'oc_current': oc_current, 'sep': sep
    }

def evaluate_triggers(data_input: Dict[str, float], dist_count: int, sep: float, cert_bal: List[float]) -> Dict[str, bool]:
    """
    Evaluate step-down, loss, DQ triggers.
    """
    # Loss trigger
    loan_grp_1_cum_loss = data_input['loan_grp_1_cum_loss']
    loan_grp_2_cum_loss = data_input['loan_grp_2_cum_loss']
    cum_realized_loss = loan_grp_1_cum_loss + loan_grp_2_cum_loss
    loss_pct = cum_realized_loss / 706145220.18
    dq_bucket_3 = data_input['dq_bucket_3']
    dq_bucket_4 = data_input['dq_bucket_4']
    reo_bal = data_input['reo_bal']
    bk_bal = data_input['bk_bal']
    foreclosure_bal = data_input['foreclosure_bal']
    dq_and_bk_bucket_3 = data_input['dq_and_bk_bucket_3']
    dq_and_bk_bucket_4 = data_input['dq_and_bk_bucket_4']
    dq_pct = (dq_bucket_3 + dq_bucket_4 + reo_bal + bk_bal + foreclosure_bal - dq_and_bk_bucket_3 - dq_and_bk_bucket_4) / data_input['pool_bal']

    loss_trigger = (
        (dist_count > 72 and dq_pct > 0.0775) or
        (dist_count > 60 and dist_count <= 73 and dq_pct > 0.0725) or
        (dist_count > 48 and dist_count <= 61 and dq_pct > 0.058) or
        (dist_count > 36 and dist_count <= 49 and dq_pct > 0.037)
    )
    dq_trigger = dq_pct > (0.3175 * sep)
    trigger = loss_trigger or dq_trigger

    # Step-down
    prior_month_stepdown = data_input['prior_month_stepdown'] == 1
    step_down = (
        sum(cert_bal[1:5]) == 0 or prior_month_stepdown or
        (dist_count > 36 and sep > SSEP)
    )

    return {
        'step_down': step_down, 'loss_trigger': loss_trigger,
        'dq_trigger': dq_trigger, 'trigger': trigger
    }

def calculate_oc_specified(step_down: bool, trigger: bool, pool_bal: float, ending_pool_bal: float, senior_class_a_bal: float, oc_current: float) -> float:
    """
    Calculate target OC.
    """
    if not step_down:
        return 0.0365 * pool_bal
    elif step_down and not trigger:
        return max(min(0.073 * ending_pool_bal, OC_FLOOR), OC_MIN)
    else:
        return oc_current  # From earlier

def calculate_rates_and_margins(cert_bal: List[float], opt_trigger: bool, one_mth_libor: float, pool_bal_grp1: float, pool_bal_grp2: float, loan_grp_1_interest: float, loan_grp_2_interest: float, actual_days: int) -> Dict[str, List[float]]:
    """
    Calculate margins, pass-through rates, interest.
    """
    cert_margin = CERT_MARGINS_OPT if opt_trigger else CERT_MARGINS_NORMAL
    libor_margin = [one_mth_libor + cert_margin.get(i, 0) for i in range(1, 15)]

    # Net rate cap
    net_rate_cap = [0] * 15
    net_rate_cap[1] = max(((loan_grp_1_interest * 12 / pool_bal_grp1) * (30 / actual_days)), 0)
    net_rate_cap[2] = net_rate_cap[1]
    net_rate_cap[3] = net_rate_cap[1]
    net_rate_cap[4] = max(((loan_grp_2_interest * 12 / pool_bal_grp2) * (30 / actual_days)), 0)
    net_rate_cap[5] = max((((loan_grp_1_interest + loan_grp_2_interest) * 12 / (pool_bal_grp1 + pool_bal_grp2)) * (30 / actual_days)), 0)
    for i in range(6, 15):
        net_rate_cap[i] = net_rate_cap[5]

    pass_thru_rate = [min(net_rate_cap[i], libor_margin[i-1]) for i in range(1, 15)]
    current_interest = [cert_bal[i] * pass_thru_rate[i-1] * actual_days / 360 for i in range(1, 15)]

    return {
        'cert_margin': cert_margin, 'libor_margin': libor_margin,
        'net_rate_cap': net_rate_cap, 'pass_thru_rate': pass_thru_rate,
        'current_interest': current_interest
    }

def distribute_interest(cert_interest_due: List[float], loan_grp_1_interest: float, loan_grp_2_interest: float, ira: float) -> Tuple[List[float], float, float, float]:
    """
    Distribute interest to classes.
    """
    cert_interest_paid = [0] * 21
    # Senior classes 1-3 from group 1
    for i in [1,2,3]:
        cert_interest_paid[i] = min(cert_interest_due[i], loan_grp_1_interest)
        cert_interest_due[i] -= cert_interest_paid[i]
        loan_grp_1_interest -= cert_interest_paid[i]
        ira -= cert_interest_paid[i]

    # Class 4 from group 2
    cert_interest_paid[4] = min(cert_interest_due[4], loan_grp_2_interest)
    cert_interest_due[4] -= cert_interest_paid[4]
    loan_grp_2_interest -= cert_interest_paid[4]
    ira -= cert_interest_paid[4]

    # Cross for class 4
    cert_interest_paid[4] += min(cert_interest_due[4], loan_grp_1_interest)
    loan_grp_1_interest -= min(cert_interest_due[4], loan_grp_1_interest)
    ira -= min(cert_interest_due[4], loan_grp_1_interest)
    cert_interest_due[4] -= min(cert_interest_due[4], loan_grp_1_interest)

    # Cross back to 1-3
    for i in [1,2,3]:
        cert_interest_paid[i] += min(cert_interest_due[i], loan_grp_2_interest)
        loan_grp_2_interest -= min(cert_interest_due[i], loan_grp_2_interest)
        ira -= min(cert_interest_due[i], loan_grp_2_interest)
        cert_interest_due[i] -= min(cert_interest_due[i], loan_grp_2_interest)

    # Subordinates
    for i in range(5, 15):
        cert_interest_paid[i] += min(cert_interest_due[i], ira)
        ira -= min(cert_interest_due[i], ira)
        cert_interest_due[i] -= min(cert_interest_due[i], ira)

    return cert_interest_paid, cert_interest_due, loan_grp_1_interest, loan_grp_2_interest, ira

def distribute_principal(pda: float, cert_bal: List[float], step_down: bool, trigger: bool, ending_pool_bal: float, senior_class_a_bal: float, loan_grp_1_principal: float, loan_grp_2_principal: float) -> List[float]:
    """
    Distribute principal based on step-down and trigger.
    """
    cert_principal_paid = [0] * 21
    if not step_down or trigger:
        # Pro-rata allocation
        class_a1_pct = loan_grp_1_principal / (loan_grp_1_principal + loan_grp_2_principal) if (loan_grp_1_principal + loan_grp_2_principal) > 0 else 0
        class_a2_pct = 1 - class_a1_pct
        class_a1_dist = class_a1_pct * pda
        class_a2_dist = class_a2_pct * pda

        # Pay seniors
        for i in [1,2,3]:
            prin = min(cert_bal[i], class_a1_dist)
            cert_principal_paid[i] += prin
            class_a1_dist -= prin
            cert_bal[i] -= prin

        prin = min(cert_bal[4], class_a2_dist)
        cert_principal_paid[4] += prin
        class_a2_dist -= prin
        cert_bal[4] -= prin

        # Cross
        prin = min(cert_bal[4], class_a1_dist)
        cert_principal_paid[4] += prin
        class_a1_dist -= prin
        cert_bal[4] -= prin

        # Pro-rata for 1-3 from group 2
        remaining = sum(cert_bal[1:4])
        if remaining > 0:
            for i in [1,2,3]:
                prin = min(cert_bal[i], class_a2_dist * (cert_bal[i] / remaining))
                cert_principal_paid[i] += prin
                class_a2_dist -= prin
                cert_bal[i] -= prin

        pda -= sum(cert_principal_paid[1:5])

        # Subordinates sequentially
        for i in range(5, 15):
            prin = min(cert_bal[i], pda)
            cert_principal_paid[i] += prin
            pda -= prin
            cert_bal[i] -= prin
    else:
        # Step-down logic (simplified, full implementation needed)
        # This is complex; implement lockouts as in VBA
        pass  # Placeholder for full step-down distribution

    return cert_principal_paid

def handle_excess_and_shortfalls(tmes: float, pda: float, oc_excess: float, oc_deficiency: float, cert_interest_paid: List[float], cert_principal_paid: List[float], reserve_fund: float, ppis: float, relief_act_shortfall: float, cert_bal: List[float]) -> Tuple[List[float], List[float], float]:
    """
    Handle excess cash flow, shortfalls, reserves.
    """
    # Excess interest (remaining IRA after distribution to certs 1-19)
    excess_interest = tmes

    # Calculate reserve fund deficiency (target - current)
    reserve_deficiency = max(0, RESERVE_FLOOR - reserve_fund)
    
    # Pay reserve deficiency from excess interest
    reserve_deposit = min(reserve_deficiency, excess_interest)
    excess_interest -= reserve_deposit
    reserve_fund += reserve_deposit

    # Shortfalls (from excess interest)
    excess_interest = max(excess_interest - relief_act_shortfall, 0)
    excess_interest = max(excess_interest - ppis, 0)

    # CE class interest and principal
    cert_interest_paid[20] = excess_interest
    cert_principal_paid[20] = pda + (oc_excess - oc_deficiency)
    cert_bal[20] -= cert_principal_paid[20]

    return cert_interest_paid, cert_principal_paid, reserve_fund

def write_results(cert_interest_paid: List[float], cert_principal_paid: List[float], output_path: str):
    """
    Write results to CSV.
    """
    results = pd.DataFrame({
        'Class': range(1, 21),
        'Interest_Paid': cert_interest_paid[1:],
        'Principal_Paid': cert_principal_paid[1:]
    })
    results.to_csv(output_path, index=False)

def run_bond_admin_model(base_path: str, output_path: str):
    """
    Main function to run the model.
    """
    debug_file = open("debug.txt", "w")
    
    # Load data
    data = load_input_data(base_path)
    debug_file.write(f"Line ~380: Loaded data - Input data keys: {list(data['input_data'].keys())[:5]}..., Note cals shape: {data['note_cals'].shape}, Manual input shape: {data['manual_input'].shape}, Interest shortfall shape: {data['interest_shortfall'].shape}\n")
    
    manual_inputs = extract_manual_inputs(data['manual_input'])
    debug_file.write(f"Line ~383: Manual inputs: {manual_inputs}\n")
    
    orig_cert_bal, cert_bal = initialize_certificates(data['note_cals'])
    debug_file.write(f"Line ~386: Cert balances: {cert_bal[1:21]}\n")
    
    pool_metrics = calculate_pool_metrics(data['input_data'])
    debug_file.write(f"Line ~389: Pool metrics: {pool_metrics}\n")
    
    senior_metrics = calculate_senior_metrics(cert_bal, pool_metrics['pool_bal'])
    debug_file.write(f"Line ~392: Senior metrics: {senior_metrics}\n")
    
    # Triggers
    triggers = evaluate_triggers(data['input_data'], manual_inputs['dist_count'], senior_metrics['sep'], cert_bal)
    debug_file.write(f"Line ~396: Triggers: {triggers}\n")
    
    # OC
    oc_specified = calculate_oc_specified(triggers['step_down'], triggers['trigger'], pool_metrics['pool_bal'], pool_metrics['ending_pool_bal'], senior_metrics['senior_class_a_bal'], senior_metrics['oc_current'])
    oc_excess = max(0, senior_metrics['oc_current'] - oc_specified)
    oc_deficiency = max(0, oc_specified - senior_metrics['oc_current'])
    debug_file.write(f"Line ~402: OC specified: {oc_specified}, Excess: {oc_excess}, Deficiency: {oc_deficiency}\n")
    
    # Rates and interest
    rates = calculate_rates_and_margins(cert_bal, False, manual_inputs['one_mth_libor'], pool_metrics['pool_bal_grp1'], pool_metrics['pool_bal_grp2'], pool_metrics['loan_grp_1_interest'], pool_metrics['loan_grp_2_interest'], manual_inputs['actual_days'])
    debug_file.write(f"PTR: {[round(r, 12) for r in rates['pass_thru_rate']]}\n")
    cert_interest_due = [0] * 21
    for i in range(1, 15):
        cert_interest_due[i] = rates['current_interest'][i-1] + 0  # Add carry-forwards later
    debug_file.write(f"Line ~409: Cert interest due: {cert_interest_due[1:15]}\n")
    
    # Distributions
    cert_interest_paid, cert_interest_due, _, _, ira = distribute_interest(cert_interest_due, pool_metrics['loan_grp_1_interest'], pool_metrics['loan_grp_2_interest'], pool_metrics['ira'])
    debug_file.write(f"Line ~413: After interest distribution - IRA: {ira}, Cert interest paid: {cert_interest_paid[1:15]}\n")
    
    bpda = max(0, pool_metrics['pra'] - oc_excess)
    epda = min(pool_metrics['ira'] - sum(cert_interest_paid[1:15]), oc_deficiency)
    pda = epda + bpda
    debug_file.write(f"Line ~418: BPDA: {bpda}, EPDA: {epda}, PDA: {pda}\n")
    
    cert_principal_paid = distribute_principal(pda, cert_bal, triggers['step_down'], triggers['trigger'], pool_metrics['ending_pool_bal'], senior_metrics['senior_class_a_bal'], pool_metrics['loan_grp_1_principal'], pool_metrics['loan_grp_2_principal'])
    debug_file.write(f"Line ~421: Cert principal paid: {cert_principal_paid[1:15]}\n")
    
    # Excess
    tmes = max(0, ira)
    debug_file.write(f"Line ~425: TMES: {tmes}\n")
    cert_interest_paid, cert_principal_paid, reserve_fund = handle_excess_and_shortfalls(tmes, pda, oc_excess, oc_deficiency, cert_interest_paid, cert_principal_paid, manual_inputs['reserve_fund'], manual_inputs['ppis'], manual_inputs['relief_act_shortfall'], cert_bal)
    debug_file.write(f"Line ~427: Final cert interest paid: {cert_interest_paid[1:21]}\n")
    debug_file.write(f"Line ~428: Final cert principal paid: {cert_principal_paid[1:21]}\n")
    
    debug_file.close()
    
    # Output
    write_results(cert_interest_paid, cert_principal_paid, output_path)


if __name__ == "__main__":
    month = input("Enter month folder (e.g., month_1, month_2, etc.): ").strip()
    base_path = f"Data/{month}"
    output_path = f"Data/{month}/output.csv"
    run_bond_admin_model(base_path, output_path)
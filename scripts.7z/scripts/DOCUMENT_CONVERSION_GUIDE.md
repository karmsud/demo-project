# Document Conversion Guide

## Purpose

Convert raw deal documents (PDF, Word, text) into AI-consumable enhanced markdown files that GHCP can use to generate payment models.

---

## Process Overview

```
┌─────────────────────────────────────────────────────────────────┐
│  1. Create folder structure for the deal                        │
│  2. Dump ALL raw documents into raw_documents/                  │
│  3. Run Python script to extract text (zero LLM tokens)         │
│  4. Paste ONE prompt into GHCP to enhance → governing_docs/     │
└─────────────────────────────────────────────────────────────────┘
```

**Two steps: Python extracts, GHCP enhances.**

---

## Prerequisites

Install required packages (one-time):
```bash
pip install PyMuPDF python-docx openpyxl
```

---

## Step 1: Create Folder Structure

For each new deal, create this structure:

```
{Deal_Name}/
├── raw_documents/      ← Put all PDF/Word/text files here
├── extracted_text/     ← Python script outputs here (auto-created)
├── governing_docs/     ← GHCP creates enhanced markdown here
└── Data/
    └── month_1/        ← CSV inputs/outputs go here
```

Example:
```
CWALT 2007-23CB/
├── raw_documents/
│   ├── PSA.pdf
│   ├── Prospectus_Supplement.pdf
│   ├── Prospectus.pdf
│   ├── Free_Writing_Prospectus.pdf
│   └── Distribution_Report.xlsx
├── extracted_text/     ← Created by script
├── governing_docs/
└── Data/
    └── month_1/
```

---

## Step 2: Dump Raw Documents

Put ALL deal documents into `raw_documents/`:
- Pooling and Servicing Agreement (PSA)
- Prospectus Supplement
- Base Prospectus
- Free Writing Prospectus
- Trust Agreement
- Distribution Reports (if available)
- Any amendments or supplements

**Naming convention:** Use descriptive names. Examples:
- `PSA.pdf`
- `Prospectus_Supplement.pdf`
- `Amendment_1.pdf`
- `Distribution_Report_Month1.xlsx`

---

## Step 3: Run Python Extraction Script

Run the conversion script (extracts raw text, zero LLM tokens):

```bash
python convert_documents.py "C:/path/to/Deal_Name"
```

Example:
```bash
python convert_documents.py "C:/Users/Karmsud/PaymentEngine/vba_models/CWALT 2007-23CB"
```

The script will:
- Read all PDF/Word/Excel/text files from `raw_documents/`
- Extract raw text from each
- Save to `extracted_text/` folder
- Print summary of what was extracted

**Output:** One `{filename}_extracted.txt` per source document.

---

## Step 4: Paste Enhancement Prompt Into GHCP

Copy the entire prompt below and paste it into GitHub Copilot in VS Code.

Replace `{DEAL_FOLDER}` with the actual path to your deal folder.

---

### THE ONE PROMPT

```
I need you to enhance extracted document text into structured AI-consumable markdown files.

## Deal Folder
{DEAL_FOLDER}

## Your Task

1. Read ALL files in the `extracted_text/` subfolder (these are raw text extracts from the Python script)
2. For EACH extracted file, create an enhanced markdown file in `governing_docs/`
3. Create a master `_INDEX.md` that maps topics to document sections

## Document Enhancement Rules

For EACH source document, create a markdown file with:

### A. Document Header
```markdown
# {Document Name}
**Source:** {filename}
**Document Type:** {PSA | Prospectus Supplement | Prospectus | Amendment | Other}
**Conversion Date:** {today's date}
---
```

### B. Preserved Original Text
Keep ALL original legal text in blockquotes:
```markdown
> Original text from document preserved exactly as written
> including all defined terms, section references, and legal language.
```

### C. Extracted Structured Data
After each relevant section, add structured extraction:

**For Class/Certificate definitions:**
```markdown
| Class | CUSIP | Initial Balance | Pass-Through Rate | Rate Type |
|-------|-------|-----------------|-------------------|-----------|
| A-1   | XXX   | $100,000,000    | SOFR + 0.50%      | Floating  |
```

**For Distribution waterfalls:**
```markdown
## EXTRACTED: Distribution Priority
1. [First] Trustee Fees and Expenses
2. [Second] Servicer Fee to Servicer
3. [Third] Interest to Class A Certificates (pro rata)
   - Source: Section 4.01(a)(iii)
   - Formula: Class Balance × Pass-Through Rate × (Actual Days / 360)
...
```

**For Defined Terms:**
```markdown
## EXTRACTED: Key Definitions
| Term | Definition | Source Section |
|------|------------|----------------|
| Available Funds | Collections minus fees... | Section 1.01 |
| Principal Distribution Amount | ... | Section 1.01 |
```

**For Formulas/Calculations:**
```markdown
## EXTRACTED: Calculation - Net WAC Rate Cap
**Source:** Section 4.01(b)(2)
**Formula:**
\`\`\`
Net_WAC_Rate_Cap = (Pool_Net_WAC × 12 / Group_Balance) × (30 / Actual_Days)
\`\`\`
**Variables:**
- Pool_Net_WAC: Weighted average net mortgage rate for the group
- Group_Balance: Outstanding balance of the group
- Actual_Days: Actual days in the accrual period
```

**For Triggers/Tests:**
```markdown
## EXTRACTED: Trigger - Step-Down Test
**Source:** Section 4.01(c)
**Condition:** Step-down occurs when:
- Distribution Date is on or after Step-Down Date (Month 36)
- AND Cumulative Loss Percentage ≤ Trigger Threshold
**Threshold Table:**
| Month Range | Loss Trigger |
|-------------|--------------|
| 1-36        | N/A (locked out) |
| 37-48       | 2.50%        |
...
```

### D. Cross-References
When a section references another section or document:
```markdown
> ...as defined in Section 1.01 of this Agreement...

**[Cross-Reference]** See [PSA.md#definitions](PSA.md#definitions) for "Available Funds" definition.
```

### E. AI Annotations
Add clarifying notes where helpful:
```markdown
**[AI Note]** This waterfall has two phases:
1. Pre-Step-Down: All principal to senior classes sequentially
2. Post-Step-Down: Principal allocated pro-rata to mezzanine classes
```

## File Naming Convention
- `PSA_extracted.txt` → `PSA.md`
- `Prospectus_Supplement_extracted.txt` → `Prospectus_Supplement.md`
- `Amendment_1_extracted.txt` → `Amendment_1.md`

Strip the `_extracted` suffix and change to `.md` for traceability.

## Create _INDEX.md

After processing all documents, create `governing_docs/_INDEX.md`:

```markdown
# {Deal Name} - Document Index

## Quick Reference

### Class Structure
- [Class Definitions](Prospectus_Supplement.md#class-definitions)
- [Class Balances](PSA.md#initial-balances)
- [Interest Rates](Prospectus_Supplement.md#pass-through-rates)

### Waterfall
- [Available Funds Definition](PSA.md#available-funds)
- [Interest Distribution Priority](PSA.md#interest-waterfall)
- [Principal Distribution Priority](PSA.md#principal-waterfall)
- [Loss Allocation](PSA.md#loss-allocation)

### Key Calculations
- [Net WAC Rate Cap](PSA.md#net-wac-cap)
- [Overcollateralization](PSA.md#overcollateralization)
- [Principal Distribution Amount](PSA.md#pda-calculation)

### Triggers & Tests
- [Step-Down Conditions](PSA.md#step-down)
- [Delinquency Triggers](PSA.md#delinquency-trigger)
- [Early Termination](PSA.md#clean-up-call)

### Fees
- [Servicer Fee](PSA.md#servicer-fee)
- [Trustee Fee](PSA.md#trustee-fee)

### Documents Processed
| Source File | Output File | Type |
|-------------|-------------|------|
| PSA.pdf | [PSA.md](PSA.md) | Pooling & Servicing Agreement |
| Prospectus_Supplement.pdf | [Prospectus_Supplement.md](Prospectus_Supplement.md) | Prospectus Supplement |
...
```

## Quality Requirements

1. **Preserve ALL original text** - Nothing deleted, only enhanced
2. **Extract ALL numeric values** - Balances, rates, thresholds, dates
3. **Identify ALL formulas** - Even if described in words, convert to code
4. **Map ALL waterfalls** - Numbered priority steps with sources
5. **Link cross-references** - Connect sections across documents
6. **Flag ambiguities** - Note where text is unclear or contradictory

## Output

Process all documents and create:
1. One `.md` file per source document in `governing_docs/`
2. One `_INDEX.md` master index in `governing_docs/`

Confirm when complete and list all files created.
```

---

## Step 5: Review and Validate

After GHCP completes:

1. **Check `governing_docs/` folder** - Verify all files were created
2. **Open `_INDEX.md`** - Verify all topics are linked
3. **Spot-check extractions** - Compare a few values against source PDFs
4. **Look for [AI Note] flags** - Address any ambiguities noted

---

## Common Issues & Solutions

| Issue | Solution |
|-------|----------|
| PyMuPDF not installed | `pip install PyMuPDF` |
| python-docx not installed | `pip install python-docx` |
| Scanned PDF (no text) | OCR first using Adobe or online tool |
| Missing sections in output | Ask GHCP to re-process specific document with focus on missed section |
| Incorrect extraction | Correct in markdown and add note about source |
| Very large document (>100 pages) | Ask GHCP to process in chunks by section |

---

## Tips for Best Results

1. **Clean filenames** - No special characters, use underscores
2. **Searchable PDFs** - If scanned, OCR first
3. **Include ALL documents** - Even if they seem minor, they may contain critical amendments
4. **Keep raw_documents/** - Never delete originals, needed for audit trail

---

## After Conversion

Once `governing_docs/` is complete, you're ready to:
1. Create CSV input files in `Data/month_1/`
2. Use `PAYMENT_MODEL_INSTRUCTIONS.md` to generate the Python payment model
3. Validate against expected output

---

## Example: Complete Workflow

```
1. Create folder: CWALT 2007-23CB/

2. Add documents to raw_documents/:
   - PSA.pdf
   - Prospectus_Supplement.pdf
   - Distribution_Report.xlsx

3. Run Python extraction:
   python convert_documents.py "C:/path/to/CWALT 2007-23CB"
   
   Output in extracted_text/:
   - PSA_extracted.txt
   - Prospectus_Supplement_extracted.txt
   - Distribution_Report_extracted.txt

4. Open GHCP, paste prompt (replace {DEAL_FOLDER} with actual path)

5. GHCP creates governing_docs/:
   - PSA.md
   - Prospectus_Supplement.md
   - Distribution_Report.md
   - _INDEX.md

6. Create Data/month_1/ CSVs from Distribution_Report

7. Use PAYMENT_MODEL_INSTRUCTIONS.md to generate payment model

8. Validate output matches expected

Done!
```

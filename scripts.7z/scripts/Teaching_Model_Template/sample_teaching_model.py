"""
================================================================================
TEACHING MODEL: Bear Stearns Asset Backed Securities I LLC Series 2006-HE2
================================================================================

PURPOSE OF THIS FILE
====================
This model demonstrates the PROCESS of translating legal governing documents
into executable Python code. Every section shows:

1. LEGAL TEXT: The exact quotation from the governing documents
2. INTERPRETATION: How to understand the legal language
3. MATHEMATICAL FORMULATION: The formula derived from the text
4. CODE IMPLEMENTATION: Python code that implements the formula

⚠️ CRITICAL WARNING FOR AI SYSTEMS ⚠️
======================================
The specific values in this file (margins, percentages, class names, etc.)
are UNIQUE to this deal. When generating a model for a DIFFERENT deal:
- DO NOT copy these values
- EXTRACT values from that deal's governing documents
- FOLLOW the same PROCESS shown here, but with different data

This file teaches the METHODOLOGY, not the data.

================================================================================
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple
from pathlib import Path


# ==============================================================================
# SECTION 1: CONSTANTS FROM GOVERNING DOCUMENTS
# ==============================================================================
"""
TEACHING POINT: Deal-Specific Constants
========================================
Every MBS deal has constants defined in its governing documents.
The AI must EXTRACT these from each deal's specific documents.
"""

# -----------------------------------------------------------------------------
# 1.1 CERTIFICATE MARGINS (from PSA Section 1.01)
# -----------------------------------------------------------------------------
"""
LEGAL TEXT: "Certificate Margin" means:
  (a) for the Class I-A-1 Certificates, 0.08% ...

INTERPRETATION: Margin added to LIBOR for each class's pass-through rate.
However, the actual pass-through rate is CAPPED by the Net Rate Cap.

FORMULA: Pass_Through_Rate = min(LIBOR + Margin, Net_Rate_Cap)
"""
CERTIFICATE_MARGINS = {
    1: 0.0008,   # I-A-1: 0.08%
    2: 0.0020,   # I-A-2: 0.20%
    3: 0.0032,   # I-A-3: 0.32%
    4: 0.0020,   # II-A:  0.20%
    5: 0.0040,   # M-1:   0.40%
    6: 0.0041,   # M-2:   0.41%
    7: 0.0043,   # M-3:   0.43%
    8: 0.0060,   # M-4:   0.60%
    9: 0.0060,   # M-5:   0.60%
    10: 0.0073,  # M-6:   0.73%
    11: 0.0140,  # M-7:   1.40%
    12: 0.0155,  # M-8:   1.55%
    13: 0.0225,  # M-9:   2.25%
    14: 0.0225,  # M-10:  2.25%
}

# Class ordering: 1-14 = A and M classes, 15-19 = P and R classes, 20 = CE
CLASS_NAMES = {
    1: "I-A-1", 2: "I-A-2", 3: "I-A-3", 4: "II-A",
    5: "M-1", 6: "M-2", 7: "M-3", 8: "M-4", 9: "M-5",
    10: "M-6", 11: "M-7", 12: "M-8", 13: "M-9", 14: "M-10",
    15: "P", 16: "R-1", 17: "R-2", 18: "R-3", 19: "RX", 20: "CE"
}

# Loan group assignments
LOAN_GROUP_1_CLASSES = [1, 2, 3]  # I-A-1, I-A-2, I-A-3
LOAN_GROUP_2_CLASSES = [4]        # II-A
MEZZANINE_CLASSES = list(range(5, 15))  # M-1 through M-10

# -----------------------------------------------------------------------------
# 1.2 DEAL CONSTANTS
# -----------------------------------------------------------------------------
ORIGINAL_POOL_BALANCE = 706145220.18
OC_TARGET_PCT_INITIAL = 0.0365   # 3.65% pre-stepdown
OC_TARGET_PCT_STEPDOWN = 0.0730  # 7.30% post-stepdown  
OC_FLOOR = OC_TARGET_PCT_INITIAL * ORIGINAL_POOL_BALANCE
OC_MIN = 3530726
RESERVE_FLOOR = 5000
SSEP = 0.502  # Specified Senior Enhancement Percentage (50.2%)


# ==============================================================================
# SECTION 2: DATA LOADING
# ==============================================================================

def load_data(base_path: str) -> dict:
    """
    Load all input data from CSV files.
    
    TEACHING POINT: Standardized input format allows consistent processing.
    """
    path = Path(base_path)
    
    # Load key-value files
    def load_kv(filepath):
        df = pd.read_csv(filepath)
        return {row['Field']: row['Value'] for _, row in df.iterrows()}
    
    data = {
        'monthly': load_kv(path / "monthly_input.csv"),
        'deal': load_kv(path.parent / "deal_setup.csv"),
    }
    
    # Load class balances
    balances_df = pd.read_csv(path / "class_balances.csv")
    # Map class names to index numbers
    name_to_idx = {v: k for k, v in CLASS_NAMES.items()}
    data['balances'] = {}
    for _, row in balances_df.iterrows():
        cls_name = row['class_name']
        if cls_name in name_to_idx:
            data['balances'][name_to_idx[cls_name]] = float(row['beginning_balance'])
    
    return data


# ==============================================================================
# SECTION 3: NET RATE CAP CALCULATION
# ==============================================================================
"""
LEGAL TEXT (from PSA - Pass-Through Rate):
------------------------------------------
"The Pass-Through Rate for each Class shall not exceed the Net Rate Cap
applicable to such Class."

"Net Rate Cap" means, for any Distribution Date:
- For Loan Group I Classes: the weighted average net mortgage rate of
  the mortgage loans in Loan Group I
- For Loan Group II Classes: the weighted average net mortgage rate of
  the mortgage loans in Loan Group II
- For Subordinate Classes: the weighted average net mortgage rate of
  all mortgage loans

INTERPRETATION:
---------------
The Net Rate Cap limits the interest rate to what the underlying loans
can support. This prevents paying more interest than collected.

MATHEMATICAL FORMULATION:
-------------------------
Net_Rate_Cap_Group1 = (Group1_Interest × 12 / Group1_Balance) × (30 / Actual_Days)
Net_Rate_Cap_Group2 = (Group2_Interest × 12 / Group2_Balance) × (30 / Actual_Days)
Net_Rate_Cap_Combined = ((Group1_Int + Group2_Int) × 12 / Total_Balance) × (30 / Actual_Days)

Pass_Through_Rate[class] = min(LIBOR + Margin[class], Net_Rate_Cap[class])
"""

def calculate_net_rate_caps(
    grp1_interest: float,
    grp2_interest: float,
    grp1_balance: float,
    grp2_balance: float,
    actual_days: int
) -> Dict[int, float]:
    """
    Calculate Net Rate Cap for each class based on loan group yields.
    
    TEACHING POINT: This prevents certificate holders from receiving
    more interest than the underlying loans generate.
    """
    # Annualize and adjust for day count
    day_factor = 30 / actual_days
    
    # Group 1 cap (for classes 1, 2, 3)
    grp1_cap = (grp1_interest * 12 / grp1_balance) * day_factor if grp1_balance > 0 else 0
    
    # Group 2 cap (for class 4)
    grp2_cap = (grp2_interest * 12 / grp2_balance) * day_factor if grp2_balance > 0 else 0
    
    # Combined cap (for classes 5-14)
    total_balance = grp1_balance + grp2_balance
    combined_cap = ((grp1_interest + grp2_interest) * 12 / total_balance) * day_factor if total_balance > 0 else 0
    
    caps = {}
    for i in LOAN_GROUP_1_CLASSES:
        caps[i] = grp1_cap
    for i in LOAN_GROUP_2_CLASSES:
        caps[i] = grp2_cap
    for i in MEZZANINE_CLASSES:
        caps[i] = combined_cap
    
    return caps


def calculate_pass_through_rates(libor: float, net_rate_caps: Dict[int, float]) -> Dict[int, float]:
    """
    Calculate actual pass-through rate as min(LIBOR + Margin, Net Rate Cap).
    """
    rates = {}
    for cls in range(1, 15):
        libor_plus_margin = libor + CERTIFICATE_MARGINS[cls]
        cap = net_rate_caps.get(cls, libor_plus_margin)
        rates[cls] = min(libor_plus_margin, cap)
    return rates


# ==============================================================================
# SECTION 4: INTEREST CALCULATION AND DISTRIBUTION
# ==============================================================================
"""
LEGAL TEXT (from PSA Section 5.04(a)):
--------------------------------------
"FIRST, from the Interest Remittance Amount:
(1) to the Servicer, servicing compensation...
(2) to the Trustee, the trustee fee...
(3) to each Class of Class A Certificates, the Interest Distribution Amount...
    first from the Interest Remittance Amount allocable to the related
    Loan Group, then from amounts allocable to the other Loan Group"

INTERPRETATION:
---------------
1. Senior classes have loan group priority (Group 1 classes paid from Group 1 
   interest first, Group 2 classes from Group 2 interest first)
2. Cross-group funding if own group is insufficient
3. Mezzanine classes paid sequentially from remaining IRA
4. CE class receives remaining excess as interest

MATHEMATICAL FORMULATION:
-------------------------
For each senior class:
  1. Pay from own loan group interest
  2. If shortfall, pay from other loan group interest
For mezzanine classes:
  Pay sequentially from combined remaining IRA
"""

def calculate_interest_due(
    balances: Dict[int, float],
    pass_through_rates: Dict[int, float],
    actual_days: int
) -> Dict[int, float]:
    """
    Calculate interest due for each class.
    
    FORMULA: Interest_Due = Balance × Pass_Through_Rate × (Actual_Days / 360)
    """
    interest_due = {}
    for cls in range(1, 15):
        balance = balances.get(cls, 0)
        rate = pass_through_rates.get(cls, 0)
        interest_due[cls] = balance * rate * actual_days / 360
    return interest_due


def distribute_interest(
    interest_due: Dict[int, float],
    grp1_interest_available: float,
    grp2_interest_available: float,
    ira: float
) -> Tuple[Dict[int, float], float]:
    """
    Distribute interest according to PSA waterfall with cross-group logic.
    
    TEACHING POINT: This implements the complex cross-group allocation
    where each loan group's interest first goes to its own senior classes,
    then crosses to cover shortfalls in the other group.
    
    Returns: (interest_paid dict, remaining IRA)
    """
    interest_paid = {i: 0.0 for i in range(1, 21)}
    
    # Track available from each group
    grp1_avail = grp1_interest_available
    grp2_avail = grp2_interest_available
    
    # -------------------------------------------------------------------------
    # Step 1: Pay Group 1 classes (1, 2, 3) from Group 1 interest
    # -------------------------------------------------------------------------
    for cls in LOAN_GROUP_1_CLASSES:
        due = interest_due.get(cls, 0)
        payment = min(due, grp1_avail)
        interest_paid[cls] = payment
        grp1_avail -= payment
        ira -= payment
    
    # -------------------------------------------------------------------------
    # Step 2: Pay Group 2 class (4) from Group 2 interest
    # -------------------------------------------------------------------------
    for cls in LOAN_GROUP_2_CLASSES:
        due = interest_due.get(cls, 0)
        payment = min(due, grp2_avail)
        interest_paid[cls] = payment
        grp2_avail -= payment
        ira -= payment
    
    # -------------------------------------------------------------------------
    # Step 3: Cross-fund Group 2 shortfall from Group 1 surplus
    # -------------------------------------------------------------------------
    for cls in LOAN_GROUP_2_CLASSES:
        due = interest_due.get(cls, 0)
        shortfall = due - interest_paid[cls]
        if shortfall > 0 and grp1_avail > 0:
            cross_payment = min(shortfall, grp1_avail)
            interest_paid[cls] += cross_payment
            grp1_avail -= cross_payment
            ira -= cross_payment
    
    # -------------------------------------------------------------------------
    # Step 4: Cross-fund Group 1 shortfall from Group 2 surplus
    # -------------------------------------------------------------------------
    for cls in LOAN_GROUP_1_CLASSES:
        due = interest_due.get(cls, 0)
        shortfall = due - interest_paid[cls]
        if shortfall > 0 and grp2_avail > 0:
            cross_payment = min(shortfall, grp2_avail)
            interest_paid[cls] += cross_payment
            grp2_avail -= cross_payment
            ira -= cross_payment
    
    # -------------------------------------------------------------------------
    # Step 5: Pay Mezzanine classes sequentially from remaining IRA
    # -------------------------------------------------------------------------
    for cls in MEZZANINE_CLASSES:
        due = interest_due.get(cls, 0)
        payment = min(due, ira)
        interest_paid[cls] = payment
        ira -= payment
    
    return interest_paid, ira


# ==============================================================================
# SECTION 5: TRIGGER AND STEPDOWN EVALUATION
# ==============================================================================
"""
LEGAL TEXT (from PSA Section 1.01):
-----------------------------------
"Stepdown Date" means the earlier of:
(i) the Distribution Date in March 2009, and
(ii) the first Distribution Date on which the Senior Enhancement 
     Percentage equals or exceeds 50.20%

"Trigger Event" means a Delinquency Event or a Loss Trigger

INTERPRETATION:
---------------
- Stepdown allows principal to flow to subordinate classes
- Triggers prevent stepdown and lock principal to seniors
- Senior Enhancement = (Pool - Senior Balance) / Pool
"""

def calculate_senior_metrics(balances: Dict[int, float], pool_balance: float) -> dict:
    """
    Calculate senior class metrics needed for triggers and OC.
    """
    senior_balance = sum(balances.get(i, 0) for i in range(1, 5))
    subordinate_balance = sum(balances.get(i, 0) for i in range(5, 15))
    
    sep = (pool_balance - senior_balance) / pool_balance if pool_balance > 0 else 0
    oc_current = pool_balance - senior_balance - subordinate_balance
    
    return {
        'senior_balance': senior_balance,
        'subordinate_balance': subordinate_balance,
        'sep': sep,
        'oc_current': oc_current
    }


def evaluate_triggers(
    data: dict,
    dist_count: int,
    sep: float,
    balances: Dict[int, float]
) -> dict:
    """
    Evaluate stepdown and trigger conditions.
    """
    monthly = data['monthly']
    pool_bal = float(monthly['pool_beg_balance'])
    
    # Delinquency ratio calculation
    dq_90 = float(monthly.get('dq_90_119_days', 0))
    dq_120 = float(monthly.get('dq_120_plus_days', 0))
    reo = float(monthly.get('reo_balance', 0))
    bk = float(monthly.get('bankruptcy_balance', 0))
    fc = float(monthly.get('foreclosure_balance', 0))
    dq_bk_90 = float(monthly.get('dq_and_bk_90_119_days', 0))
    dq_bk_120 = float(monthly.get('dq_and_bk_120_plus_days', 0))
    
    dq_numerator = dq_90 + dq_120 + reo + bk + fc - dq_bk_90 - dq_bk_120
    dq_pct = dq_numerator / pool_bal if pool_bal > 0 else 0
    
    # Loss trigger (based on month thresholds)
    loss_trigger = (
        (dist_count > 72 and dq_pct > 0.0775) or
        (dist_count > 60 and dist_count <= 72 and dq_pct > 0.0725) or
        (dist_count > 48 and dist_count <= 60 and dq_pct > 0.058) or
        (dist_count > 36 and dist_count <= 48 and dq_pct > 0.037)
    )
    
    # Delinquency trigger
    dq_trigger = dq_pct > (0.3175 * sep)
    
    trigger = loss_trigger or dq_trigger
    
    # Stepdown evaluation
    prior_stepdown = int(float(monthly.get('prior_month_stepdown', 0))) == 1
    senior_paid_off = sum(balances.get(i, 0) for i in range(1, 5)) == 0
    
    step_down = (
        senior_paid_off or 
        prior_stepdown or
        (dist_count > 36 and sep > SSEP)
    )
    
    return {
        'step_down': step_down,
        'trigger': trigger,
        'loss_trigger': loss_trigger,
        'dq_trigger': dq_trigger
    }


# ==============================================================================
# SECTION 6: PRINCIPAL DISTRIBUTION
# ==============================================================================
"""
LEGAL TEXT (from PSA Section 5.04(a)(2)):
-----------------------------------------
"SECOND, from amounts remaining after clause FIRST:

(A) prior to the Stepdown Date or during a Trigger Event:
    (i) to Loan Group I Certificates, the Loan Group I Principal Amount
    (ii) to Loan Group II Certificates, the Loan Group II Principal Amount
    
(B) on or after Stepdown Date (no Trigger Event):
    pro rata to all Class A Certificates, then sequentially to M classes"

INTERPRETATION:
---------------
- Pre-stepdown: Each loan group's principal goes to its own seniors
- Cross-funding if one group's seniors are paid off
- Post-stepdown: Pro-rata allocation
"""

def distribute_principal(
    pda: float,
    balances: Dict[int, float],
    step_down: bool,
    trigger: bool,
    grp1_principal: float,
    grp2_principal: float
) -> Tuple[Dict[int, float], Dict[int, float]]:
    """
    Distribute principal according to stepdown status.
    
    Returns: (principal_paid dict, updated_balances dict)
    """
    principal_paid = {i: 0.0 for i in range(1, 21)}
    new_balances = balances.copy()
    
    if not step_down or trigger:
        # Pre-stepdown: Group-specific allocation
        
        # Calculate allocation percentages
        total_principal = grp1_principal + grp2_principal
        if total_principal > 0:
            grp1_pct = grp1_principal / total_principal
            grp2_pct = grp2_principal / total_principal
        else:
            grp1_pct = grp2_pct = 0
        
        grp1_dist = grp1_pct * pda
        grp2_dist = grp2_pct * pda
        
        # Pay Group 1 seniors (sequential within group)
        for cls in LOAN_GROUP_1_CLASSES:
            payment = min(new_balances.get(cls, 0), grp1_dist)
            principal_paid[cls] = payment
            new_balances[cls] = new_balances.get(cls, 0) - payment
            grp1_dist -= payment
        
        # Pay Group 2 seniors
        for cls in LOAN_GROUP_2_CLASSES:
            payment = min(new_balances.get(cls, 0), grp2_dist)
            principal_paid[cls] = payment
            new_balances[cls] = new_balances.get(cls, 0) - payment
            grp2_dist -= payment
        
        # Cross-fund: Group 1 surplus to Group 2
        for cls in LOAN_GROUP_2_CLASSES:
            if grp1_dist > 0:
                payment = min(new_balances.get(cls, 0), grp1_dist)
                principal_paid[cls] += payment
                new_balances[cls] -= payment
                grp1_dist -= payment
        
        # Cross-fund: Group 2 surplus to Group 1 (pro-rata)
        if grp2_dist > 0:
            total_grp1_remaining = sum(new_balances.get(i, 0) for i in LOAN_GROUP_1_CLASSES)
            if total_grp1_remaining > 0:
                for cls in LOAN_GROUP_1_CLASSES:
                    cls_share = new_balances.get(cls, 0) / total_grp1_remaining
                    payment = min(new_balances.get(cls, 0), grp2_dist * cls_share)
                    principal_paid[cls] += payment
                    new_balances[cls] -= payment
                    grp2_dist -= payment
        
        # Remaining PDA to mezzanine (sequential)
        remaining_pda = pda - sum(principal_paid[i] for i in range(1, 5))
        for cls in MEZZANINE_CLASSES:
            payment = min(new_balances.get(cls, 0), remaining_pda)
            principal_paid[cls] = payment
            new_balances[cls] = new_balances.get(cls, 0) - payment
            remaining_pda -= payment
    
    else:
        # Post-stepdown: Pro-rata to seniors, then sequential to mezz
        # (Simplified - full implementation would have lockout logic)
        total_senior = sum(new_balances.get(i, 0) for i in range(1, 5))
        if total_senior > 0:
            senior_share = min(pda, total_senior)
            for cls in range(1, 5):
                cls_balance = new_balances.get(cls, 0)
                payment = senior_share * (cls_balance / total_senior) if total_senior > 0 else 0
                principal_paid[cls] = payment
                new_balances[cls] -= payment
            pda -= senior_share
        
        for cls in MEZZANINE_CLASSES:
            payment = min(new_balances.get(cls, 0), pda)
            principal_paid[cls] = payment
            new_balances[cls] -= payment
            pda -= payment
    
    return principal_paid, new_balances


# ==============================================================================
# SECTION 7: OC AND EXCESS CASHFLOW
# ==============================================================================
"""
LEGAL TEXT (from PSA Section 5.04(a)):
--------------------------------------
"Overcollateralization Target Amount" calculation determines how much
excess cashflow is used for credit enhancement vs. distributed.

For CE Class: All remaining interest after paying classes 1-14 and
all principal amounts flow to the CE class.

INTERPRETATION:
---------------
- OC excess can release principal to subordinates
- OC deficiency requires additional principal from excess interest
- CE receives: remaining_interest + (pda adjustments)
"""

def calculate_oc_target(
    step_down: bool,
    trigger: bool,
    pool_bal: float,
    ending_pool_bal: float
) -> float:
    """
    Calculate OC target based on stepdown/trigger status.
    """
    if not step_down:
        return OC_TARGET_PCT_INITIAL * pool_bal
    elif step_down and not trigger:
        return max(min(OC_TARGET_PCT_STEPDOWN * ending_pool_bal, OC_FLOOR), OC_MIN)
    else:
        return OC_FLOOR  # During trigger, maintain minimum


def calculate_ce_distributions(
    remaining_ira: float,
    pda: float,
    oc_current: float,
    oc_target: float,
    reserve_fund: float,
    ppis: float,
    relief_act_shortfall: float
) -> Tuple[float, float]:
    """
    Calculate CE class interest and principal.
    
    TEACHING POINT: CE receives all excess cashflow. Its "interest" is
    the remaining IRA after paying all other classes. Its "principal"
    is the PDA adjusted for OC requirements.
    """
    # OC calculations
    oc_excess = max(0, oc_current - oc_target)
    oc_deficiency = max(0, oc_target - oc_current)
    
    # Reserve fund handling
    reserve_deficiency = max(0, RESERVE_FLOOR - reserve_fund)
    reserve_deposit = min(reserve_deficiency, remaining_ira)
    remaining_ira -= reserve_deposit
    
    # Shortfall adjustments
    remaining_ira = max(0, remaining_ira - relief_act_shortfall)
    remaining_ira = max(0, remaining_ira - ppis)
    
    # CE distributions
    ce_interest = remaining_ira
    ce_principal = pda + (oc_excess - oc_deficiency)
    
    return ce_interest, ce_principal


# ==============================================================================
# SECTION 8: MAIN CALCULATION FUNCTION
# ==============================================================================

def run_monthly_distribution(data_path: str) -> pd.DataFrame:
    """
    Execute full monthly distribution calculation.
    
    This is the main entry point that orchestrates all calculations.
    """
    # -------------------------------------------------------------------------
    # Step 1: Load Data
    # -------------------------------------------------------------------------
    data = load_data(data_path)
    monthly = data['monthly']
    balances = data['balances']
    
    # Extract key values
    pool_bal = float(monthly['pool_beg_balance'])
    ending_pool_bal = float(monthly['pool_end_balance'])
    grp1_balance = float(monthly['grp1_beg_balance'])
    grp2_balance = float(monthly['grp2_beg_balance'])
    grp1_interest = float(monthly['grp1_interest_collected'])
    grp2_interest = float(monthly['grp2_interest_collected'])
    grp1_principal = float(monthly['grp1_principal_collected'])
    grp2_principal = float(monthly['grp2_principal_collected'])
    libor = float(monthly['one_month_libor'])
    actual_days = int(float(monthly['actual_days']))
    dist_count = int(float(monthly['distribution_month']))
    reserve_fund = float(monthly.get('reserve_fund_balance', 0))
    ppis = float(monthly.get('ppis', 0))
    relief_act = float(monthly.get('relief_act_shortfall', 0))
    
    ira = grp1_interest + grp2_interest
    pra = grp1_principal + grp2_principal
    
    # -------------------------------------------------------------------------
    # Step 2: Calculate Metrics
    # -------------------------------------------------------------------------
    metrics = calculate_senior_metrics(balances, pool_bal)
    
    # -------------------------------------------------------------------------
    # Step 3: Evaluate Triggers
    # -------------------------------------------------------------------------
    triggers = evaluate_triggers(data, dist_count, metrics['sep'], balances)
    
    # -------------------------------------------------------------------------
    # Step 4: Calculate OC Target
    # -------------------------------------------------------------------------
    oc_target = calculate_oc_target(
        triggers['step_down'], triggers['trigger'],
        pool_bal, ending_pool_bal
    )
    oc_excess = max(0, metrics['oc_current'] - oc_target)
    oc_deficiency = max(0, oc_target - metrics['oc_current'])
    
    # -------------------------------------------------------------------------
    # Step 5: Calculate Interest Rates (with Net Rate Cap)
    # -------------------------------------------------------------------------
    net_rate_caps = calculate_net_rate_caps(
        grp1_interest, grp2_interest,
        grp1_balance, grp2_balance,
        actual_days
    )
    pass_through_rates = calculate_pass_through_rates(libor, net_rate_caps)
    
    # -------------------------------------------------------------------------
    # Step 6: Calculate Interest Due
    # -------------------------------------------------------------------------
    interest_due = calculate_interest_due(balances, pass_through_rates, actual_days)
    
    # -------------------------------------------------------------------------
    # Step 7: Distribute Interest
    # -------------------------------------------------------------------------
    interest_paid, remaining_ira = distribute_interest(
        interest_due, grp1_interest, grp2_interest, ira
    )
    
    # -------------------------------------------------------------------------
    # Step 8: Calculate Principal Distribution Amount
    # -------------------------------------------------------------------------
    """
    LEGAL TEXT interpretation:
    BPDA = Basic Principal Distribution Amount = max(0, PRA - OC_excess)
    EPDA = Excess Principal Distribution Amount = portion of excess interest
           used to cover OC deficiency
    PDA = BPDA + EPDA
    """
    bpda = max(0, pra - oc_excess)
    epda = min(remaining_ira, oc_deficiency)
    pda = bpda + epda
    
    # -------------------------------------------------------------------------
    # Step 9: Distribute Principal
    # -------------------------------------------------------------------------
    principal_paid, new_balances = distribute_principal(
        pda, balances,
        triggers['step_down'], triggers['trigger'],
        grp1_principal, grp2_principal
    )
    
    # -------------------------------------------------------------------------
    # Step 10: Handle CE Class (Excess Cashflow)
    # -------------------------------------------------------------------------
    ce_interest, ce_principal = calculate_ce_distributions(
        remaining_ira, pda, metrics['oc_current'], oc_target,
        reserve_fund, ppis, relief_act
    )
    
    interest_paid[20] = ce_interest
    principal_paid[20] = ce_principal
    
    # -------------------------------------------------------------------------
    # Step 11: Prepare Output
    # -------------------------------------------------------------------------
    results = []
    for cls in range(1, 21):
        results.append({
            'Class': cls,
            'Interest_Paid': interest_paid.get(cls, 0.0),
            'Principal_Paid': principal_paid.get(cls, 0.0)
        })
    
    output_df = pd.DataFrame(results)
    return output_df


# ==============================================================================
# SECTION 9: ENTRY POINT
# ==============================================================================

if __name__ == "__main__":
    import sys
    
    data_path = "Data/month_1"
    if len(sys.argv) > 1:
        data_path = sys.argv[1]
    
    print("=" * 70)
    print("TEACHING MODEL: Bear Stearns 2006-HE2")
    print("=" * 70)
    print(f"\nProcessing: {data_path}")
    
    try:
        output_df = run_monthly_distribution(data_path)
        
        print("\n--- Distribution Results ---")
        print(output_df.to_string(index=False))
        
        # Save output
        output_df.to_csv(f"{data_path}/output_teaching.csv", index=False)
        print(f"\nResults saved to {data_path}/output_teaching.csv")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

# Distribution Waterfall - Bear Stearns Asset Backed Securities I LLC, Series 2006-HE2

## Document Information
- **Source**: Pooling and Servicing Agreement, Section 5.04 - Distributions
- **Purpose**: Defines the priority order for distributing interest, principal, and excess cashflow
- **AI Instruction**: This document defines the exact sequence and conditions for payment distributions. Each priority must be implemented in order. Funds flow from one priority to the next only after the current priority is satisfied.

---

## Overview

On each Distribution Date, funds are distributed in the following order:
1. **Interest Funds** - Distributed per Section 5.04(a)(1)
2. **Principal Funds** - Distributed per Section 5.04(a)(2)
3. **Excess Cashflow** - Distributed per Section 5.04(a)(4)

---

## SECTION 1: INTEREST FUNDS DISTRIBUTION

**Legal Text**: "INTEREST FUNDS SHALL BE DISTRIBUTED IN THE FOLLOWING MANNER AND ORDER OF PRIORITY"

### Priority 1(A): Group I Interest to Group I Senior Certificates

**Legal Text**: "FROM INTEREST FUNDS IN RESPECT OF LOAN GROUP I, TO THE CLASS I-A-1, CLASS I-A-2 AND CLASS I-A-3 CERTIFICATES, THE CURRENT INTEREST AND ANY INTEREST CARRY FORWARD AMOUNT FOR EACH SUCH CLASS, ON A PRO RATA BASIS, BASED ON THE ENTITLEMENT OF EACH SUCH CLASS"

**Interpretation**:
- **Source of Funds**: Interest Funds collected from Loan Group I only
- **Recipients**: Class I-A-1, Class I-A-2, Class I-A-3 (the Group I Senior classes)
- **What They Receive**: Current Interest + any unpaid Interest Carry Forward
- **Allocation Method**: Pro rata based on each class's entitlement (interest due)

**Mathematical Formulation**:
```
Let:
  IF_G1 = Interest Funds from Group I
  E_i = Current Interest + Interest Carry Forward for class i
  E_total = E[I-A-1] + E[I-A-2] + E[I-A-3]

For each class i in [I-A-1, I-A-2, I-A-3]:
  If E_total > 0:
    Payment_i = min(E_i, IF_G1 × (E_i / E_total))
  Else:
    Payment_i = 0
    
Remaining_IF_G1 = IF_G1 - sum(Payments)
```

### Priority 1(B): Group II Interest to Group II Senior Certificates

**Legal Text**: "FROM INTEREST FUNDS IN RESPECT OF LOAN GROUP II, TO THE CLASS II-A CERTIFICATES, THE CURRENT INTEREST AND ANY INTEREST CARRY FORWARD AMOUNT FOR SUCH CLASS"

**Interpretation**:
- **Source of Funds**: Interest Funds collected from Loan Group II only
- **Recipients**: Class II-A (the sole Group II Senior class)
- **What They Receive**: Current Interest + any unpaid Interest Carry Forward
- **Allocation Method**: Single class, no allocation needed

**Mathematical Formulation**:
```
Let:
  IF_G2 = Interest Funds from Group II
  E_IIA = Current Interest + Interest Carry Forward for Class II-A

Payment_IIA = min(E_IIA, IF_G2)
Remaining_IF_G2 = IF_G2 - Payment_IIA
```

### Priority 2: Cross-Collateralization of Senior Interest

**Legal Text**: "FROM REMAINING INTEREST FUNDS IN RESPECT OF THE NON-RELATED LOAN GROUP, TO THE NON-RELATED CLASS I-A CERTIFICATES AND CLASS II-A CERTIFICATES, THE REMAINING CURRENT INTEREST, IF ANY, AND THE REMAINING INTEREST CARRY FORWARD AMOUNT, IF ANY, FOR SUCH CLASSES, PRO RATA BASED ON THE ENTITLEMENT OF EACH SUCH CLASS"

**Interpretation**:
- **Source of Funds**: REMAINING Interest Funds from each group (after Priority 1)
- **Recipients**: Senior classes from the OTHER group that didn't receive full payment
- **Allocation Method**: Pro rata based on remaining entitlement

**Mathematical Formulation**:
```
# Remaining needs after Priority 1
Remaining_Need[I-A-1] = E[I-A-1] - Payment[I-A-1]  (from Priority 1)
Remaining_Need[I-A-2] = E[I-A-2] - Payment[I-A-2]
Remaining_Need[I-A-3] = E[I-A-3] - Payment[I-A-3]
Remaining_Need[II-A] = E[II-A] - Payment[II-A]

# Group II funds can help Group I seniors (cross-collat)
If Remaining_IF_G2 > 0 and sum(Remaining_Need[I-A-*]) > 0:
  Allocate Remaining_IF_G2 to I-A-1, I-A-2, I-A-3 pro rata by remaining need

# Group I funds can help Group II seniors (cross-collat)  
If Remaining_IF_G1 > 0 and Remaining_Need[II-A] > 0:
  Allocate Remaining_IF_G1 to II-A up to remaining need
```

### Priority 3: Subordinate Interest (Mezzanine Classes)

**Legal Text**: "FROM REMAINING INTEREST FUNDS IN RESPECT OF BOTH LOAN GROUPS, SEQUENTIALLY TO THE CLASS M-1, CLASS M-2, CLASS M-3, CLASS M-4, CLASS M-5, CLASS M-6, CLASS M-7, CLASS M-8, CLASS M-9 AND CLASS M-10 CERTIFICATES, IN THAT ORDER, THE CURRENT INTEREST FOR SUCH CLASS."

**Interpretation**:
- **Source of Funds**: REMAINING Interest Funds from BOTH groups combined
- **Recipients**: M-1 through M-10 in sequential order
- **What They Receive**: Current Interest only (NOT carry forward at this priority)
- **Allocation Method**: SEQUENTIAL - pay M-1 first, then M-2, etc.

**Mathematical Formulation**:
```
Combined_Remaining_IF = Remaining_IF_G1 + Remaining_IF_G2

For each class M-i in [M-1, M-2, ..., M-10] in order:
  Payment[M-i] = min(Current_Interest[M-i], Combined_Remaining_IF)
  Combined_Remaining_IF = Combined_Remaining_IF - Payment[M-i]
```

**Note**: Interest Carry Forward for M classes is paid from Excess Cashflow (Priority 4), not here.

---

## SECTION 2: PRINCIPAL DISTRIBUTION

**Legal Text**: "ON EACH DISTRIBUTION DATE, THE PRINCIPAL DISTRIBUTION AMOUNT SHALL BE DISTRIBUTED IN THE FOLLOWING MANNER AND ORDER OF PRIORITY"

### Condition Check: Pre-Stepdown vs Post-Stepdown

**Legal Text**: Two separate waterfall paths:
- Section 2(A): "FOR EACH DISTRIBUTION DATE (I) PRIOR TO THE STEPDOWN DATE OR (II) ON WHICH A TRIGGER EVENT IS IN EFFECT"
- Section 2(B): "FOR EACH DISTRIBUTION DATE ON OR AFTER THE STEPDOWN DATE, SO LONG AS A TRIGGER EVENT IS NOT IN EFFECT"

**Decision Logic**:
```python
if not stepdown_eligible or trigger_event_active:
    # Use Pre-Stepdown waterfall (Section 2A)
    # All principal pays down certificates to zero sequentially
else:
    # Use Post-Stepdown waterfall (Section 2B)
    # Principal is capped by lockout percentages
```

---

### SECTION 2(A): PRINCIPAL DISTRIBUTION - PRE-STEPDOWN OR TRIGGER ACTIVE

**Condition**: Prior to Stepdown Date OR Trigger Event in effect

#### Priority 2A-1: Group Principal to Senior Certificates

**Legal Text**: "TO THE CLASS A CERTIFICATES, THE PRINCIPAL DISTRIBUTION AMOUNT FOR SUCH DISTRIBUTION DATE TO BE DISTRIBUTED AS FOLLOWS:
(A) FROM THE GROUP I PRINCIPAL DISTRIBUTION AMOUNT FOR SUCH DISTRIBUTION DATE, SEQUENTIALLY, TO THE CLASS I-A-1, CLASS I-A-2 AND CLASS I-A-3 CERTIFICATES, IN THAT ORDER, IN EACH CASE UNTIL THE CERTIFICATE PRINCIPAL BALANCE THEREOF IS REDUCED TO ZERO; AND
(B) FROM THE GROUP II PRINCIPAL DISTRIBUTION AMOUNT FOR SUCH DISTRIBUTION DATE, TO THE CLASS II-A CERTIFICATES, UNTIL THE CERTIFICATE PRINCIPAL BALANCE THEREOF IS REDUCED TO ZERO"

**Interpretation**:
- Group I Principal → I-A-1 first (until zero), then I-A-2 (until zero), then I-A-3 (until zero)
- Group II Principal → II-A (until zero)

**Mathematical Formulation**:
```
# Calculate Group Principal Distribution Amounts
Group_I_PDA = PDA × (Principal_Funds_G1 / Total_Principal_Funds)
Group_II_PDA = PDA × (Principal_Funds_G2 / Total_Principal_Funds)

# Group I - Sequential
Remaining_G1 = Group_I_PDA
For each class in [I-A-1, I-A-2, I-A-3] in order:
  Payment = min(Balance[class], Remaining_G1)
  Remaining_G1 -= Payment

# Group II
Payment[II-A] = min(Balance[II-A], Group_II_PDA)
Remaining_G2 = Group_II_PDA - Payment[II-A]
```

#### Priority 2A-2 through 2A-11: Subordinate Principal (Sequential)

**Legal Text**: "TO THE CLASS M-1 CERTIFICATES, FROM ANY REMAINING PRINCIPAL FUNDS IN RESPECT OF BOTH LOAN GROUPS FOR SUCH DISTRIBUTION DATE, UNTIL THE CERTIFICATE PRINCIPAL BALANCE THEREOF IS REDUCED TO ZERO"

(Pattern repeats for M-2 through M-10)

**Interpretation**:
- After Seniors are paid, combine remaining Group I and Group II principal
- Pay M-1 until balance = 0, then M-2, etc.

**Mathematical Formulation**:
```
Combined_Remaining = Remaining_G1 + Remaining_G2

For each class M-i in [M-1, M-2, ..., M-10] in order:
  Payment[M-i] = min(Balance[M-i], Combined_Remaining)
  Combined_Remaining -= Payment[M-i]
```

---

### SECTION 2(B): PRINCIPAL DISTRIBUTION - POST-STEPDOWN (NO TRIGGER)

**Condition**: On or after Stepdown Date AND Trigger Event NOT in effect

#### Priority 2B-1: Group Principal to Senior Certificates (With Lockout)

**Legal Text**: "FROM THE GROUP I PRINCIPAL DISTRIBUTION AMOUNT FOR SUCH DISTRIBUTION DATE, SEQUENTIALLY, TO THE CLASS I-A-1, CLASS I-A-2 AND CLASS I-A-3 CERTIFICATES, IN THAT ORDER, THE **CLASS I-A PRINCIPAL DISTRIBUTION AMOUNT** FOR SUCH DISTRIBUTION DATE"

**Key Difference**: Uses "Class I-A Principal Distribution Amount" instead of full Group I PDA.

**Class I-A Principal Distribution Amount Definition** (from definitions):
"the product of the Class A Principal Distribution Amount and a fraction, the numerator of which is the Principal Funds for Loan Group I for such Distribution Date and the denominator of which is the Principal Funds for both Loan Groups"

**Class A Principal Distribution Amount Definition**:
"the lesser of (x) the Principal Distribution Amount and (y) the excess, if any, of (i) the aggregate Certificate Principal Balance of the Class A Certificates immediately prior to such Distribution Date, over (ii) the lesser of (a) the product of (1) **49.80%** and (2) the aggregate Stated Principal Balance... and (b) the aggregate Stated Principal Balance... minus $3,530,726"

**Mathematical Formulation for Class A**:
```
# Calculate the lockout floor
Lockout_Floor_A = min(
    0.4980 × Ending_Pool_Balance,
    Ending_Pool_Balance - 3530726
)

# Class A can only pay down to the lockout floor
Class_A_PDA = min(
    PDA,
    max(0, Sum_Class_A_Balances - Lockout_Floor_A)
)

# Split between Group I and Group II
Class_IA_PDA = Class_A_PDA × (Principal_Funds_G1 / Total_Principal_Funds)
Class_IIA_PDA = Class_A_PDA × (Principal_Funds_G2 / Total_Principal_Funds)
```

#### Priority 2B-2 through 2B-11: Subordinate Principal (With Lockout)

Each M class has its own lockout percentage. The pattern is:

**Mathematical Formulation (general)**:
```
For class M-i with lockout_pct[i]:
  
  # Calculate cumulative balance of this class and all senior classes
  Cumulative_Balance = Sum(Balance[class] for class in [A classes + M-1 to M-i])
  
  # Calculate lockout floor for this class
  Lockout_Floor = min(
      lockout_pct[i] × Ending_Pool_Balance,
      Ending_Pool_Balance - 3530726
  )
  
  # This class can only pay down to its lockout floor
  Class_Mi_PDA = min(
      Remaining_PDA,
      max(0, Cumulative_Balance - Lockout_Floor)
  )
```

**Lockout Percentages** (from definitions):
| Class | Lockout % |
|-------|-----------|
| A (combined) | 49.80% |
| M-1 | 59.10% |
| M-2 | 66.50% |
| M-3 | 71.00% |
| M-4 | 74.90% |
| M-5 | 78.60% |
| M-6 | 82.00% |
| M-7 | 85.10% |
| M-8 | 87.90% |
| M-9 | 90.20% |
| M-10 | 92.70% |

---

## SECTION 3: CROSS-GROUP PRINCIPAL REALLOCATION

**Legal Text**: "NOTWITHSTANDING THE PROVISIONS OF CLAUSES (2)(A) AND (B) ABOVE, IF ON ANY DISTRIBUTION DATE THE CLASS A CERTIFICATES RELATED TO A LOAN GROUP ARE NO LONGER OUTSTANDING, THE PRO RATA PORTION OF THE PRINCIPAL DISTRIBUTION AMOUNT OR THE APPLICABLE CLASS A PRINCIPAL DISTRIBUTION AMOUNT, AS APPLICABLE, OTHERWISE ALLOCABLE TO SUCH CLASS A CERTIFICATES WILL BE ALLOCATED TO THE REMAINING GROUP OF CLASS A CERTIFICATES"

**Interpretation**: If all Group I seniors are paid off, their principal allocation goes to Group II seniors, and vice versa.

---

## SECTION 4: EXCESS CASHFLOW DISTRIBUTION

**Legal Text**: "ANY EXCESS CASHFLOW SHALL BE DISTRIBUTED IN THE FOLLOWING MANNER AND ORDER OF PRIORITY"

**Definition of Excess Cashflow**: Remaining Excess Spread + Overcollateralization Release Amount

### Priority 4(A): Interest Carry Forward to Senior Certificates

**Legal Text**: "FROM ANY REMAINING EXCESS CASHFLOW, TO THE CLASS A CERTIFICATES, (A) FIRST, ANY REMAINING INTEREST CARRY FORWARD AMOUNT FOR SUCH CLASSES, PRO RATA, IN ACCORDANCE WITH THE INTEREST CARRY FORWARD AMOUNT DUE WITH RESPECT TO EACH SUCH CLASS... AND (B) SECOND, ANY UNPAID REALIZED LOSS AMOUNT FOR SUCH CLASSES"

**Interpretation**:
- Pay remaining Interest Carry Forward to Class A certificates
- Then pay Unpaid Realized Loss Amounts

### Priority 4(B): Interest Carry Forward to Mezzanine Certificates

**Legal Text**: "FROM ANY REMAINING EXCESS CASHFLOW, SEQUENTIALLY, TO THE CLASS M-1, CLASS M-2, CLASS M-3, CLASS M-4, CLASS M-5, CLASS M-6, CLASS M-7, CLASS M-8, CLASS M-9 AND CLASS M-10 CERTIFICATES, IN THAT ORDER, AN AMOUNT EQUAL TO THE INTEREST CARRY FORWARD AMOUNT FOR EACH SUCH CLASS"

**Interpretation**:
- Sequential payment of Interest Carry Forward to M classes
- This is where M class carry forward gets paid (not in regular interest waterfall)

### Priority 4(C): Basis Risk Shortfall to Senior Certificates + Reserve Fund

**Legal Text**: "FROM ANY REMAINING EXCESS CASHFLOW OTHERWISE DISTRIBUTABLE TO THE CLASS CE INTEREST AND THE CLASS CE CERTIFICATES, TO THE RESERVE FUND, (I) FIRST, TO PAY TO THE CLASSES OF CLASS I-A CERTIFICATES AND CLASS II-A CERTIFICATES, ANY BASIS RISK SHORTFALL CARRY FORWARD AMOUNT FOR SUCH CLASSES... AND (II) SECOND, TO MAINTAIN A BALANCE IN THE RESERVE FUND EQUAL TO THE RESERVE FUND DEPOSIT"

### Priority 4(D): Basis Risk Shortfall to Mezzanine Certificates + Reserve Fund

**Legal Text**: "FROM ANY REMAINING EXCESS CASHFLOW... TO PAY TO THE CLASS M-1, CLASS M-2... CLASS M-10 CERTIFICATES, SEQUENTIALLY IN THAT ORDER, ANY BASIS RISK SHORTFALL CARRY FORWARD AMOUNT"

### Priority 4(E): Relief Act and Prepayment Interest Shortfalls

**Legal Text**: "FROM ANY REMAINING EXCESS CASHFLOW, TO THE CLASS A CERTIFICATES, ON A PRO RATA BASIS... AND THEN SEQUENTIALLY TO THE CLASS M-1... CLASS M-10 CERTIFICATES, IN THAT ORDER, THE AMOUNT OF RELIEF ACT SHORTFALLS AND ANY PREPAYMENT INTEREST SHORTFALLS ALLOCATED TO SUCH CLASSES"

### Priority 4(F): Swap Termination Payments

**Legal Text**: "FROM ANY REMAINING EXCESS CASHFLOW, TO THE DERIVATIVE ADMINISTRATOR FOR PAYMENT TO THE SWAP PROVIDER, ANY SWAP TERMINATION PAYMENTS DUE TO A SWAP PROVIDER TRIGGER EVENT"

### Priority 4(G): Class CE Distribution

**Legal Text**: "FROM ANY REMAINING EXCESS CASHFLOW, TO THE CLASS CE INTEREST AND CLASS CE CERTIFICATES, AN AMOUNT EQUAL TO THE CLASS CE DISTRIBUTION AMOUNT REDUCED BY AMOUNTS DISTRIBUTED IN CLAUSES (C) AND (D) ABOVE"

**Interpretation**: Class CE receives remaining excess cashflow (this is how CE earns its return)

### Priority 4(H): Residual Certificates

**Legal Text**: "FROM ANY REMAINING EXCESS CASHFLOW, TO EACH OF THE CLASS R-1, CLASS R-2, CLASS R-3 AND CLASS RX CERTIFICATES"

---

## Summary Waterfall Diagram

```
INTEREST FUNDS
    │
    ├─► Priority 1(A): Group I Interest → I-A-1, I-A-2, I-A-3 (pro rata)
    │
    ├─► Priority 1(B): Group II Interest → II-A
    │
    ├─► Priority 2: Cross-collateralization of remaining senior interest
    │
    └─► Priority 3: Combined remaining → M-1 → M-2 → ... → M-10 (sequential)


PRINCIPAL FUNDS
    │
    ├─► [If Pre-Stepdown or Trigger Active]
    │       ├─► Group I → I-A-1 → I-A-2 → I-A-3 (sequential to zero)
    │       ├─► Group II → II-A (to zero)
    │       └─► Combined remaining → M-1 → M-2 → ... → M-10 (sequential to zero)
    │
    └─► [If Post-Stepdown and No Trigger]
            ├─► Class A PDA (with 49.80% lockout) split by group
            └─► Each M class PDA (with respective lockout percentage)


EXCESS CASHFLOW
    │
    ├─► Priority 4(A): Interest Carry Forward → Class A (pro rata)
    │
    ├─► Priority 4(B): Interest Carry Forward → M classes (sequential)
    │
    ├─► Priority 4(C): Basis Risk Shortfall → Class A + Reserve Fund
    │
    ├─► Priority 4(D): Basis Risk Shortfall → M classes + Reserve Fund
    │
    ├─► Priority 4(E): Relief Act/PPIS Shortfalls → A then M classes
    │
    ├─► Priority 4(F): Swap Termination Payments
    │
    ├─► Priority 4(G): Class CE Distribution
    │
    └─► Priority 4(H): Residual Certificates
```

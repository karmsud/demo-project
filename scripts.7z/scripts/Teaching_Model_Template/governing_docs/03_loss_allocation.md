# Loss Allocation - Bear Stearns Asset Backed Securities I LLC, Series 2006-HE2

## Document Information
- **Source**: Pooling and Servicing Agreement, Section 5.05 - Allocation of Realized Losses
- **Purpose**: Defines how realized losses on mortgage loans are allocated to certificate classes
- **AI Instruction**: Losses are allocated AFTER distributions are made. The allocation reduces certificate balances in reverse priority order (most subordinate first).

---

## Loss Allocation Waterfall

**Legal Text**: "ALL REALIZED LOSSES ON THE MORTGAGE LOANS... SHALL BE ALLOCATED BY THE TRUSTEE ON EACH DISTRIBUTION DATE AS FOLLOWS:"

### Allocation Order (Most Subordinate First)

| Priority | Recipient | Condition |
|----------|-----------|-----------|
| 1 | Excess Spread | "FIRST, TO EXCESS SPREAD AS PART OF THE PAYMENT IN RESPECT OF THE EXTRA PRINCIPAL DISTRIBUTION AMOUNT" |
| 2 | Class CE | "SECOND, TO THE CLASS CE INTEREST AND CLASS CE CERTIFICATES, UNTIL THE CERTIFICATE PRINCIPAL BALANCE OR UNCERTIFICATED PRINCIPAL BALANCE THEREOF, AS APPLICABLE, HAS BEEN REDUCED TO ZERO" |
| 3 | Class M-10 | "THIRD, TO THE CLASS M-10 CERTIFICATES, UNTIL THE CERTIFICATE PRINCIPAL BALANCE THEREOF HAS BEEN REDUCED TO ZERO" |
| 4 | Class M-9 | "FOURTH, TO THE CLASS M-9 CERTIFICATES, UNTIL THE CERTIFICATE PRINCIPAL BALANCE THEREOF HAS BEEN REDUCED TO ZERO" |
| 5 | Class M-8 | "FIFTH, TO THE CLASS M-8 CERTIFICATES..." |
| 6 | Class M-7 | "SIXTH, TO THE CLASS M-7 CERTIFICATES..." |
| 7 | Class M-6 | "SEVENTH, TO THE CLASS M-6 CERTIFICATES..." |
| 8 | Class M-5 | "EIGHTH, TO THE CLASS M-5 CERTIFICATES..." |
| 9 | Class M-4 | "NINTH, TO THE CLASS M-4 CERTIFICATES..." |
| 10 | Class M-3 | "TENTH, TO THE CLASS M-3 CERTIFICATES..." |
| 11 | Class M-2 | "ELEVENTH, TO THE CLASS M-2 CERTIFICATES..." |
| 12 | Class M-1 | "TWELFTH, TO THE CLASS M-1 CERTIFICATES..." |
| 13 | Related Class A | "THIRTEENTH, TO THE RELATED CLASS OR CLASSES OF CLASS A CERTIFICATES, ON A PRO RATA BASIS" |
| 14 | Unrelated Class A | "FOURTEENTH, TO THE UNRELATED CLASS OR CLASSES OF CLASS A CERTIFICATES, ON A PRO RATA BASIS" |

---

## Key Principles

### Timing of Loss Allocation

**Legal Text**: "ALL REALIZED LOSSES TO BE ALLOCATED TO THE CERTIFICATE PRINCIPAL BALANCES OF ALL CLASSES ON ANY DISTRIBUTION DATE SHALL BE SO ALLOCATED **AFTER** THE ACTUAL DISTRIBUTIONS TO BE MADE ON SUCH DATE"

**Interpretation**: 
1. First, make all interest and principal distributions
2. Then, allocate losses to reduce certificate balances
3. Loss allocation does NOT affect current period distributions

### Method of Allocation

**Legal Text**: "ANY ALLOCATION OF REALIZED LOSSES TO A CLASS OF CERTIFICATES OR TO THE CLASS CE INTEREST ON ANY DISTRIBUTION DATE SHALL BE MADE BY **REDUCING THE CERTIFICATE PRINCIPAL BALANCE** OR UNCERTIFICATED PRINCIPAL BALANCE THEREOF BY THE AMOUNT SO ALLOCATED"

**Interpretation**: Losses reduce the certificate balance, not a direct cash payment.

### Loss Allocation Limitation

**Legal Text**: "NOTWITHSTANDING THE FOREGOING, NO SUCH ALLOCATION OF ANY REALIZED LOSS SHALL BE MADE ON A DISTRIBUTION DATE TO ANY CLASS OF CERTIFICATES TO THE EXTENT THAT SUCH ALLOCATION WOULD RESULT IN THE REDUCTION OF THE AGGREGATE CERTIFICATE PRINCIPAL BALANCE OF ALL THE CERTIFICATES... TO AN AMOUNT LESS THAN THE AGGREGATE STATED PRINCIPAL BALANCE OF ALL OF THE MORTGAGE LOANS"

**Interpretation**: 
- Certificate balances cannot be reduced below pool balance
- This prevents "over-allocation" of losses

### Class P Exclusion

**Legal Text**: "NO ALLOCATIONS OF ANY REALIZED LOSSES SHALL BE MADE TO THE CERTIFICATE PRINCIPAL BALANCE OR UNCERTIFICATED PRINCIPAL BALANCE, AS APPLICABLE, OF THE CLASS P INTEREST AND THE CLASS P CERTIFICATES."

---

## Mathematical Implementation

```python
def allocate_losses(realized_loss, balances, pool_balance):
    """
    Allocate realized losses to certificate classes in reverse priority order.
    
    Args:
        realized_loss: Total realized loss amount to allocate
        balances: Dict of {class_name: current_balance}
        pool_balance: Current pool balance (for limitation check)
    
    Returns:
        Dict of {class_name: loss_allocated}
    """
    
    remaining_loss = realized_loss
    allocations = {cls: 0 for cls in balances}
    
    # Loss allocation order (most subordinate first)
    allocation_order = [
        'CE',
        'M-10', 'M-9', 'M-8', 'M-7', 'M-6',
        'M-5', 'M-4', 'M-3', 'M-2', 'M-1',
        'II-A',  # Unrelated to Group I
        'I-A-3', 'I-A-2', 'I-A-1'  # Group I seniors (pro-rata, but sequential here for simplicity)
    ]
    
    for class_name in allocation_order:
        if remaining_loss <= 0:
            break
        if class_name not in balances:
            continue
            
        # Check loss allocation limitation
        total_cert_balance = sum(balances.values())
        max_allocatable = max(0, total_cert_balance - pool_balance)
        
        # Allocate up to class balance, remaining loss, and limitation
        allocation = min(
            balances[class_name],
            remaining_loss,
            max_allocatable
        )
        
        allocations[class_name] = allocation
        balances[class_name] -= allocation
        remaining_loss -= allocation
    
    return allocations
```

---

## Subsequent Recoveries

**Legal Text**: "IF, AFTER TAKING INTO ACCOUNT SUCH SUBSEQUENT RECOVERIES, THE AMOUNT OF A REALIZED LOSS IS REDUCED, THE AMOUNT OF SUCH SUBSEQUENT RECOVERIES WILL BE APPLIED TO INCREASE THE CERTIFICATE PRINCIPAL BALANCE OF THE CLASS OF CERTIFICATES WITH THE HIGHEST PAYMENT PRIORITY TO WHICH REALIZED LOSSES HAVE BEEN ALLOCATED"

**Interpretation**:
- If losses are later recovered (e.g., from liquidation proceeds exceeding expectations)
- The recovery increases certificate balances
- Starting with the HIGHEST priority class that had losses allocated
- This is the reverse of loss allocation

**Recovery Order** (most senior first, opposite of loss allocation):
1. Class I-A-1, I-A-2, I-A-3 (pro rata)
2. Class II-A
3. Class M-1
4. Class M-2
5. ... through M-10
6. Class CE

**Note**: "HOLDERS OF SUCH CERTIFICATES WILL NOT BE ENTITLED TO ANY PAYMENT IN RESPECT OF CURRENT INTEREST ON THE AMOUNT OF SUCH INCREASES FOR ANY INTEREST ACCRUAL PERIOD PRECEDING THE DISTRIBUTION DATE ON WHICH SUCH INCREASE OCCURS"

This means recovered principal doesn't earn back-interest.

# Trigger Events and Stepdown - Bear Stearns Asset Backed Securities I LLC, Series 2006-HE2

## Document Information
- **Source**: Pooling and Servicing Agreement, Definitions Section
- **Purpose**: Defines conditions that affect principal distribution waterfall
- **AI Instruction**: Triggers determine whether principal follows Pre-Stepdown (sequential to zero) or Post-Stepdown (lockout percentage) rules.

---

## Stepdown Date

### Definition

**Legal Text**: "Stepdown Date: The later to occur of (a) the Distribution Date in **March 2009** and (b) the first Distribution Date on which the **Current Specified Enhancement Percentage is greater than or equal to 50.20%**."

### Interpretation

Both conditions must be satisfied for stepdown to be eligible:

1. **Time Condition**: Distribution Date >= March 2009
   - First distribution is March 2006 (month 1)
   - March 2009 is month 37
   - So: `distribution_month >= 37`

2. **Enhancement Condition**: Current Specified Enhancement Percentage >= 50.20%
   - Enhancement = (M Class Balances + OC Amount) / Pool Balance
   - Must be >= 0.5020

### Mathematical Test

```python
def is_stepdown_eligible(month, enhancement_pct):
    """
    Determine if stepdown conditions are met.
    
    Args:
        month: Distribution month number (1 = March 2006)
        enhancement_pct: Current Specified Enhancement Percentage
    
    Returns:
        bool: True if stepdown is eligible
    """
    time_condition = month >= 37  # March 2009
    enhancement_condition = enhancement_pct >= 0.5020
    
    return time_condition and enhancement_condition
```

---

## Trigger Event

### Definition

**Legal Text**: "Trigger Event: With respect to any Distribution Date, a Trigger Event exists if (i) a **Delinquency Event** shall have occurred and be continuing or (ii) the **aggregate amount of Realized Losses** on the Mortgage Loans since the Cut-off Date as a percentage of the aggregate Cut-off Date Principal Balance of the Mortgage Loans exceeds the applicable percentages set forth below"

### Interpretation

Either condition triggers a Trigger Event:

1. **Delinquency Event** (see below)
2. **Cumulative Loss Trigger** (exceeds schedule)

If a Trigger Event is active, principal distribution follows the Pre-Stepdown waterfall (sequential to zero) even if past the Stepdown Date.

---

## Delinquency Event

### Definition

**Legal Text**: "Delinquency Event: A Delinquency Event shall have occurred and be continuing if at any time, (x) the percent equivalent of a fraction, the numerator of which is the **aggregate Stated Principal Balance of the Mortgage Loans that are 60 days or more Delinquent** (including for this purpose any such Mortgage Loans in **bankruptcy or foreclosure** and Mortgage Loans with respect to which the related Mortgaged Property is **REO Property**), and the denominator of which is the aggregate Stated Principal Balance of all of the Mortgage Loans as of the last day of the related Due Period exceeds (y) **31.75%** of the Current Specified Enhancement Percentage."

### Components of 60+ Day Delinquency

The numerator includes:
- Loans 60+ days delinquent
- Loans in bankruptcy (regardless of delinquency status)
- Loans in foreclosure
- REO Properties

### Mathematical Test

```python
def is_delinquency_event(dq_60_plus, bankruptcy, foreclosure, reo, 
                          pool_balance, enhancement_pct):
    """
    Determine if a Delinquency Event is in effect.
    
    Args:
        dq_60_plus: Balance of loans 60+ days delinquent
        bankruptcy: Balance of loans in bankruptcy
        foreclosure: Balance of loans in foreclosure
        reo: Balance of REO properties
        pool_balance: Current aggregate pool balance
        enhancement_pct: Current Specified Enhancement Percentage
    
    Returns:
        bool: True if Delinquency Event is in effect
    """
    # Calculate delinquency ratio
    delinquent_balance = dq_60_plus + bankruptcy + foreclosure + reo
    dq_ratio = delinquent_balance / pool_balance
    
    # Calculate threshold
    threshold = 0.3175 * enhancement_pct
    
    return dq_ratio > threshold
```

---

## Cumulative Loss Trigger

### Definition

**Legal Text**: "the aggregate amount of Realized Losses on the Mortgage Loans since the Cut-off Date as a percentage of the aggregate Cut-off Date Principal Balance of the Mortgage Loans exceeds the applicable percentages set forth below with respect to such Distribution Date"

### Loss Trigger Schedule

The PSA includes a schedule of maximum cumulative loss percentages by distribution date. If cumulative losses exceed the scheduled percentage for that month, the Loss Trigger is activated.

**Note**: The exact schedule varies by deal and should be extracted from the PSA exhibits.

For Bear Stearns 2006-HE2, a typical structure would be:

| Period | Max Cumulative Loss % |
|--------|----------------------|
| Months 1-12 | Varies by month |
| Months 13-24 | Varies by month |
| ... | ... |

### Mathematical Test

```python
def is_loss_trigger_active(cumulative_loss, original_pool_balance, 
                           month, loss_schedule):
    """
    Determine if the Loss Trigger is in effect.
    
    Args:
        cumulative_loss: Total realized losses since cut-off
        original_pool_balance: Cut-off Date Principal Balance
        month: Distribution month number
        loss_schedule: Dict of {month: max_loss_pct} or callable
    
    Returns:
        bool: True if Loss Trigger is in effect
    """
    loss_pct = cumulative_loss / original_pool_balance
    
    if callable(loss_schedule):
        max_loss_pct = loss_schedule(month)
    else:
        max_loss_pct = loss_schedule.get(month, float('inf'))
    
    return loss_pct > max_loss_pct
```

---

## Combined Trigger Logic

### Decision Tree

```
Is Stepdown Date Reached?
├── NO → Use Pre-Stepdown Waterfall (sequential to zero)
│
└── YES → Is Trigger Event Active?
          ├── YES (Delinquency OR Loss Trigger) 
          │    → Use Pre-Stepdown Waterfall (sequential to zero)
          │
          └── NO 
               → Use Post-Stepdown Waterfall (lockout percentages)
```

### Implementation

```python
def get_principal_waterfall_mode(month, enhancement_pct, 
                                  dq_60_plus, bankruptcy, foreclosure, reo,
                                  pool_balance, cumulative_loss, 
                                  original_pool_balance, loss_schedule):
    """
    Determine which principal distribution waterfall to use.
    
    Returns:
        str: 'PRE_STEPDOWN' or 'POST_STEPDOWN'
    """
    # Check stepdown eligibility
    stepdown_eligible = is_stepdown_eligible(month, enhancement_pct)
    
    if not stepdown_eligible:
        return 'PRE_STEPDOWN'
    
    # Check for trigger events
    dq_trigger = is_delinquency_event(
        dq_60_plus, bankruptcy, foreclosure, reo, 
        pool_balance, enhancement_pct
    )
    
    loss_trigger = is_loss_trigger_active(
        cumulative_loss, original_pool_balance, 
        month, loss_schedule
    )
    
    trigger_active = dq_trigger or loss_trigger
    
    if trigger_active:
        return 'PRE_STEPDOWN'
    else:
        return 'POST_STEPDOWN'
```

---

## Current Specified Enhancement Percentage

### Definition

**Legal Text**: "Current Specified Enhancement Percentage: With respect to any Distribution Date, the percentage obtained by dividing (x) the sum of (i) the **aggregate Certificate Principal Balance of the Class M Certificates** and (ii) the **Overcollateralization Amount**, in each case prior to the distribution of the Principal Distribution Amount on such Distribution Date, by (y) the **aggregate Stated Principal Balance of the Mortgage Loans** as of the end of the related Due Period."

### Mathematical Formula

```python
def calculate_enhancement_pct(m_class_balances, oc_amount, pool_balance):
    """
    Calculate Current Specified Enhancement Percentage.
    
    Args:
        m_class_balances: List of M-1 through M-10 balances
        oc_amount: Current Overcollateralization Amount
        pool_balance: Current pool balance
    
    Returns:
        float: Enhancement percentage (e.g., 0.45 for 45%)
    """
    total_m_balance = sum(m_class_balances)
    numerator = total_m_balance + oc_amount
    
    if pool_balance == 0:
        return 1.0  # Fully enhanced if pool is zero
    
    return numerator / pool_balance
```

---

## Impact on Principal Distribution

| Scenario | Waterfall | Effect |
|----------|-----------|--------|
| Pre-Stepdown | Sequential to zero | Seniors paid first until balance = 0, then subordinates |
| Post-Stepdown + Trigger | Sequential to zero | Same as Pre-Stepdown |
| Post-Stepdown + No Trigger | Lockout percentages | Each class limited by its subordination percentage |

### Example

- Month 40, Enhancement = 55%, No triggers
- Stepdown eligible: YES (month >= 37, enhancement >= 50.20%)
- Trigger active: NO
- **Result**: Post-Stepdown waterfall with lockout percentages

- Month 40, Enhancement = 55%, Delinquency Event
- Stepdown eligible: YES
- Trigger active: YES (delinquency)
- **Result**: Pre-Stepdown waterfall (sequential to zero)

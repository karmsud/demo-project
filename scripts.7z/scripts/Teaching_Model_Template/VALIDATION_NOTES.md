# Teaching Model Validation Notes

## Validation Status: ✅ PASSED

**Date Validated:** January 24, 2026  
**Month Tested:** Month 1  
**Result:** All 20 classes match exactly (0.0000 difference)

## Comparison Results

| Class | Expected Interest | Teaching Interest | Diff |
|-------|------------------|-------------------|------|
| 1 (I-A-1) | 696,629.05 | 696,629.05 | 0.00 ✓ |
| 2 (I-A-2) | 268,976.69 | 268,976.69 | 0.00 ✓ |
| 3 (I-A-3) | 52,857.56 | 52,857.56 | 0.00 ✓ |
| 4 (II-A) | 871,015.56 | 871,015.56 | 0.00 ✓ |
| 5-14 (M classes) | Various | Various | 0.00 ✓ |
| 15-19 (P, R) | 0.00 | 0.00 | 0.00 ✓ |
| 20 (CE) | 1,742,279.23 | 1,742,279.23 | 0.00 ✓ |

| Class | Expected Principal | Teaching Principal | Diff |
|-------|-------------------|-------------------|------|
| 1 (I-A-1) | 4,203,847.91 | 4,203,847.91 | 0.00 ✓ |
| 4 (II-A) | 4,139,869.55 | 4,139,869.55 | 0.00 ✓ |
| 20 (CE) | 8,343,637.12 | 8,343,637.12 | 0.00 ✓ |

## Key Implementation Details

### 1. Net Rate Cap
The teaching model correctly implements the Net Rate Cap calculation:
```
Net_Rate_Cap = (Loan_Group_Interest × 12 / Loan_Group_Balance) × (30 / Actual_Days)
Pass_Through_Rate = min(LIBOR + Margin, Net_Rate_Cap)
```

### 2. Cross-Group Interest Allocation
Interest is distributed with loan group priority:
1. Group 1 interest → I-A-1, I-A-2, I-A-3
2. Group 2 interest → II-A
3. Group 1 surplus → II-A shortfall
4. Group 2 surplus → I-A shortfall
5. Remaining → M classes sequentially

### 3. CE Class Treatment
CE (Class 20) receives:
- **Interest**: All remaining IRA after classes 1-14
- **Principal**: PDA + (OC_excess - OC_deficiency)

### 4. Principal Distribution Amount (PDA)
```
BPDA = max(0, PRA - OC_excess)
EPDA = min(remaining_IRA, OC_deficiency)
PDA = BPDA + EPDA
```

## Files Validated
- Production: `Bear Stearns 2006-HE2/Data/month_1/output.csv`
- Teaching: `Teaching_Model_Template/Data/month_1/output_teaching.csv`

# Teaching Model Template

## Purpose

This folder contains a **teaching sample** for AI-assisted generation of mortgage-backed securities (MBS) / asset-backed securities (ABS) payment models. The sample demonstrates how to translate legal governing documents (Pooling and Servicing Agreements, Prospectus Supplements) into executable Python payment calculation code.

**This is NOT a reusable library or engine.** Each deal requires its own unique payment model generated from that deal's specific governing documents.

---

## Sample Deal: Bear Stearns Asset Backed Securities I LLC, Series 2006-HE2

This teaching sample is based on the Bear Stearns 2006-HE2 securitization deal. The governing documents, setup files, and payment model are all specific to this deal and serve as a worked example showing:

1. How to interpret legal document language
2. How to extract deal parameters from documents
3. How to translate waterfall priorities into code
4. How to structure input/output files

---

## Folder Structure

```
Teaching_Model_Template/
├── README.md                    # This file
├── sample_teaching_model.py     # The teaching payment model (heavily annotated)
├── governing_docs/              # Enhanced markdown versions of legal documents
│   ├── 01_definitions.md        # Defined terms from the PSA
│   ├── 02_waterfall.md          # Distribution priorities (interest, principal, excess)
│   ├── 03_loss_allocation.md    # Realized loss allocation rules
│   └── 04_triggers.md           # Stepdown date, trigger events
├── Data/
│   ├── deal_setup.csv           # Static deal constants (does not change month-to-month)
│   ├── classes_setup.csv        # Certificate class definitions and parameters
│   └── month_1/                 # Monthly input/output data
│       ├── monthly_input.csv    # Pool performance and rate data for this period
│       ├── prior_shortfalls.csv # Carry-forward amounts from prior periods
│       ├── output.csv           # Generated: Payment results
│       └── debug.csv            # Generated: Intermediate calculations for validation
```

---

## File Schemas

### deal_setup.csv

Contains deal-level constants that **do not change** month-to-month. These values are extracted from the governing documents during initial deal setup.

| Field | Description | Source Document Section |
|-------|-------------|------------------------|
| deal_name | Deal identifier | Cover page |
| closing_date | Original closing date | Definitions: "Closing Date" |
| cutoff_date | Pool cutoff date | Definitions: "Cut-off Date" |
| original_pool_balance | Aggregate Cut-off Date Principal Balance | Definitions: "Cut-off Date Principal Balance" |
| stepdown_month | Month number when stepdown can occur | Definitions: "Stepdown Date" |
| oc_target_pct | Overcollateralization target percentage | Definitions: "Overcollateralization Target Amount" |
| oc_floor_amount | Minimum OC dollar amount | Definitions: "Overcollateralization Target Amount" |
| oc_stepdown_pct | OC target percentage after stepdown | Definitions: "Overcollateralization Target Amount" |
| reserve_fund_required | Required reserve fund balance | Definitions: "Reserve Fund Deposit" |
| servicing_fee_rate | Annual servicing fee rate | Definitions: "Servicing Fee Rate" |
| trustee_fee_rate | Annual trustee fee rate | Definitions: "Trustee Fee" |
| current_enhancement_pct | Initial credit enhancement percentage | Definitions: "Current Specified Enhancement Percentage" |
| loss_trigger_schedule | JSON array of [month, max_cum_loss_pct] pairs | Definitions: "Trigger Event" |
| delinquency_trigger_formula | Formula for delinquency trigger | Definitions: "Delinquency Event" |

### classes_setup.csv

Defines each certificate class and its parameters. One row per class.

| Field | Description | Source |
|-------|-------------|--------|
| class_id | Sequential numeric ID (1, 2, 3...) | N/A (internal) |
| class_name | Certificate class name (e.g., "I-A-1", "M-1") | PSA Section 6.01 |
| loan_group | Which loan group this class is associated with (1, 2, or "both") | PSA waterfall section |
| class_type | "senior", "mezzanine", "subordinate", "ce", "residual", "other" | PSA structure |
| original_balance | Initial Certificate Principal Balance | Preliminary Statement |
| margin | Certificate Margin (spread over LIBOR) | Definitions: "Certificate Margin" |
| margin_step_up | Margin after Optional Termination Date (if different) | Definitions: "Certificate Margin" |
| lockout_pct | For stepdown: percentage floor (e.g., 0.498 for Class A) | Definitions: Class X Principal Distribution Amount |
| interest_accrual | "actual/360", "30/360", etc. | Definitions: "Accrual Period" |
| is_interest_bearing | TRUE/FALSE | Class definition |
| is_principal_bearing | TRUE/FALSE | Class definition |
| sequential_order | Order within sequential pay-down (1=first, 2=second, etc.) | Waterfall section |
| distribution_priority_interest | Priority in interest waterfall | Waterfall section 5.04(a)(1) |
| distribution_priority_principal | Priority in principal waterfall | Waterfall section 5.04(a)(2) |

### monthly_input.csv

Monthly varying data provided by servicer reports. Key-value format.

| Field | Description |
|-------|-------------|
| distribution_month | Month number (1, 2, 3...) |
| distribution_date | Actual distribution date |
| libor_rate | One-Month LIBOR for this period |
| actual_days | Days in the accrual period |
| beg_pool_balance | Beginning aggregate pool balance |
| end_pool_balance | Ending aggregate pool balance |
| beg_pool_balance_grp1 | Beginning Loan Group I balance |
| end_pool_balance_grp1 | Ending Loan Group I balance |
| beg_pool_balance_grp2 | Beginning Loan Group II balance |
| end_pool_balance_grp2 | Ending Loan Group II balance |
| interest_collected_grp1 | Interest collected from Group I loans |
| interest_collected_grp2 | Interest collected from Group II loans |
| principal_collected_grp1 | Principal collected from Group I loans |
| principal_collected_grp2 | Principal collected from Group II loans |
| scheduled_principal_grp1 | Scheduled principal from Group I |
| scheduled_principal_grp2 | Scheduled principal from Group II |
| prepayments_grp1 | Prepayments from Group I |
| prepayments_grp2 | Prepayments from Group II |
| cumulative_loss_grp1 | Cumulative realized losses, Group I |
| cumulative_loss_grp2 | Cumulative realized losses, Group II |
| current_period_loss | Realized losses this period |
| dq_30_balance | 30+ days delinquent balance |
| dq_60_balance | 60+ days delinquent balance |
| dq_90_balance | 90+ days delinquent balance |
| foreclosure_balance | Balance in foreclosure |
| reo_balance | REO property balance |
| bankruptcy_balance | Balance in bankruptcy |
| reserve_fund_balance | Current reserve fund balance |
| prepayment_interest_shortfall | PPIS for this period |
| relief_act_shortfall | Relief Act interest shortfall |

### prior_shortfalls.csv

Carry-forward amounts from prior periods. One row per class.

| Field | Description |
|-------|-------------|
| class_name | Certificate class name |
| interest_carry_forward | Unpaid interest carry-forward amount |
| basis_risk_shortfall | Unpaid basis risk shortfall |
| realized_loss_applied | Cumulative realized losses allocated to this class |

### output.csv

Generated by the payment model. One row per class.

| Field | Description |
|-------|-------------|
| class_id | Sequential class ID |
| class_name | Certificate class name |
| interest_due | Interest due this period |
| interest_paid | Interest actually paid |
| interest_shortfall | Unpaid interest (carry-forward to next period) |
| principal_paid | Principal paid this period |
| beginning_balance | Certificate balance at period start |
| ending_balance | Certificate balance at period end |
| realized_loss_allocated | Losses allocated this period |
| basis_risk_shortfall_paid | Basis risk shortfall recovered |

### debug.csv

Intermediate calculations for validation. Key-value format.

| Field | Description |
|-------|-------------|
| stepdown_eligible | TRUE/FALSE - is stepdown date reached? |
| loss_trigger_active | TRUE/FALSE - is loss trigger in effect? |
| dq_trigger_active | TRUE/FALSE - is delinquency trigger in effect? |
| trigger_event_active | TRUE/FALSE - combined trigger status |
| oc_target | Target overcollateralization amount |
| oc_current | Current overcollateralization amount |
| oc_excess | Excess OC available for release |
| oc_deficiency | OC shortfall requiring buildup |
| total_interest_available | Total interest funds available |
| total_principal_available | Total principal funds available |
| excess_spread | Calculated excess spread |
| extra_principal_amount | EPDA for OC buildup |
| remaining_excess_cashflow | Funds for excess waterfall |
| reserve_fund_draw | Amount drawn from reserve |
| reserve_fund_deposit | Amount deposited to reserve |

---

## How to Use This Teaching Sample

### For AI Model Generation

1. **Study the structure**: Review how `sample_teaching_model.py` is organized
2. **Understand the process**: Each code section shows:
   - The original legal text being implemented
   - Phrase-by-phrase interpretation
   - Mathematical formulation
   - Code implementation
3. **Apply to new deals**: Read the new deal's governing documents, understand what they require, and generate appropriate code - do NOT copy values or logic from this sample unless the new deal's documents specify the same approach

### For Human Validation

1. **Prepare input files**: Populate `monthly_input.csv` and `prior_shortfalls.csv` from servicer reports
2. **Run the model**: `python sample_teaching_model.py`
3. **Compare output**: Validate `output.csv` against independently-prepared Excel model
4. **Debug if needed**: Use `debug.csv` to trace calculation differences

---

## Critical Warning for AI Model Generation

**DO NOT** copy numeric values from this sample to other deals. Every value in `deal_setup.csv` and `classes_setup.csv` must be extracted from that specific deal's governing documents.

Examples of deal-specific values that vary:
- OC target percentages
- Lockout percentages for stepdown
- Certificate margins
- Trigger thresholds
- Reserve fund requirements
- Class names and count
- Loan group structure

The **PROCESS** shown here (how to interpret legal text and translate to code) is what should be learned, not the specific values or formulas.

---

## Document Preparation Guidelines

For AI to successfully generate a payment model, governing documents should be prepared as follows:

1. **Convert to plain text or markdown** - Remove PDF formatting artifacts
2. **Preserve section structure** - Keep section numbers and headings
3. **Include all defined terms** - The definitions section is critical
4. **Preserve exact legal language** - Do not paraphrase or summarize
5. **Mark waterfall priorities clearly** - Number each distribution priority
6. **Include all formula definitions** - Especially for Principal Distribution Amounts

---

## Version History

| Date | Version | Description |
|------|---------|-------------|
| 2026-01-24 | 1.0 | Initial teaching model based on Bear Stearns 2006-HE2 |

---

## Contact

This teaching model was developed as part of a payment engine automation initiative. For questions about the structure or approach, refer to the conversation history documenting the design decisions.

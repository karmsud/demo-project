# prompt.md — GHCP prompts to setup + run the PAT smoke test

## Prompt 1 — Setup environment
> You are in a VS Code project folder that contains `requirements.txt`, `.env.example`, and `test_github_models_pat.py`.
> Create a Python venv in `.venv`, activate it in PowerShell, install requirements, and confirm imports succeed.

## Prompt 2 — Create .env from .env.example
> Copy `.env.example` to `.env`. Then instruct me where to paste my GitHub Models PAT in `.env`.
> Do not print secrets.

## Prompt 3 — Run smoke test
> Run: `python .\test_github_models_pat.py "Say hello in one sentence."`
> If it fails, inspect the error output and tell me the most likely cause and exact remediation steps.

## Prompt 4 — Diagnose common 401/403
> If we get HTTP 401 or 403, explain whether it's missing Models permission, SSO authorization, org model allowlist, or endpoint/network issue.
> Provide the next concrete action for each case.

## Prompt 5 — Change model name
> If the model is blocked, try a smaller/alternate allowed model name by editing `GITHUB_MODELS_MODEL` in `.env`, then rerun the test.

GitHub Models PAT Smoke Test (Python)
====================================

This is a minimal smoke test to verify your GitHub fine-grained PAT can call GitHub Models
from a Python script inside VS Code.

FILES
- requirements.txt
- .env.example  (copy to .env and fill in your PAT)
- test_github_models_pat.py
- prompt.md     (copy/paste prompts for GitHub Copilot Chat)

STEPS (Windows PowerShell)
1) Unzip this folder
2) Open folder in VS Code
3) Create venv and install deps:
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt

4) Create .env:
   Copy-Item .env.example .env
   notepad .env
   (paste your PAT in GITHUB_MODELS_PAT=...)

5) Run:
   python .\test_github_models_pat.py "Say hello in one sentence."

If it prints a valid response, your PAT works.

import os
import sys
import json
import requests
from dotenv import load_dotenv
from langsmith import traceable

load_dotenv()

API_URL = os.getenv("GITHUB_MODELS_URL", "https://models.github.ai/inference/chat/completions").strip()
MODEL = os.getenv("GITHUB_MODELS_MODEL", "openai/gpt-4.1").strip()
PAT = os.getenv("GITHUB_MODELS_PAT", "").strip()

@traceable(run_type="llm", name="github_models_smoke_test")
def call_model(prompt: str) -> str:
    headers = {
        "Authorization": f"Bearer {PAT}",
        "Content-Type": "application/json",
        "X-GitHub-Api-Version": "2022-11-28",
        "Accept": "application/vnd.github+json",
    }

    body = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.2,
        "stream": False,
    }

    r = requests.post(API_URL, headers=headers, json=body, timeout=120)
    r.raise_for_status()  # raise for bad status
    data = r.json()
    return data["choices"][0]["message"]["content"].strip()

def main() -> int:
    prompt = " ".join(sys.argv[1:]).strip() or "Say hello in one sentence."

    if not PAT or "PASTE_YOUR_PAT_HERE" in PAT:
        print("ERROR: GITHUB_MODELS_PAT is not set (or still placeholder).")
        print("Edit .env and set GITHUB_MODELS_PAT to your token.")
        return 2

    try:
        response_content = call_model(prompt)
        print(response_content)
    except requests.RequestException as e:
        print(f"NETWORK ERROR: {e}")
        return 3
    except Exception as e:
        print(f"ERROR: {e}")
        return 4

    return 0

if __name__ == "__main__":
    raise SystemExit(main())

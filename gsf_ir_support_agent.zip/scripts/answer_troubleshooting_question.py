import argparse
import json
import os
from typing import Any, Dict, List, Tuple, Optional
from datetime import datetime

import numpy as np
from sentence_transformers import SentenceTransformer
import networkx as nx
from networkx.readwrite import json_graph
import nltk

try:
    nltk.data.find("tokenizers/punkt")
except LookupError:
    try:
        nltk.download("punkt", quiet=True)
    except Exception:
        pass

from nltk.tokenize import sent_tokenize

try:
    from PIL import Image
    import pytesseract
except Exception:
    Image = None
    pytesseract = None


def load_embeddings(path: str) -> Tuple[str, Optional[str], np.ndarray, List[Dict[str, Any]]]:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    model_name = data["model_name"]
    guide_version = data.get("guide_version")
    sections = data["sections"]
    embs = np.array([s["embedding"] for s in sections], dtype=float)
    return model_name, guide_version, embs, sections


def load_graph(path: str) -> nx.Graph:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return json_graph.node_link_graph(data)


def ocr_image(path: str) -> str:
    if Image is None or pytesseract is None:
        return ""
    try:
        img = Image.open(path)
        text = pytesseract.image_to_string(img)
        return text or ""
    except Exception:
        return ""


def build_query_embedding(
    model_name: str, question: str, error_text: str
) -> np.ndarray:
    model = SentenceTransformer(model_name)
    full_query = (question or "") + "\n" + (error_text or "")
    return model.encode(full_query, convert_to_numpy=True, normalize_embeddings=True)


def rank_sections(
    query_emb: np.ndarray, section_embs: np.ndarray, sections_meta: List[Dict[str, Any]], top_k: int
) -> List[Dict[str, Any]]:
    scores = section_embs @ query_emb
    indices = np.argsort(scores)[::-1][:top_k]
    results: List[Dict[str, Any]] = []
    for rank, idx in enumerate(indices, start=1):
        sec_meta = sections_meta[idx]
        results.append(
            {
                "rank": rank,
                "score": float(scores[idx]),
                "id": sec_meta["id"],
                "heading": sec_meta["heading"],
            }
        )
    return results


def extract_section_text_from_graph(G: nx.Graph, section_id: int) -> str:
    node = G.nodes.get(section_id)
    if not node:
        return ""
    return node.get("text") or ""


def build_solution_steps(text: str, mode: str = "quick") -> List[str]:
    if not text:
        return []
    sentences = sent_tokenize(text)
    cleaned = [s.strip() for s in sentences if s.strip()]
    if mode == "quick":
        return cleaned[:8]  # fewer steps
    return cleaned  # deep = full sentences


def confidence_band(score: float) -> str:
    if score >= 0.8:
        return "high"
    if score >= 0.5:
        return "medium"
    return "low"


def build_answer_markdown(
    ranked_sections: List[Dict[str, Any]], G: nx.Graph, mode: str = "quick"
) -> Tuple[str, List[Dict[str, Any]], float, str]:
    if not ranked_sections:
        return (
            "I could not find any matching solution in the troubleshooting guide "
            "for this error. Please try rephrasing the question or adding more "
            "context.",
            [],
            0.0,
            "low",
        )

    solutions: List[Dict[str, Any]] = []
    max_score = max(s["score"] for s in ranked_sections)
    band = confidence_band(max_score)
    overall_confidence = float(max_score)

    for sec in ranked_sections:
        sec_id = sec["id"]
        text = extract_section_text_from_graph(G, sec_id)
        steps = build_solution_steps(text, mode=mode)
        solutions.append(
            {
                "rank": sec["rank"],
                "score": sec["score"],
                "section_id": sec_id,
                "heading": sec["heading"],
                "steps": steps,
            }
        )

    lines: List[str] = []
    best = solutions[0]
    lines.append(f"## Suggested solution (Rank 1: {best['heading']})")
    lines.append("")
    lines.append(f"_Confidence: {band} (score {overall_confidence:.3f})_")
    lines.append("")

    if best["steps"]:
        lines.append("### Step-by-step fix")
        lines.append("")
        for i, step in enumerate(best["steps"], start=1):
            lines.append(f"{i}. {step}")
        lines.append("")
    else:
        lines.append(
            "The troubleshooting guide contains a relevant section, "
            "but I could not extract detailed steps automatically. "
            "Please open the section in the guide for full context."
        )
        lines.append("")

    if len(solutions) > 1:
        lines.append("### Other possible solutions")
        lines.append("")
        for sol in solutions[1:]:
            lines.append(f"- **Rank {sol['rank']}** – {sol['heading']} (score {sol['score']:.3f})")
        lines.append("")

    lines.append("### References")
    lines.append("")
    for sol in solutions:
        lines.append(f"- Section ID `{sol['section_id']}` – {sol['heading']}")
    lines.append("")

    if band == "low":
        lines.append("> Confidence is low. Consider rephrasing the question or including more context.")
        lines.append("")

    return "\n".join(lines), solutions, overall_confidence, band


def append_query_log(
    log_path: str,
    question: str,
    error_text: str,
    guide_version: Optional[str],
    solutions: List[Dict[str, Any]],
    confidence: float,
    band: str,
) -> None:
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    record = {
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "question": question,
        "error_text": error_text,
        "guide_version": guide_version,
        "top_solutions": [
            {
                "rank": s["rank"],
                "score": s["score"],
                "section_id": s["section_id"],
                "heading": s["heading"],
            }
            for s in solutions
        ],
        "confidence": confidence,
        "confidence_band": band,
    }
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")


def main():
    parser = argparse.ArgumentParser(
        description="Answer a troubleshooting question using precomputed guide artifacts."
    )
    parser.add_argument("--question", type=str, required=True, help="Short restatement of the user's question.")
    parser.add_argument("--error-text", type=str, default="", help="Full error message text.")
    parser.add_argument(
        "--screenshot-path",
        type=str,
        default=None,
        help="Optional path to an error screenshot image for OCR.",
    )
    parser.add_argument(
        "--markdown",
        type=str,
        required=True,
        help="Path to enhanced Markdown (not strictly required for ranking, but useful for future extensions).",
    )
    parser.add_argument(
        "--embeddings",
        type=str,
        required=True,
        help="Path to embeddings JSON created by build_troubleshooting_kb.py.",
    )
    parser.add_argument(
        "--graph",
        type=str,
        required=True,
        help="Path to graph JSON created by build_troubleshooting_kb.py.",
    )
    parser.add_argument(
        "--top-k",
        type=int,
        default=5,
        help="Maximum number of candidate solutions to return.",
    )
    parser.add_argument(
        "--mode",
        type=str,
        default="quick",
        choices=["quick", "deep"],
        help="Answer mode: 'quick' for concise steps, 'deep' for more detailed explanation.",
    )
    parser.add_argument(
        "--out",
        type=str,
        required=True,
        help="Output JSON path for the structured answer.",
    )
    parser.add_argument(
        "--log-path",
        type=str,
        default=".github/skills/troubleshooting-kb/data/query_log.jsonl",
        help="Where to append query logs.",
    )
    args = parser.parse_args()

    screenshot_text = ""
    if args.screenshot_path:
        screenshot_text = ocr_image(args.screenshot_path)

    combined_error_text = "\n".join(
        [t for t in [args.error_text, screenshot_text] if t]
    )

    model_name, guide_version, section_embs, sections_meta = load_embeddings(args.embeddings)
    query_emb = build_query_embedding(model_name, args.question, combined_error_text)
    ranked = rank_sections(query_emb, section_embs, sections_meta, top_k=args.top_k)
    G = load_graph(args.graph)

    answer_markdown, solutions, confidence, band = build_answer_markdown(ranked, G, mode=args.mode)

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    output = {
        "question": args.question,
        "error_text": combined_error_text,
        "answer_markdown": answer_markdown,
        "solutions": solutions,
        "relevant_sections": [
            {"id": s["section_id"], "heading": s["heading"]} for s in solutions
        ],
        "confidence": confidence,
        "confidence_band": band,
        "guide_version": guide_version,
    }
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2)

    # Append query log
    append_query_log(
        args.log_path,
        args.question,
        combined_error_text,
        guide_version,
        solutions,
        confidence,
        band,
    )

    print("Answer written to", args.out)
    print(f"Confidence band: {band} (score {confidence:.3f})")
    print("Top candidate sections:")
    for sol in solutions:
        print(f"- Rank {sol['rank']}: {sol['heading']} (id={sol['section_id']}, score={sol['score']:.3f})")


if __name__ == "__main__":
    main()

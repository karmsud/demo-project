"""
Simple regression harness for the GSF IR Support Agent KB.

You populate TEST_CASES with (question, error_text, expected_section_ids)
and this script will report whether the expected sections appear in the
top-k candidates from answer_troubleshooting_question.py.
"""

import json
import os
import subprocess
import sys
from typing import List, Dict, Any

# Edit this list with your own known-good mappings.
TEST_CASES = [
    # Example:
    # {
    #     "name": "ABC-123 connection failure",
    #     "question": "ABC-123 connection failure in ingestion pipeline",
    #     "error_text": "ABC-123: Failed to connect to upstream service",
    #     "expected_section_ids": [3, 4],
    # }
]


def run_answer_script(
    question: str,
    error_text: str,
    top_k: int = 5,
    mode: str = "quick",
    out_path: str = ".github/skills/troubleshooting-kb/data/test_answer.json",
) -> Dict[str, Any]:
    cmd = [
        sys.executable,
        "scripts/answer_troubleshooting_question.py",
        "--question",
        question,
        "--error-text",
        error_text,
        "--markdown",
        ".github/skills/troubleshooting-kb/data/guide_enhanced.md",
        "--embeddings",
        ".github/skills/troubleshooting-kb/data/guide_embeddings.json",
        "--graph",
        ".github/skills/troubleshooting-kb/data/guide_graph.json",
        "--top-k",
        str(top_k),
        "--mode",
        mode,
        "--out",
        out_path,
    ]
    subprocess.check_call(cmd)
    with open(out_path, "r", encoding="utf-8") as f:
        return json.load(f)


def main():
    if not TEST_CASES:
        print("No TEST_CASES defined. Edit scripts/test_troubleshooting_kb.py to add some.")
        return

    passed = 0
    for case in TEST_CASES:
        print(f"Running test: {case['name']}")
        result = run_answer_script(
            question=case["question"],
            error_text=case.get("error_text", ""),
            top_k=5,
            mode="quick",
        )
        candidate_ids = [s["section_id"] for s in result.get("solutions", [])]
        expected_ids = case["expected_section_ids"]
        if any(eid in candidate_ids for eid in expected_ids):
            print(f"  PASS: Expected one of {expected_ids}, got candidates {candidate_ids}")
            passed += 1
        else:
            print(f"  FAIL: Expected one of {expected_ids}, got candidates {candidate_ids}")

    print(f"Summary: {passed}/{len(TEST_CASES)} tests passed.")


if __name__ == "__main__":
    main()

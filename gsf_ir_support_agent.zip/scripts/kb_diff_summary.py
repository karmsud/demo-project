"""
Compare two embeddings JSON files (old vs new) and summarize which
section headings were added or removed. Useful after rebuilding the KB.
"""

import json
import argparse
from typing import Dict, Any, Set


def load_headings(path: str) -> Dict[int, str]:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return {s["id"]: s["heading"] for s in data.get("sections", [])}


def main():
    parser = argparse.ArgumentParser(description="Summarize differences between two KB embeddings files.")
    parser.add_argument("--old", required=True, help="Path to old embeddings JSON.")
    parser.add_argument("--new", required=True, help="Path to new embeddings JSON.")
    args = parser.parse_args()

    old_heads = load_headings(args.old)
    new_heads = load_headings(args.new)

    old_ids: Set[int] = set(old_heads.keys())
    new_ids: Set[int] = set(new_heads.keys())

    added_ids = sorted(new_ids - old_ids)
    removed_ids = sorted(old_ids - new_ids)
    common_ids = sorted(old_ids & new_ids)

    print("KB Diff Summary")
    print("---------------")
    print(f"Old sections: {len(old_ids)}")
    print(f"New sections: {len(new_ids)}")
    print(f"Added sections: {len(added_ids)}")
    print(f"Removed sections: {len(removed_ids)}")
    print("")

    if added_ids:
        print("Added:")
        for sid in added_ids:
            print(f"- [{sid}] {new_heads.get(sid, '')}")
        print("")

    if removed_ids:
        print("Removed:")
        for sid in removed_ids:
            print(f"- [{sid}] {old_heads.get(sid, '')}")
        print("")

    print("Common (unchanged IDs):", len(common_ids))


if __name__ == "__main__":
    main()

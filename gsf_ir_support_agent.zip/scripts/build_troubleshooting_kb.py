import argparse
import os
import json
from typing import List, Dict, Any, Optional

import numpy as np
from sentence_transformers import SentenceTransformer
from docx import Document as DocxDocument
from pypdf import PdfReader
import networkx as nx
from networkx.readwrite import json_graph
import nltk

# Ensure punkt is available (safe to call even if already downloaded)
try:
    nltk.data.find("tokenizers/punkt")
except LookupError:
    try:
        nltk.download("punkt", quiet=True)
    except Exception:
        pass

from nltk.tokenize import sent_tokenize


def read_docx(path: str) -> List[str]:
    doc = DocxDocument(path)
    texts: List[str] = []
    for para in doc.paragraphs:
        text = para.text.strip()
        if text:
            texts.append(text)
    return texts


def read_pdf(path: str) -> List[str]:
    reader = PdfReader(path)
    texts: List[str] = []
    for page in reader.pages:
        try:
            text = page.extract_text() or ""
        except Exception:
            text = ""
        text = text.strip()
        if text:
            texts.append(text)
    return texts


def merge_text_sources(pdf_path: Optional[str] = None, docx_path: Optional[str] = None) -> List[str]:
    parts: List[str] = []
    if docx_path and os.path.exists(docx_path):
        parts.extend(read_docx(docx_path))
    if pdf_path and os.path.exists(pdf_path):
        pdf_parts = read_pdf(pdf_path)
        existing = set(p.strip() for p in parts)
        for p in pdf_parts:
            if p.strip() not in existing:
                parts.append(p)
    return parts


def detect_sections(paragraphs: List[str]) -> List[Dict[str, Any]]:
    """
    Very simple heuristic sectioner:
    - Lines that look like headings (short, maybe with 'Error' or code pattern)
      start a new section.
    - Everything else is added as body text.
    """
    sections: List[Dict[str, Any]] = []
    current = {"id": 0, "heading": "Introduction", "body": []}
    sec_id = 0

    def is_heading(s: str) -> bool:
        if len(s) <= 80 and (s.isupper() or "error" in s.lower()):
            return True
        if len(s) <= 80 and (":" in s):
            return True
        return False

    for line in paragraphs:
        if is_heading(line) and current["body"]:
            sections.append(current)
            sec_id += 1
            current = {"id": sec_id, "heading": line.strip(), "body": []}
        else:
            current["body"].append(line.strip())
    if current["body"]:
        sections.append(current)

    return sections


def build_enhanced_markdown(sections: List[Dict[str, Any]]) -> str:
    lines: List[str] = ["# Troubleshooting Guide (Enhanced)", ""]
    for sec in sections:
        heading = sec["heading"].strip()
        if not heading:
            heading = f"Section {sec['id']}"
        if not heading.startswith("#"):
            lines.append(f"## {heading}")
        else:
            lines.append(heading)
        lines.append("")
        for para in sec["body"]:
            if para.strip().startswith(("-", "*", "•", "1.", "2.", "3.", "Step ")):
                lines.append(f"- {para.strip().lstrip('•').lstrip('*').strip()}")
            else:
                lines.append(para)
            lines.append("")
    return "\n".join(lines)


def build_embeddings(
    sections: List[Dict[str, Any]],
    model_name: str = "sentence-transformers/all-MiniLM-L6-v2",
    guide_version: Optional[str] = None,
) -> Dict[str, Any]:
    model = SentenceTransformer(model_name)
    embeddings_data: Dict[str, Any] = {
        "model_name": model_name,
        "guide_version": guide_version,
        "sections": [],
    }

    texts = []
    for sec in sections:
        body_text = " ".join(sec["body"])
        if not body_text.strip():
            body_text = sec["heading"]
        texts.append(body_text)

    embs = model.encode(texts, convert_to_numpy=True, normalize_embeddings=True)

    for sec, emb in zip(sections, embs):
        embeddings_data["sections"].append(
            {
                "id": sec["id"],
                "heading": sec["heading"],
                "embedding": emb.tolist(),
            }
        )

    return embeddings_data


def build_graph(sections: List[Dict[str, Any]]) -> nx.Graph:
    G = nx.Graph()
    for sec in sections:
        body_text = " ".join(sec["body"])
        sentences = sent_tokenize(body_text) if body_text else []
        G.add_node(
            sec["id"],
            heading=sec["heading"],
            text=body_text,
            sentences=sentences,
        )

    for i in range(len(sections) - 1):
        G.add_edge(sections[i]["id"], sections[i + 1]["id"], relation="next")

    def keywords(s: str) -> set:
        tokens = [t.lower() for t in s.split() if len(t) > 3]
        return set(tokens)

    for i in range(len(sections)):
        for j in range(i + 1, len(sections)):
            kw_i = keywords(" ".join(sections[i]["body"]))
            kw_j = keywords(" ".join(sections[j]["body"]))
            if not kw_i or not kw_j:
                continue
            overlap = len(kw_i & kw_j)
            if overlap >= 5:
                G.add_edge(
                    sections[i]["id"],
                    sections[j]["id"],
                    relation="keyword_similarity",
                    weight=overlap,
                )

    return G


def main():
    parser = argparse.ArgumentParser(
        description="Build troubleshooting knowledge base artifacts from PDF/DOCX."
    )
    parser.add_argument("--pdf", type=str, default=None, help="Path to PDF guide.")
    parser.add_argument(
        "--docx", type=str, default=None, help="Path to DOCX guide."
    )
    parser.add_argument(
        "--guide-version",
        type=str,
        default=None,
        help="Optional version label for this guide build (e.g., 'v1.2.3').",
    )
    parser.add_argument(
        "--out-markdown",
        type=str,
        required=True,
        help="Output enhanced Markdown path.",
    )
    parser.add_argument(
        "--out-embeddings",
        type=str,
        required=True,
        help="Output embeddings JSON path.",
    )
    parser.add_argument(
        "--out-graph",
        type=str,
        required=True,
        help="Output graph JSON path.",
    )
    args = parser.parse_args()

    if not args.pdf and not args.docx:
        raise SystemExit("You must provide at least one of --pdf or --docx.")

    paragraphs = merge_text_sources(pdf_path=args.pdf, docx_path=args.docx)
    if not paragraphs:
        raise SystemExit("No text could be extracted from the provided sources.")

    sections = detect_sections(paragraphs)

    markdown = build_enhanced_markdown(sections)
    os.makedirs(os.path.dirname(args.out_markdown), exist_ok=True)
    with open(args.out_markdown, "w", encoding="utf-8") as f:
        f.write(markdown)

    embeddings_data = build_embeddings(sections, guide_version=args.guide_version)
    os.makedirs(os.path.dirname(args.out_embeddings), exist_ok=True)
    with open(args.out_embeddings, "w", encoding="utf-8") as f:
        json.dump(embeddings_data, f, indent=2)

    G = build_graph(sections)
    os.makedirs(os.path.dirname(args.out_graph), exist_ok=True)
    data = json_graph.node_link_data(G)
    with open(args.out_graph, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

    print("Build complete.")
    print(f"- Enhanced Markdown: {args.out_markdown}")
    print(f"- Embeddings JSON : {args.out_embeddings}")
    print(f"- Graph JSON      : {args.out_graph}")
    if args.guide_version:
        print(f"- Guide version   : {args.guide_version}")


if __name__ == "__main__":
    main()

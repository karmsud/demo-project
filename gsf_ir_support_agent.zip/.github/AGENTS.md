# Global agent instructions for this repository

- This repository implements a **read-only troubleshooting assistant**.
- When answering questions about application errors, agents must **only use**
  information derived from the official Troubleshooting Guide located in
  `docs/` and the processed artifacts in
  `.github/skills/troubleshooting-kb/data/`.
- Never invent solutions that are not supported by that guide.
- Do **not** write or modify Python scripts at runtime.
  Reuse existing scripts under `scripts/`.
- Do not call external web APIs or search the public internet for answers.
  All answers must come from the guide or its derived artifacts.

---
name: troubleshooting-kb
description: >
  Use this skill when helping a user troubleshoot application errors
  using the official Troubleshooting Guide and its precomputed
  artifacts (Markdown, embeddings, and NetworkX graph).
---

# Troubleshooting KB Skill

This skill provides a deterministic troubleshooting workflow built on
pre-written Python scripts and precomputed knowledge artifacts.

## Files and artifacts

- Enhanced Markdown guide:
  `.github/skills/troubleshooting-kb/data/guide_enhanced.md`
- Embeddings index:
  `.github/skills/troubleshooting-kb/data/guide_embeddings.json`
- NetworkX graph (JSON):
  `.github/skills/troubleshooting-kb/data/guide_graph.json`
- Query log:
  `.github/skills/troubleshooting-kb/data/query_log.jsonl`
- Python scripts:
  - `scripts/build_troubleshooting_kb.py`
  - `scripts/answer_troubleshooting_question.py`

## Strict rules

- **Never** write or modify Python code at runtime.
- Use the existing scripts as-is via the `terminal` tool.
- Do not use web search; all answers must come from the guide artifacts.
- Prefer the script outputs over your own reasoning when there is conflict.

## Admin workflow – refresh knowledge base

Use when an admin explicitly says they are updating the troubleshooting guide.

1. Confirm the new source files are in `docs/` (PDF and/or DOCX) and, if possible,
   ask for a guide version label (e.g., `v1.2.3`).
2. Construct and run the build command via `#tool:terminal`:

   ```bash
   python scripts/build_troubleshooting_kb.py ^
     --pdf docs/troubleshooting_guide.pdf ^
     --docx docs/troubleshooting_guide.docx ^
     --guide-version "<version or app build>" ^
     --out-markdown .github/skills/troubleshooting-kb/data/guide_enhanced.md ^
     --out-embeddings .github/skills/troubleshooting-kb/data/guide_embeddings.json ^
     --out-graph .github/skills/troubleshooting-kb/data/guide_graph.json
   ```

   - If only one of `--pdf` or `--docx` exists, omit the other flag.
   - If the admin does not supply a version, omit `--guide-version`.
   - Wait for the command to finish before answering.

3. After the script finishes, summarize for the admin:
   - confirmation of the artifact paths,
   - the guide version (if set),
   - timestamp of update.

## Support workflow – answer a user’s error question

Use this when a user pastes error text and/or attaches a screenshot.

1. Extract the user’s **question**, **error text**, and any **context**
   (environment, version, steps to reproduce). If key details are missing,
   ask clarifying questions before running the script.
2. Decide answer mode:
   - Use `--mode quick` by default.
   - If the user asks "why", "explain", or wants more detail, use `--mode deep`.
3. If a screenshot is clearly referenced and saved to a file in the workspace,
   include its path when calling the answer script. If not, rely on the text
   the user has provided.
4. Construct and run the answer script via `#tool:terminal`:

   ```bash
   python scripts/answer_troubleshooting_question.py ^
     --question "<short restatement of user question>" ^
     --error-text "<consolidated text from logs and chat>" ^
     --markdown .github/skills/troubleshooting-kb/data/guide_enhanced.md ^
     --embeddings .github/skills/troubleshooting-kb/data/guide_embeddings.json ^
     --graph .github/skills/troubleshooting-kb/data/guide_graph.json ^
     --top-k 5 ^
     --mode quick ^
     --out .github/skills/troubleshooting-kb/data/last_answer.json
   ```

   - If an image path is available, also add:
     `--screenshot-path "<relative/path/to/screenshot.png>"`.
   - For debugging or developer usage, you may increase `--top-k` to 10.

5. After the command finishes, open
   `.github/skills/troubleshooting-kb/data/last_answer.json` and use it
   to craft your answer. The JSON contains:
   - `answer_markdown`: detailed explanation,
   - `solutions`: list of candidate solutions with step lists,
   - `relevant_sections`: list of guide headings and IDs,
   - `confidence` and `confidence_band` ("high" | "medium" | "low"),
   - `guide_version` if available.

6. Respond to the user by:
   - Quoting the main solution in natural language,
   - Explaining the fix step by step in a numbered list,
   - Listing alternative solutions when available,
   - Including a brief “why this works” explanation derived from the guide,
   - Mentioning the guide version you used, if known.

If the confidence band is "low", tell the user that the match is weak and
suggest adding more context or escalating.

## Debug workflow – inspect candidates (developer only)

For your own tuning and debugging, you can call the answer script with
`--top-k 10` and inspect the `solutions` array directly or via the
`/debug-troubleshooting-kb` prompt. Use this to refine guide headings
and sectioning so that the right sections are retrieved.

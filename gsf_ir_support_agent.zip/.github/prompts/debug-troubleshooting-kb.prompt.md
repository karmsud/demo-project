---
name: debug-troubleshooting-kb
description: Developer-only workflow to inspect top candidate sections for a query.
agent: GSF IR Support Agent
tools: ['terminal', 'codebase', 'search']
argument-hint: "Provide a sample question and error text to debug retrieval."
---

You are helping a **developer or power user** debug the troubleshooting KB.

1. Ask the user for:
   - A representative question,
   - The associated error text or log snippet.

2. Explain that you will call the answer script in debug mode to retrieve
   the top 10 candidate sections with scores.

3. Use `#tool:terminal` to run:

   ```bash
   python scripts/answer_troubleshooting_question.py ^
     --question "<debug question>" ^
     --error-text "<debug error text>" ^
     --markdown .github/skills/troubleshooting-kb/data/guide_enhanced.md ^
     --embeddings .github/skills/troubleshooting-kb/data/guide_embeddings.json ^
     --graph .github/skills/troubleshooting-kb/data/guide_graph.json ^
     --top-k 10 ^
     --mode quick ^
     --out .github/skills/troubleshooting-kb/data/last_answer.json
   ```

4. After the command finishes, open `last_answer.json` and show the user:
   - The confidence and band,
   - Each candidate solution's section ID, heading, and score.

5. Briefly suggest how they might tune the guide headings or content if
   the right section isn’t being ranked highly.

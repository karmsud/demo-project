---
name: refresh-troubleshooting-kb
description: Admin-only workflow to rebuild the troubleshooting knowledge base.
agent: GSF IR Support Agent
tools: ['terminal', 'codebase', 'search']
argument-hint: "Confirm the new PDF/DOCX file names in docs/ and the guide version string."
---

You are helping an **administrator** refresh the troubleshooting knowledge base.

1. Confirm with the user:
   - The new PDF file path under `docs/`, if it exists.
   - The new DOCX file path under `docs/`, if it exists.
   - The guide or app version label to use (e.g., `v1.3.0`).

2. Explain that you will run the pre-existing build script
   `scripts/build_troubleshooting_kb.py` to regenerate:
   - enhanced Markdown
   - embeddings index
   - NetworkX graph

3. Use `#tool:terminal` to construct and run the command described
   in the `troubleshooting-kb` skill, including `--guide-version` when provided.

4. After the command completes:
   - Inspect any console output for obvious errors.
   - Summarize what was regenerated and the guide version.
   - Remind the admin that all subsequent support answers will use
     the new guide content.

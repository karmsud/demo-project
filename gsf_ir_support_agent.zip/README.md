# GSF IR Support Agent Scaffold

This repository is a scaffold for a **GSF IR Support Agent** that runs inside
VS Code with GitHub Copilot Agents. The agent:

- Answers error / troubleshooting questions using **only** your official
  Troubleshooting Guide.
- Uses **pre-built Python scripts** to:
  - Convert your PDF / Word guide into an enhanced Markdown file.
  - Create a semantic embedding index from that Markdown.
  - Build a simple NetworkX graph representation of the guide.
- At runtime, when a user asks a question, the agent:
  - Extracts error text (and optionally OCRs screenshots).
  - Performs **semantic search** and uses the graph to find relevant sections.
  - Returns up to **top 5 ranked solutions** in a clean, step-by-step format.
- Behaves as a **read-only research/reasoning agent**:
  - It reuses these Python scripts and does *not* generate new Python at runtime.
  - It does not act on external systems—only reads, reasons, and explains.

Additional features:

- **Confidence-aware answers** with "I don't know" behavior when matches are weak.
- **Query logging** (`query_log.jsonl`) so you can see what users ask that the guide
  does or doesn’t cover.
- Optional **version-awareness** (tag guide builds with a version string).
- A basic **KB regression test harness** to check that known errors still map to
  expected sections after guide updates.
- A **debug prompt** for you to inspect top candidate sections for a query.

> This is a scaffold: you are expected to drop in your own Troubleshooting Guide
> PDF / DOCX and tweak paths or logic as needed.

---

## 1. Folder layout

After unzipping, you'll see something like:

```text
gsf_ir_support_agent/
  requirements.txt
  README.md

  docs/
    troubleshooting_guide.pdf        # <-- you add this
    troubleshooting_guide.docx       # <-- and/or this

  scripts/
    build_troubleshooting_kb.py
    answer_troubleshooting_question.py
    test_troubleshooting_kb.py
    kb_diff_summary.py

  .github/
    AGENTS.md
    agents/
      gsf-ir-support.agent.md
    prompts/
      start-support-session.prompt.md
      refresh-troubleshooting-kb.prompt.md
      debug-troubleshooting-kb.prompt.md
    skills/
      troubleshooting-kb/
        SKILL.md
        data/
          guide_enhanced.md          # generated
          guide_embeddings.json      # generated
          guide_graph.json           # generated
          last_answer.json           # generated
          query_log.jsonl            # appended to by answer script
```

You **only** need to supply the PDF and/or DOCX troubleshooting guide in `docs/`
and run the build script once to create the artifacts.

---

## 2. One-time Python setup

1. Open this folder in VS Code.

2. Create and activate a virtual environment (Windows / PowerShell):

   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

3. Install dependencies:

   ```powershell
   pip install -r requirements.txt
   ```

4. (Optional but recommended) Download NLTK punkt tokenizer data:

   ```powershell
   python -m nltk.downloader punkt
   ```

5. **Tesseract OCR** (optional, for screenshot OCR from Python):

   - Install the Tesseract binary for your OS (e.g., Windows installer).
   - Ensure `tesseract` is on your PATH or configure `pytesseract.pytesseract.tesseract_cmd`
     inside `answer_troubleshooting_question.py`.

   If you can't install Tesseract, you can still use the system by:
   - Copy-pasting error text instead of relying on OCR, or
   - Letting Copilot vision read the screenshot text in chat while the scripts
     operate only on text.

---

## 3. Add your Troubleshooting Guide

1. Place your PDF and/or DOCX in the `docs/` folder:

   - `docs/troubleshooting_guide.pdf`
   - `docs/troubleshooting_guide.docx`

   The build script prefers DOCX if present, but can fall back to PDF.

2. Run the **build** script from the repo root (with venv active):

   ```powershell
   python scripts\build_troubleshooting_kb.py `
     --pdf docs/troubleshooting_guide.pdf `
     --docx docs/troubleshooting_guide.docx `
     --guide-version "v1.0" `
     --out-markdown .github/skills/troubleshooting-kb/data/guide_enhanced.md `
     --out-embeddings .github/skills/troubleshooting-kb/data/guide_embeddings.json `
     --out-graph .github/skills/troubleshooting-kb/data/guide_graph.json
   ```

   You can omit `--pdf` or `--docx` if you only have one of them.
   `--guide-version` is optional but recommended (e.g., your app or doc version).

This will:

- Extract text from your guide.
- Produce a lightly structured **enhanced Markdown** version.
- Chunk the guide into sections and compute embeddings using a local
  `sentence-transformers` model.
- Build a simple NetworkX graph connecting related sections.
- Tag the embeddings with the guide version (if provided).

---

## 4. How the runtime answer script works

The script `scripts/answer_troubleshooting_question.py` expects:

- `--question`: short restatement of the user's question.
- `--error-text`: the full error message / text (including anything OCR'd).
- Paths to the Markdown, embeddings JSON, and graph JSON.
- An output JSON path (`--out`).
- Optional:
  - `--screenshot-path`: to OCR an error screenshot.
  - `--mode quick|deep`: quick = lean steps; deep = more verbose explanation.
  - `--top-k`: number of candidate solutions (default 5).

Example CLI usage:

```powershell
python scripts\answer_troubleshooting_question.py `
  --question "Why is my ABC-123 pipeline failing on step 4?" `
  --error-text "ABC-123: Failed to connect to upstream service..." `
  --markdown .github/skills/troubleshooting-kb/data/guide_enhanced.md `
  --embeddings .github/skills/troubleshooting-kb/data/guide_embeddings.json `
  --graph .github/skills/troubleshooting-kb/data/guide_graph.json `
  --top-k 5 `
  --mode quick `
  --out .github/skills/troubleshooting-kb/data/last_answer.json
```

The JSON output will contain:

- `answer_markdown`: a Markdown-formatted explanation.
- `solutions`: up to `top_k` ranked candidate solutions with steps.
- `relevant_sections`: list of guide section IDs and headings.
- `confidence`: numeric score between 0 and 1.
- `guide_version`: if available from the build.
- `confidence_band`: "high" | "medium" | "low".

The script also appends a log entry to:
`.github/skills/troubleshooting-kb/data/query_log.jsonl`

---

## 5. VS Code + GitHub Copilot Agent wiring

This scaffold includes:

- `.github/skills/troubleshooting-kb/SKILL.md`  
  Describes how Copilot should use the build + answer scripts and the
  generated artifacts. It also encodes the rules:
  - no new Python at runtime
  - only answer from this guide
  - scripts must be used via the `terminal` tool.

- `.github/agents/gsf-ir-support.agent.md`  
  Defines the **GSF IR Support Agent** custom agent persona.

- `.github/prompts/start-support-session.prompt.md`  
  Slash-command-style prompt to start a guided support session with this agent.

- `.github/prompts/refresh-troubleshooting-kb.prompt.md`  
  Slash-command-style prompt for an **admin** to re-run the build script when
  the guide is updated.

- `.github/prompts/debug-troubleshooting-kb.prompt.md`  
  Debug-only prompt that helps you inspect top candidate sections, scores,
  and headings for a given query.

- `.github/AGENTS.md`  
  Global guardrails for all agents in this repo.

### 5.1 Enable skills & AGENTS in VS Code

In your VS Code settings (JSON), add:

```json
{
  "chat.useAgentSkills": true,
  "chat.useAgentsMdFile": true
}
```

### 5.2 Start a support session (user flow)

1. Open **GitHub Copilot Chat** in VS Code.
2. From the **Agents** dropdown, select **GSF IR Support Agent**.
3. Type:

   ```text
   /start-support-session
   ```

4. Follow the agent's questions and paste:
   - your error text,
   - any logs,
   - optionally attach screenshots,
   - mention the app version if applicable.

The agent will:

- Ask clarifying questions if key details are missing.
- Use the `troubleshooting-kb` skill to call
  `answer_troubleshooting_question.py`.
- Return up to top 5 ranked solution candidates in a structured format:
  - summary
  - root cause
  - step-by-step fix
  - references into your guide
  - note about confidence level and doc version used.

### 5.3 Refresh the troubleshooting KB (admin flow)

1. Drop a new version of the guide into `docs/`.
2. In Copilot Chat (same agent), run:

   ```text
   /refresh-troubleshooting-kb
   ```

3. Provide the new file names and (optionally) guide version when prompted.

The agent will:

- Use the `troubleshooting-kb` skill's admin workflow.
- Run `build_troubleshooting_kb.py` via the `terminal` tool.
- Summarize what was regenerated and confirm the timestamp/version.

### 5.4 Debug top candidates (developer flow)

1. In Copilot Chat, with **GSF IR Support Agent** selected, type:

   ```text
   /debug-troubleshooting-kb
   ```

2. Provide an error / question as if you were a user.

The agent will:

- Call the answer script with a higher `--top-k` (e.g., 10).
- Show you raw rankings: scores, headings, and section IDs for each candidate.
- Help you tune headings, sectioning, or the guide itself.

---

## 6. Regression testing

The scaffold includes a simple `scripts/test_troubleshooting_kb.py` that you
can extend with known error → expected section mappings. Run it after
rebuilding the KB to ensure retrieval quality hasn't regressed.

---

## 7. Customization ideas

- Improve section detection to align with your guide's layout.
- Add more metadata into graph nodes (error codes, severity, components).
- Add filters (e.g., select only sections matching a specific module).
- Integrate with your existing GSF IR logging or ticketing workflows
  *without* turning the agent into an "Act" agent.

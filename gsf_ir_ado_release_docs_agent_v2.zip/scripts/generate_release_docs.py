import argparse
import glob
import os
from typing import List, Dict, Any, Optional

import pandas as pd

REQUIRED_COLS = [
    "ID",
    "Title",
    "Work Item Type",
    "State",
    "Area Path",
    "Iteration Path",
    "Tags",
    "Description",
]

def load_csvs(pattern: str) -> pd.DataFrame:
    paths = glob.glob(pattern)
    if not paths:
        raise SystemExit(f"No CSV files matched pattern: {pattern}")
    frames = []
    for p in paths:
        df = pd.read_csv(p)
        df["__source_file"] = os.path.basename(p)
        frames.append(df)
    df_all = pd.concat(frames, ignore_index=True)

    # ensure required cols
    for col in REQUIRED_COLS:
        if col not in df_all.columns:
            df_all[col] = ""

    return df_all

def filter_by_release(df: pd.DataFrame, release_name: Optional[str]) -> pd.DataFrame:
    if not release_name:
        return df
    mask = df["Iteration Path"].astype(str).str.lower().str.contains(release_name.lower())
    filtered = df[mask]
    if filtered.empty:
        print(f"Warning: no rows matched release-name '{release_name}'. Using all rows.")
        return df
    return filtered

def build_kb_doc(df: pd.DataFrame, release_name: Optional[str]) -> str:
    title_release = release_name or "All Releases"
    lines: List[str] = [f"# SDLC Knowledge Base – {title_release}", ""]

    # Group by iteration path
    for iteration, group in sorted(df.groupby("Iteration Path", dropna=False), key=lambda x: str(x[0])):
        iter_name = iteration if (isinstance(iteration, str) and iteration.strip()) else "Unassigned"
        lines.append(f"## Release: {iter_name}")
        lines.append("")
        # order by ID (as string)
        group_sorted = group.copy()
        group_sorted["__ID_str"] = group_sorted["ID"].astype(str)
        group_sorted = group_sorted.sort_values("__ID_str")
        for _, row in group_sorted.iterrows():
            wid = str(row["ID"])
            title = str(row["Title"]) if not pd.isna(row["Title"]) else ""
            work_item_type = str(row["Work Item Type"])
            state = str(row["State"])
            area = str(row["Area Path"])
            tags = str(row["Tags"])
            desc = str(row["Description"]) if not pd.isna(row["Description"]) else ""

            heading = f"### [{wid}] {title}".strip()
            lines.append(heading)
            lines.append("")
            lines.append(f"- Work Item Type: {work_item_type}")
            lines.append(f"- State: {state}")
            lines.append(f"- Area: {area}")
            lines.append(f"- Tags: {tags}")
            lines.append("")
            if desc.strip():
                lines.append(desc.strip())
                lines.append("")
        lines.append("")

    return "\n".join(lines)

def build_dev_doc(df: pd.DataFrame, release_name: Optional[str]) -> str:
    title_release = release_name or "All Releases"
    lines: List[str] = [f"# Technical Change Log – {title_release}", ""]

    # Group by Area Path, then Work Item Type
    for area, area_group in sorted(df.groupby("Area Path", dropna=False), key=lambda x: str(x[0])):
        area_name = area if (isinstance(area, str) and area.strip()) else "Unassigned Area"
        lines.append(f"## Area: {area_name}")
        lines.append("")

        for wtype, type_group in sorted(area_group.groupby("Work Item Type", dropna=False), key=lambda x: str(x[0])):
            wtype_name = wtype if (isinstance(wtype, str) and wtype.strip()) else "Unspecified Type"
            lines.append(f"### {wtype_name}")
            lines.append("")
            type_sorted = type_group.copy()
            type_sorted["__ID_str"] = type_sorted["ID"].astype(str)
            type_sorted = type_sorted.sort_values("__ID_str")
            for _, row in type_sorted.iterrows():
                wid = str(row["ID"])
                title = str(row["Title"]) if not pd.isna(row["Title"]) else ""
                state = str(row["State"])
                tags = str(row["Tags"])
                meta_parts = []
                if state:
                    meta_parts.append(f"State: {state}")
                if tags:
                    meta_parts.append(f"Tags: {tags}")
                meta = "; ".join(meta_parts)
                if meta:
                    lines.append(f"- [{wid}] {title} ({meta})")
                else:
                    lines.append(f"- [{wid}] {title}")
            lines.append("")
        lines.append("")

    return "\n".join(lines)

def categorize_for_user(item_type: str) -> str:
    t = (item_type or "").lower()
    if any(x in t for x in ["feature", "user story", "product backlog item", "story"]):
        return "features"
    if "bug" in t:
        return "bugs"
    return "other"

def build_user_doc(df: pd.DataFrame, release_name: Optional[str]) -> str:
    title_release = release_name or "All Releases"
    lines: List[str] = [f"# Release Notes – {title_release}", ""]

    categories = {"features": [], "bugs": [], "other": []}
    for _, row in df.iterrows():
        wid = str(row["ID"])
        title = str(row["Title"]) if not pd.isna(row["Title"]) else ""
        wtype = str(row["Work Item Type"])
        cat = categorize_for_user(wtype)
        categories[cat].append({"id": wid, "title": title})

    if categories["features"]:
        lines.append("## New Features / Enhancements")
        lines.append("")
        for it in categories["features"]:
            lines.append(f"- [{it['id']}] {it['title']}")
        lines.append("")

    if categories["bugs"]:
        lines.append("## Bug Fixes")
        lines.append("")
        for it in categories["bugs"]:
            lines.append(f"- [{it['id']}] {it['title']}")
        lines.append("")

    if categories["other"]:
        lines.append("## Other Changes")
        lines.append("")
        for it in categories["other"]:
            lines.append(f"- [{it['id']}] {it['title']}")
        lines.append("")

    if not (categories["features"] or categories["bugs"] or categories["other"]):
        lines.append("_No work items found for this selection._")
        lines.append("")

    return "\n".join(lines)

def main():
    parser = argparse.ArgumentParser(
        description="Generate KB, technical doc, and end-user release notes from ADO/TFS CSV exports."
    )
    parser.add_argument(
        "--input-glob",
        type=str,
        required=True,
        help="Glob pattern for input CSV files, e.g. 'data/ado/raw/*.csv'.",
    )
    parser.add_argument(
        "--release-name",
        type=str,
        default=None,
        help="Optional release name filter (matched against 'Iteration Path').",
    )
    parser.add_argument(
        "--out-kb",
        type=str,
        required=True,
        help="Output path for the knowledge base Markdown file.",
    )
    parser.add_argument(
        "--out-dev",
        type=str,
        required=True,
        help="Output path for the developer technical notes Markdown file.",
    )
    parser.add_argument(
        "--out-user",
        type=str,
        required=True,
        help="Output path for the end-user release notes Markdown file.",
    )
    args = parser.parse_args()

    df = load_csvs(args.input_glob)
    df = filter_by_release(df, args.release_name)

    kb_md = build_kb_doc(df, args.release_name)
    dev_md = build_dev_doc(df, args.release_name)
    user_md = build_user_doc(df, args.release_name)

    os.makedirs(os.path.dirname(args.out_kb), exist_ok=True)
    os.makedirs(os.path.dirname(args.out_dev), exist_ok=True)
    os.makedirs(os.path.dirname(args.out_user), exist_ok=True)

    with open(args.out_kb, "w", encoding="utf-8") as f:
        f.write(kb_md)
    with open(args.out_dev, "w", encoding="utf-8") as f:
        f.write(dev_md)
    with open(args.out_user, "w", encoding="utf-8") as f:
        f.write(user_md)

    print("Release documentation generation complete.")
    print(f"- Knowledge base       : {args.out_kb}")
    print(f"- Dev technical notes  : {args.out_dev}")
    print(f"- User release notes   : {args.out_user}")

if __name__ == "__main__":
    main()

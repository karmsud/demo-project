# GSF IR ADO Release Docs Agent (v2 – NL routing)

This scaffold is for **Use Case #2**:

> You provide CSV exports from Azure DevOps (ADO) / TFS.  
> The agent consumes them and generates three Markdown documents:
>
> 1. A **knowledge base document** (`kb_sdlc.md`),
> 2. A **technical document for developers** (`dev_technical_notes.md`),
> 3. An **end‑user release notes document** (`release_notes_user.md`).

There is **no Q&A chatbot**. This is a **pure analyzer agent** that:
- reads your CSV exports,
- runs a single deterministic Python script,
- produces the three docs,
- then (optionally) summarizes them for you in chat.

This **v2** version enhances the agent instructions so the user can talk in
natural language (e.g. *"Generate release notes for 2026.01"*), and the agent
decides which script + outputs to use.

---

## 1. Folder layout

```text
gsf_ir_ado_release_docs_agent_v2/
  requirements.txt
  README.md

  data/
    ado/
      raw/
        # <-- drop ADO/TFS CSV exports here

  scripts/
    generate_release_docs.py   # main script creating all 3 docs

  .github/
    AGENTS.md
    agents/
      gsf-ir-ado-release-docs.agent.md
    skills/
      ado-release-docs/
        SKILL.md
        data/
          kb_sdlc.md             # generated
          dev_technical_notes.md # generated
          release_notes_user.md  # generated
    prompts/
      generate-ado-release-docs.prompt.md
```

---

## 2. One-time setup (Windows / PowerShell)

From repo root:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

---

## 3. Provide your ADO/TFS CSV exports

Save exported CSVs under:

- `data/ado/raw/`

Expected columns (or similar):

- `ID`
- `Title`
- `Work Item Type`
- `State`
- `Area Path`
- `Iteration Path`   (used as “release / sprint / iteration”)
- `Tags`
- `Description`

Missing columns are created as empty strings, but more data = better docs.

---

## 4. Core script (you *can* call it manually)

```powershell
python scripts\generate_release_docs.py ^
  --input-glob "data/ado/raw/*.csv" ^
  --release-name "2026.01" ^
  --out-kb .github/skills/ado-release-docs/data/kb_sdlc.md ^
  --out-dev .github/skills/ado-release-docs/data/dev_technical_notes.md ^
  --out-user .github/skills/ado-release-docs/data/release_notes_user.md
```

But normally, you’ll let the **agent** call this for you.

---

## 5. VS Code + Copilot setup

In VS Code settings (JSON):

```json
{
  "chat.useAgentSkills": true,
  "chat.useAgentsMdFile": true
}
```

Then in Copilot Chat:

1. Select **GSF IR ADO Release Docs Agent**.
2. Either:
   - Use the slash command `/generate-ado-release-docs`, **or**
   - Just talk in natural language, e.g.  
     *"I dropped CSV exports into `data/ado/raw`. Generate KB, dev notes, and end‑user release notes for release 2026.01."*

The agent will:

- Ask for CSV glob + release name if needed,
- Run `generate_release_docs.py` via the `terminal` tool,
- Present the generated docs (especially `release_notes_user.md`) in chat.

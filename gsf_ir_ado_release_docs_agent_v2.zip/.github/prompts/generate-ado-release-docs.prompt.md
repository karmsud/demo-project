---
name: generate-ado-release-docs
description: Generate KB, technical, and end-user release docs from ADO/TFS CSV exports.
agent: GSF IR ADO Release Docs Agent
tools: ['terminal', 'codebase', 'search']
argument-hint: >
  Provide the CSV glob (e.g. data/ado/raw/*.csv) and an optional release name
  (e.g. 2026.01).
---

You are helping a user generate three documents from their ADO/TFS CSV exports:

1. SDLC Knowledge Base (kb_sdlc.md),
2. Developer Technical Notes (dev_technical_notes.md),
3. End-User Release Notes (release_notes_user.md).

Steps:

1. Ask the user for:
   - CSV glob (default: `data/ado/raw/*.csv`),
   - Release name string, if they want to filter.

2. Explain that you will call the pre-written script `generate_release_docs.py`
   to generate all three Markdown docs.

3. Use the `terminal` tool to run:

   ```bash
   python scripts/generate_release_docs.py ^
     --input-glob "<user CSV glob, or data/ado/raw/*.csv>" ^
     --release-name "<user release name or empty>" ^
     --out-kb .github/skills/ado-release-docs/data/kb_sdlc.md ^
     --out-dev .github/skills/ado-release-docs/data/dev_technical_notes.md ^
     --out-user .github/skills/ado-release-docs/data/release_notes_user.md
   ```

   - If the user does **not** want to filter by release, omit `--release-name`.

4. After the command completes:
   - Confirm that the docs were written.
   - Offer to open and summarize them, starting with `release_notes_user.md`
     for end-user communications.
